<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs_CZ">
<context>
    <name>about</name>
    <message>
        <source>About AcetoneISO2</source>
        <translation type="obsolete">O AcetoneISO2</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Autoři</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Kontakty</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <source>ok</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>About AcetoneISO</source>
        <translation>O AcetoneISO2</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Honor &amp;&amp; Glory</source>
        <translation>Pocta &amp;&amp; Sláva</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Translators:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Italian: Original Authors&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Czech: Hanz&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Russian: Arseniy Muravyev&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Polish: Jarek&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Romanian: Aparaschivei Florin&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Hungarian: Sandor Lisovszki&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;German: Johannes Obermayr&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Special Thanks goes to:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All the people that made a donation!&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All package mantainers.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All the people that submitted bug-reports and in some cases suggested even solutions to fix them.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Irc #qt channel on irc.freenode.net for all their help on C++ and Qt4&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Trolltech for releasing such a wonderful framework, Qt4!&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All the open source tools AcetoneISO uses, this includes: fuseiso, mencoder, mplayer, mencoder, dd, cdrdao, wodim, growisofs, youtube-dl, 7z, ffmpeg, gnupg, dvd+r-format and more!&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To Poweriso, because even if they released a proprietary version of their software, it&apos;s free to use, works good and is feature-rich (too bad x86 only).&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Alcohol 120% software :) Yes, they inspired AcetoneISO&apos;s name :p&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;And finally... a big thanks goes to You for using our software! It&apos;s for people like you that we find the strength to continue working on AcetoneISO.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Thanks to all of You,&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;The AcetoneISO Team&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Translators:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Italian: Original Authors&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Czech: Hanz&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Russian: Arseniy Muravyev&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Polish: Jarek&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Romanian: Aparaschivei Florin&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Hungarian: Sandor Lisovszki&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;German: Johannes Obermayr&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Special Thanks goes to:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All the people that made a donation!&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All package mantainers.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All the people that submitted bug-reports and in some cases suggested even solutions to fix them.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Irc #qt channel on irc.freenode.net for all their help on C++ and Qt4&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Trolltech for releasing such a wonderful framework, Qt4!&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All the open source tools AcetoneISO uses, this includes: fuseiso, mencoder, mplayer, mencoder, dd, cdrdao, wodim, growisofs, youtube-dl, 7z, ffmpeg, gnupg, dvd+r-format and more!&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To Poweriso, because even if they released a proprietary version of their software, it&apos;s free to use, works good and is feature-rich (too bad x86 only).&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Alcohol 120% software :) Yes, they inspired AcetoneISO&apos;s name :p&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;And finally... a big thanks goes to You for using our software! It&apos;s for people like you that we find the strength to continue working on AcetoneISO.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Thanks to all of You,&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;The AcetoneISO Team&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;You can contact us by email at:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0000ff;&quot;&gt;acetoneiso@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Official Website:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.acetoneteam.org/&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.acetoneteam.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;GNU GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Version 3, 29 June 2007 &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Copyright © 2007 Free Software Foundation, Inc. &amp;lt;http://fsf.org/&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;preamble&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;reamble &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The GNU General Public License is a free, copyleft license for software and other kinds of works. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program--to make sure it remains free software for all its users. We, the Free Software Foundation, use the GNU General Public License for most of our software; it applies also to any other work released this way by its authors. You can apply it to your programs, too. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Developers that use the GNU GPL protect your rights with two steps: (1) assert copyright on the software, and (2) offer you this License giving you legal permission to copy, distribute and/or modify it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For the developers&apos; and authors&apos; protection, the GPL clearly explains that there is no warranty for this free software. For both users&apos; and authors&apos; sake, the GPL requires that modified versions be marked as changed, so that their problems will not be attributed erroneously to authors of previous versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Some devices are designed to deny users access to install or run modified versions of the software inside them, although the manufacturer can do so. This is fundamentally incompatible with the aim of protecting users&apos; freedom to change the software. The systematic pattern of such abuse occurs in the area of products for individuals to use, which is precisely where it is most unacceptable. Therefore, we have designed this version of the GPL to prohibit the practice for those products. If such problems arise substantially in other domains, we stand ready to extend this provision to those domains in future versions of the GPL, as needed to protect the freedom of users. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Finally, every program is threatened constantly by software patents. States should not allow patents to restrict development and use of software on general-purpose computers, but in those that do, we wish to avoid the special danger that patents applied to a free program could make it effectively proprietary. To prevent this, the GPL assures that patents cannot be used to render the program non-free. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;terms&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;ERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section0&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;0&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Definitions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“This License” refers to version 3 of the GNU General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Copyright” also means copyright-like laws that apply to other kinds of works, such as semiconductor masks. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“The Program” refers to any copyrightable work licensed under this License. Each licensee is addressed as “you”. “Licensees” and “recipients” may be individuals or organizations. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “modify” a work means to copy from or adapt all or part of the work in a fashion requiring copyright permission, other than the making of an exact copy. The resulting work is called a “modified version” of the earlier work or a work “based on” the earlier work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “covered work” means either the unmodified Program or a work based on the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “propagate” a work means to do anything with it that, without permission, would make you directly or secondarily liable for infringement under applicable copyright law, except executing it on a computer or modifying a private copy. Propagation includes copying, distribution (with or without modification), making available to the public, and in some countries other activities as well. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “convey” a work means any kind of propagation that enables other parties to make or receive copies. Mere interaction with a user through a computer network, with no transfer of a copy, is not conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;An interactive user interface displays “Appropriate Legal Notices” to the extent that it includes a convenient and prominently visible feature that (1) displays an appropriate copyright notice, and (2) tells the user that there is no warranty for the work (except to the extent that warranties are provided), that licensees may convey the work under this License, and how to view a copy of this License. If the interface presents a list of user commands or options, such as a menu, a prominent item in the list meets this criterion. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Source Code. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “source code” for a work means the preferred form of the work for making modifications to it. “Object code” means any non-source form of a work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “Standard Interface” means an interface that either is an official standard defined by a recognized standards body, or, in the case of interfaces specified for a particular programming language, one that is widely used among developers working in that language. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “System Libraries” of an executable work include anything, other than the work as a whole, that (a) is included in the normal form of packaging a Major Component, but which is not part of that Major Component, and (b) serves only to enable use of the work with that Major Component, or to implement a Standard Interface for which an implementation is available to the public in source code form. A “Major Component”, in this context, means a major essential component (kernel, window system, and so on) of the specific operating system (if any) on which the executable work runs, or a compiler used to produce the work, or an object code interpreter used to run it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “Corresponding Source” for a work in object code form means all the source code needed to generate, install, and (for an executable work) run the object code and to modify the work, including scripts to control those activities. However, it does not include the work&apos;s System Libraries, or general-purpose tools or generally available free programs which are used unmodified in performing those activities but which are not part of the work. For example, Corresponding Source includes interface definition files associated with source files for the work, and the source code for shared libraries and dynamically linked subprograms that the work is specifically designed to require, such as by intimate data communication or control flow between those subprograms and other parts of the work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Corresponding Source need not include anything that users can regenerate automatically from other parts of the Corresponding Source. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Corresponding Source for a work in source code form is that same work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;2&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Basic Permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;All rights granted under this License are granted for the term of copyright on the Program, and are irrevocable provided the stated conditions are met. This License explicitly affirms your unlimited permission to run the unmodified Program. The output from running a covered work is covered by this License only if the output, given its content, constitutes a covered work. This License acknowledges your rights of fair use or other equivalent, as provided by copyright law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Conveying under any other circumstances is permitted solely under the conditions stated below. Sublicensing is not allowed; section 10 makes it unnecessary. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Protecting Users&apos; Legal Rights From Anti-Circumvention Law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No covered work shall be deemed part of an effective technological measure under any applicable law fulfilling obligations under article 11 of the WIPO copyright treaty adopted on 20 December 1996, or similar laws prohibiting or restricting circumvention of such measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When you convey a covered work, you waive any legal power to forbid circumvention of technological measures to the extent such circumvention is effected by exercising rights under this License with respect to the covered work, and you disclaim any intention to limit operation or modification of the work as a means of enforcing, against the work&apos;s users, your or third parties&apos; legal rights to forbid circumvention of technological measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;4&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Verbatim Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey verbatim copies of the Program&apos;s source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice; keep intact all notices stating that this License and any non-permissive terms added in accord with section 7 apply to the code; keep intact all notices of the absence of any warranty; and give all recipients a copy of this License along with the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may charge any price or no price for each copy that you convey, and you may offer support or warranty protection for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section5&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;5&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Modified Source Versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey a work based on the Program, or the modifications to produce it from the Program, in the form of source code under the terms of section 4, provided that you also meet all of these conditions: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) The work must carry prominent notices stating that you modified it, and giving a relevant date. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) The work must carry prominent notices stating that it is released under this License and any conditions added under section 7. This requirement modifies the requirement in section 4 to “keep intact all notices”. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) You must license the entire work, as a whole, under this License to anyone who comes into possession of a copy. This License will therefore apply, along with any applicable section 7 additional terms, to the whole of the work, and all its parts, regardless of how they are packaged. This License gives no permission to license the work in any other way, but it does not invalidate such permission if you have separately received it. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) If the work has interactive user interfaces, each must display Appropriate Legal Notices; however, if the Program has interactive interfaces that do not display Appropriate Legal Notices, your work need not make them do so. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A compilation of a covered work with other separate and independent works, which are not by their nature extensions of the covered work, and which are not combined with it such as to form a larger program, in or on a volume of a storage or distribution medium, is called an “aggregate” if the compilation and its resulting copyright are not used to limit the access or legal rights of the compilation&apos;s users beyond what the individual works permit. Inclusion of a covered work in an aggregate does not cause this License to apply to the other parts of the aggregate. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section6&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;6&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Non-Source Forms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey a covered work in object code form under the terms of sections 4 and 5, provided that you also convey the machine-readable Corresponding Source under the terms of this License, in one of these ways: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by the Corresponding Source fixed on a durable physical medium customarily used for software interchange. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by a written offer, valid for at least three years and valid for as long as you offer spare parts or customer support for that product model, to give anyone who possesses the object code either (1) a copy of the Corresponding Source for all the software in the product that is covered by this License, on a durable physical medium customarily used for software interchange, for a price no more than your reasonable cost of physically performing this conveying of source, or (2) access to copy the Corresponding Source from a network server at no charge. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Convey individual copies of the object code with a copy of the written offer to provide the Corresponding Source. This alternative is allowed only occasionally and noncommercially, and only if you received the object code with such an offer, in accord with subsection 6b. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Convey the object code by offering access from a designated place (gratis or for a charge), and offer equivalent access to the Corresponding Source in the same way through the same place at no further charge. You need not require recipients to copy the Corresponding Source along with the object code. If the place to copy the object code is a network server, the Corresponding Source may be on a different server (operated by you or a third party) that supports equivalent copying facilities, provided you maintain clear directions next to the object code saying where to find the Corresponding Source. Regardless of what server hosts the Corresponding Source, you remain obligated to ensure that it is available for as long as needed to satisfy these requirements. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Convey the object code using peer-to-peer transmission, provided you inform other peers where the object code and Corresponding Source of the work are being offered to the general public at no charge under subsection 6d. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A separable portion of the object code, whose source code is excluded from the Corresponding Source as a System Library, need not be included in conveying the object code work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “User Product” is either (1) a “consumer product”, which means any tangible personal property which is normally used for personal, family, or household purposes, or (2) anything designed or sold for incorporation into a dwelling. In determining whether a product is a consumer product, doubtful cases shall be resolved in favor of coverage. For a particular product received by a particular user, “normally used” refers to a typical or common use of that class of product, regardless of the status of the particular user or of the way in which the particular user actually uses, or expects or is expected to use, the product. A product is a consumer product regardless of whether the product has substantial commercial, industrial or non-consumer uses, unless such uses represent the only significant mode of use of the product. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Installation Information” for a User Product means any methods, procedures, authorization keys, or other information required to install and execute modified versions of a covered work in that User Product from a modified version of its Corresponding Source. The information must suffice to ensure that the continued functioning of the modified object code is in no case prevented or interfered with solely because modification has been made. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you convey an object code work under this section in, or with, or specifically for use in, a User Product, and the conveying occurs as part of a transaction in which the right of possession and use of the User Product is transferred to the recipient in perpetuity or for a fixed term (regardless of how the transaction is characterized), the Corresponding Source conveyed under this section must be accompanied by the Installation Information. But this requirement does not apply if neither you nor any third party retains the ability to install modified object code on the User Product (for example, the work has been installed in ROM). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The requirement to provide Installation Information does not include a requirement to continue to provide support service, warranty, or updates for a work that has been modified or installed by the recipient, or for the User Product in which it has been modified or installed. Access to a network may be denied when the modification itself materially and adversely affects the operation of the network or violates the rules and protocols for communication across the network. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Corresponding Source conveyed, and Installation Information provided, in accord with this section must be in a format that is publicly documented (and with an implementation available to the public in source code form), and must require no special password or key for unpacking, reading or copying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section7&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;7&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Additional Terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Additional permissions” are terms that supplement the terms of this License by making exceptions from one or more of its conditions. Additional permissions that are applicable to the entire Program shall be treated as though they were included in this License, to the extent that they are valid under applicable law. If additional permissions apply only to part of the Program, that part may be used separately under those permissions, but the entire Program remains governed by this License without regard to the additional permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When you convey a copy of a covered work, you may at your option remove any additional permissions from that copy, or from any part of it. (Additional permissions may be written to require their own removal in certain cases when you modify the work.) You may place additional permissions on material, added by you to a covered work, for which you have or can give appropriate copyright permission. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, for material you add to a covered work, you may (if authorized by the copyright holders of that material) supplement the terms of this License with terms: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Disclaiming warranty or limiting liability differently from the terms of sections 15 and 16 of this License; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Requiring preservation of specified reasonable legal notices or author attributions in that material or in the Appropriate Legal Notices displayed by works containing it; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Prohibiting misrepresentation of the origin of that material, or requiring that modified versions of such material be marked in reasonable ways as different from the original version; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Limiting the use for publicity purposes of names of licensors or authors of the material; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Declining to grant rights under trademark law for use of some trade names, trademarks, or service marks; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;f) Requiring indemnification of licensors and authors of that material by anyone who conveys the material (or modified versions of it) with contractual assumptions of liability to the recipient, for any liability that these contractual assumptions directly impose on those licensors and authors. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;All other non-permissive additional terms are considered “further restrictions” within the meaning of section 10. If the Program as you received it, or any part of it, contains a notice stating that it is governed by this License along with a term that is a further restriction, you may remove that term. If a license document contains a further restriction but permits relicensing or conveying under this License, you may add to a covered work material governed by the terms of that license document, provided that the further restriction does not survive such relicensing or conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you add terms to a covered work in accord with this section, you must place, in the relevant source files, a statement of the additional terms that apply to those files, or a notice indicating where to find the applicable terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Additional terms, permissive or non-permissive, may be stated in the form of a separately written license, or stated as exceptions; the above requirements apply either way. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section8&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;8&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Termination. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may not propagate or modify a covered work except as expressly provided under this License. Any attempt otherwise to propagate or modify it is void, and will automatically terminate your rights under this License (including any patent licenses granted under the third paragraph of section 11). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, you do not qualify to receive new licenses for the same material under section 10. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section9&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;9&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Acceptance Not Required for Having Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You are not required to accept this License in order to receive or run a copy of the Program. Ancillary propagation of a covered work occurring solely as a consequence of using peer-to-peer transmission to receive a copy likewise does not require acceptance. However, nothing other than this License grants you permission to propagate or modify any covered work. These actions infringe copyright if you do not accept this License. Therefore, by modifying or propagating a covered work, you indicate your acceptance of this License to do so. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section10&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;0. Automatic Licensing of Downstream Recipients. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each time you convey a covered work, the recipient automatically receives a license from the original licensors, to run, modify and propagate that work, subject to this License. You are not responsible for enforcing compliance by third parties with this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;An “entity transaction” is a transaction transferring control of an organization, or substantially all assets of one, or subdividing an organization, or merging organizations. If propagation of a covered work results from an entity transaction, each party to that transaction who receives a copy of the work also receives whatever licenses to the work the party&apos;s predecessor in interest had or could give under the previous paragraph, plus a right to possession of the Corresponding Source of the work from the predecessor in interest, if the predecessor has it or can get it with reasonable efforts. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may not impose any further restrictions on the exercise of the rights granted or affirmed under this License. For example, you may not impose a license fee, royalty, or other charge for exercise of rights granted under this License, and you may not initiate litigation (including a cross-claim or counterclaim in a lawsuit) alleging that any patent claim is infringed by making, using, selling, offering for sale, or importing the Program or any portion of it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section11&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1. Patents. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “contributor” is a copyright holder who authorizes use under this License of the Program or a work on which the Program is based. The work thus licensed is called the contributor&apos;s “contributor version”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A contributor&apos;s “essential patent claims” are all patent claims owned or controlled by the contributor, whether already acquired or hereafter acquired, that would be infringed by some manner, permitted by this License, of making, using, or selling its contributor version, but do not include claims that would be infringed only as a consequence of further modification of the contributor version. For purposes of this definition, “control” includes the right to grant patent sublicenses in a manner consistent with the requirements of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each contributor grants you a non-exclusive, worldwide, royalty-free patent license under the contributor&apos;s essential patent claims, to make, use, sell, offer for sale, import and otherwise run, modify and propagate the contents of its contributor version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;In the following three paragraphs, a “patent license” is any express agreement or commitment, however denominated, not to enforce a patent (such as an express permission to practice a patent or covenant not to sue for patent infringement). To “grant” such a patent license to a party means to make such an agreement or commitment not to enforce a patent against the party. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you convey a covered work, knowingly relying on a patent license, and the Corresponding Source of the work is not available for anyone to copy, free of charge and under the terms of this License, through a publicly available network server or other readily accessible means, then you must either (1) cause the Corresponding Source to be so available, or (2) arrange to deprive yourself of the benefit of the patent license for this particular work, or (3) arrange, in a manner consistent with the requirements of this License, to extend the patent license to downstream recipients. “Knowingly relying” means you have actual knowledge that, but for the patent license, your conveying the covered work in a country, or your recipient&apos;s use of the covered work in a country, would infringe one or more identifiable patents in that country that you have reason to believe are valid. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If, pursuant to or in connection with a single transaction or arrangement, you convey, or propagate by procuring conveyance of, a covered work, and grant a patent license to some of the parties receiving the covered work authorizing them to use, propagate, modify or convey a specific copy of the covered work, then the patent license you grant is automatically extended to all recipients of the covered work and works based on it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A patent license is “discriminatory” if it does not include within the scope of its coverage, prohibits the exercise of, or is conditioned on the non-exercise of one or more of the rights that are specifically granted under this License. You may not convey a covered work if you are a party to an arrangement with a third party that is in the business of distributing software, under which you make payment to the third party based on the extent of your activity of conveying the work, and under which the third party grants, to any of the parties who would receive the covered work from you, a discriminatory patent license (a) in connection with copies of the covered work conveyed by you (or copies made from those copies), or (b) primarily for and in connection with specific products or compilations that contain the covered work, unless you entered into that arrangement, or that patent license was granted, prior to 28 March 2007. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Nothing in this License shall be construed as excluding or limiting any implied license or other defenses to infringement that may otherwise be available to you under applicable patent law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section12&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;2. No Surrender of Others&apos; Freedom. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot convey a covered work so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not convey it at all. For example, if you agree to terms that obligate you to collect a royalty for further conveying from those to whom you convey the Program, the only way you could satisfy both those terms and this License would be to refrain entirely from conveying the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section13&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;3. Use with the GNU Affero General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, you have permission to link or combine any covered work with a work licensed under version 3 of the GNU Affero General Public License into a single combined work, and to convey the resulting work. The terms of this License will continue to apply to the part which is the covered work, but the special requirements of the GNU Affero General Public License, section 13, concerning interaction through a network will apply to the combination as such. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section14&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;4. Revised Versions of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Free Software Foundation may publish revised and/or new versions of the GNU General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each version is given a distinguishing version number. If the Program specifies that a certain numbered version of the GNU General Public License “or any later version” applies to it, you have the option of following the terms and conditions either of that numbered version or of any later version published by the Free Software Foundation. If the Program does not specify a version number of the GNU General Public License, you may choose any version ever published by the Free Software Foundation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the Program specifies that a proxy can decide which future versions of the GNU General Public License can be used, that proxy&apos;s public statement of acceptance of a version permanently authorizes you to choose that version for the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Later license versions may give you additional or different permissions. However, no additional obligations are imposed on any author or copyright holder as a result of your choosing to follow a later version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section15&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;5. Disclaimer of Warranty. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section16&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;6. Limitation of Liability. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section17&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;7. Interpretation of Sections 15 and 16. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the disclaimer of warranty and limitation of liability provided above cannot be given local legal effect according to their terms, reviewing courts shall apply local law that most closely approximates an absolute waiver of all civil liability in connection with the Program, unless a warranty or assumption of liability accompanies a copy of the Program in return for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;END OF TERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;howto&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;ow to Apply These Terms to Your New Programs &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you develop a new program, and you want it to be of the greatest possible use to the public, the best way to achieve this is to make it free software which everyone can redistribute and change under these terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To do so, attach the following notices to the program. It is safest to attach them to the start of each source file to most effectively state the exclusion of warranty; and each file should have at least the “copyright” line and a pointer to where the full notice is found. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;one line to give the program&apos;s name and a brief idea of what it does.&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is free software: you can redistribute it and/or modify&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    it under the terms of the GNU General Public License as published by&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    the Free Software Foundation, either version 3 of the License, or&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is distributed in the hope that it will be useful,&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    GNU General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    You should have received a copy of the GNU General Public License&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    along with this program.  If not, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Also add information on how to contact you by electronic and paper mail. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the program does terminal interaction, make it output a short notice like this when it starts in an interactive mode: &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;program&amp;gt;  Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This is free software, and you are welcome to redistribute it&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    under certain conditions; type `show c&apos; for details. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate parts of the General Public License. Of course, your program&apos;s commands might be different; for a GUI interface, you would use an “about box”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You should also get your employer (if you work as a programmer) or school, if any, to sign a “copyright disclaimer” for the program, if necessary. For more information on this, and how to apply and follow the GNU GPL, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The GNU General Public License does not permit incorporating your program into proprietary programs. If your program is a subroutine library, you may consider it more useful to permit linking proprietary applications with the library. If this is what you want to do, use the GNU Lesser General Public License instead of this License. But first, please read &amp;lt;http://www.gnu.org/philosophy/why-not-lgpl.htm&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The cd/dvd image manipulator for linux&lt;br /&gt;is created by:&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Current: &lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-style:italic;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Previous 2006-2009:&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;&lt;br /&gt;Fabrizio Di Marco&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;AcetoneISO Subversion&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;xx/11/2010&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;Translators:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Italian: Original Authors&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Czech: Hanz&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Russian: Arseniy Muravyev&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Polish: Jarek&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Romanian: Aparaschivei Florin&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Hungarian: Sandor Lisovszki&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;German: Johannes Obermayr&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;Special Thanks goes to:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All the people that made a donation!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All package mantainers.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All people that submitted bug-reports, patches and suggestions.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Irc #qt channel on irc.freenode.net for all their help on C++ and Qt4&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Trolltech for releasing such a wonderful framework, Qt4!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All the open source tools AcetoneISO uses, this includes: fuseiso, mencoder, mplayer, mencoder, dd, cdrdao, wodim, growisofs, youtube-dl, 7z, ffmpeg, gnupg, dvd+r-format and more!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;And finally... a big thanks goes to You for using our software!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Thanks to all of You,&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;The AcetoneISO Team&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>acetoneiso</name>
    <message>
        <source>AcetoneISO2</source>
        <translation type="obsolete">AcetoneISO2</translation>
    </message>
    <message>
        <source>mount</source>
        <translation>Připojit</translation>
    </message>
    <message>
        <source>Double click an image to browse</source>
        <translation type="obsolete">Dvojklik pro vyhledání Image</translation>
    </message>
    <message>
        <source>Click a mounted iso on the Display and then unmount</source>
        <translation type="obsolete">Nejdříve klikněte na připojené ISO a potom odpojit</translation>
    </message>
    <message>
        <source>unmount</source>
        <translation>Odpojit</translation>
    </message>
    <message>
        <source>database</source>
        <translation>Databáze</translation>
    </message>
    <message>
        <source>Double click to mount image</source>
        <translation type="obsolete">Dvojklik pro připojení Image</translation>
    </message>
    <message>
        <source>set database</source>
        <translation type="obsolete">sestavit databázi</translation>
    </message>
    <message>
        <source>Click an image on the DB and then &quot;delete image&quot;</source>
        <translation type="obsolete">Nejdříve klikněte na Image v databázi a poté &apos;&apos;smazat Image&apos;&apos;</translation>
    </message>
    <message>
        <source>delete image</source>
        <translation type="obsolete">Smazat</translation>
    </message>
    <message>
        <source>Click here to update  your Database</source>
        <translation type="obsolete">Klikněte sem pro aktualizaci vaší databáze</translation>
    </message>
    <message>
        <source>update DB</source>
        <translation type="obsolete">Aktualizace DB</translation>
    </message>
    <message>
        <source>play</source>
        <translation type="obsolete">Přehrát</translation>
    </message>
    <message>
        <source>Play DVD-Movie ISO</source>
        <translation type="obsolete">Přehrát filmové DVD ISO</translation>
    </message>
    <message>
        <source>umount DVD-Movie</source>
        <translation type="obsolete">Odpojit filmové DVD</translation>
    </message>
    <message>
        <source>Backup CD-Audio</source>
        <translation>Zálohovat audio CD</translation>
    </message>
    <message>
        <source>Md5-Sum</source>
        <translation type="obsolete">Součet Md5</translation>
    </message>
    <message>
        <source>help</source>
        <translation type="obsolete">Nápověda</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Ukončit</translation>
    </message>
    <message>
        <source>Set Database</source>
        <translation>Sestavit databázi</translation>
    </message>
    <message>
        <source>Image Info</source>
        <translation>Informace o image</translation>
    </message>
    <message>
        <source>Extract Boot Image</source>
        <translation>Extrahovat BOOT Image</translation>
    </message>
    <message>
        <source>Generate to file</source>
        <translation>Generovat do souboru</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Kontrolovat</translation>
    </message>
    <message>
        <source>DOS Boot</source>
        <translation>DOS Boot</translation>
    </message>
    <message>
        <source>Generic Floppy-Emulation</source>
        <translation>Generic Floppy-Emulation</translation>
    </message>
    <message>
        <source>Generic No-Emulation</source>
        <translation>Generic No-Emulation</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuál</translation>
    </message>
    <message>
        <source>About</source>
        <translation>O Aplikaci</translation>
    </message>
    <message>
        <source>umount</source>
        <translation>Odpojit</translation>
    </message>
    <message>
        <source>To CD</source>
        <translation>na CD</translation>
    </message>
    <message>
        <source>To DvD</source>
        <translation>na DVD</translation>
    </message>
    <message>
        <source>Click to mount an ISO MDF NRG BIN IMG image</source>
        <translation type="obsolete">Kliknout pro připojení ISO MDF NRG BIN IMG Image</translation>
    </message>
    <message>
        <source>please make a small donation for development!</source>
        <translation type="obsolete">please make a small donation for development!</translation>
    </message>
    <message>
        <source>play your DVD image of a film</source>
        <translation type="obsolete">Přehrát Image filmového DVD</translation>
    </message>
    <message>
        <source>Convert MacOs Image</source>
        <translation>Převést MacOs Image</translation>
    </message>
    <message>
        <source>Loading GUI...</source>
        <translation type="obsolete">Nahrávám GUI...</translation>
    </message>
    <message>
        <source>Loading Options...</source>
        <translation type="obsolete">Nahrávám nastavení...</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save BIN Audio file</source>
        <translation type="obsolete">AcetoneISO::Uložit BIN Audio soubor</translation>
    </message>
    <message>
        <source>Images (*.bin)</source>
        <translation>Images (*.bin)</translation>
    </message>
    <message>
        <source>no cdrdao found in /usr/bin</source>
        <translation>cdrdao nenalezen v /usr/bin</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to compress</source>
        <translation type="obsolete">AcetoneISO2::Vyberte Image pro komprimaci</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</source>
        <translation>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Compressed Image</source>
        <translation type="obsolete">AcetoneISO2::Uložit komprimovaný Image</translation>
    </message>
    <message>
        <source>Images (*.7z)</source>
        <translation>Images (*.7z)</translation>
    </message>
    <message>
        <source>Do You want to compress in Ultra High mode? (very slow)</source>
        <translation>Chcete komprimovat v Ultra High mode? (velmi pomalé)</translation>
    </message>
    <message>
        <source>no 7z found in /usr/bin</source>
        <translation>7z nenalezen v /usr/bin</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Otevřít Image</translation>
    </message>
    <message>
        <source>Image Files (*.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</source>
        <translation type="obsolete">Image Files (*.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save ISO file</source>
        <translation type="obsolete">AcetoneISO2::Uložit ISO soubor</translation>
    </message>
    <message>
        <source>Images (*.iso)</source>
        <translation>Images (*.iso)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Database Folder</source>
        <translation type="obsolete">AcetoneISO2::Zvolit adresář s databází</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to decrypt</source>
        <translation type="obsolete">AcetoneISO2::Vyberte Image pro dekódování</translation>
    </message>
    <message>
        <source>Encrypted Image ( *.gpg)</source>
        <translation>Kódovaný Image ( *.gpg)</translation>
    </message>
    <message>
        <source>Please be sure to have mkisofs installed in /usr/bin </source>
        <translation type="obsolete">Prosím ujistěte se že máte nainstalováno mkisofs v /usr/bin</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder to transform in a bootable ISO</source>
        <translation type="obsolete">AcetoneISO2::Vyberte adresář pro transformaci v bootovatelném ISO</translation>
    </message>
    <message>
        <source>Select Boot File</source>
        <translation type="obsolete">Zvolit BOOT soubor</translation>
    </message>
    <message>
        <source>Select Boot File Type:</source>
        <translation type="obsolete">Zvolit typ BOOT souboru:</translation>
    </message>
    <message>
        <source>GRUB</source>
        <translation type="obsolete">GRUB</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to encrypt</source>
        <translation type="obsolete">AcetoneISO2::Vyberte Image pro kódování</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select where to extract image</source>
        <translation type="obsolete">AcetoneISO::Určete kam extrahovat Image</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder to be Converted</source>
        <translation type="obsolete">AcetoneISO2::Vybete adresář pro převod</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save ISO</source>
        <translation type="obsolete">AcetoneISO2::Uložit ISO</translation>
    </message>
    <message>
        <source>ISO ID</source>
        <translation>ISO ID</translation>
    </message>
    <message>
        <source>Please insert an ID for the ISO</source>
        <translation>Prosím zadejte ID pro ISO</translation>
    </message>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>no mkisofs found in /usr/bin</source>
        <translation type="obsolete">mkisofs nenalezen v /usr/bin</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select *bin or *img</source>
        <translation type="obsolete">AcetoneISO2::Vyberte *bin nebo *img</translation>
    </message>
    <message>
        <source>Image Files (*.bin *.img)</source>
        <translation>Image Files (*.bin *.img)</translation>
    </message>
    <message>
        <source>Select from where to extract Boot Image:</source>
        <translation>Určete odkud extrahovat Boot Image:</translation>
    </message>
    <message>
        <source>ISO File</source>
        <translation>ISO soubor</translation>
    </message>
    <message>
        <source>CD/DVD</source>
        <translation>CD/DVD</translation>
    </message>
    <message>
        <source>Image Files (*.iso)</source>
        <translation>Image Files (*.iso)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save boot image</source>
        <translation>AcetoneISO2::Uložit BOOT image</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.nrg *.bin *.img *.mdf)</source>
        <translation type="obsolete">Image Files (*.iso *.nrg *.bin *.img *.mdf)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select where to mount image</source>
        <translation type="obsolete">AcetoneISO::Určete kam připojit Image</translation>
    </message>
    <message>
        <source>The folder </source>
        <translation>Adresář</translation>
    </message>
    <message>
        <source> can&apos;t be mounted</source>
        <translation>Nemůže být připojen</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select folder to unmount</source>
        <translation type="obsolete">AcetoneISO2::Vyberte adresář pro odpojení</translation>
    </message>
    <message>
        <source> is not mounted!</source>
        <translation>Nepřipojeno!</translation>
    </message>
    <message>
        <source>Please note that this tool only works for normal DATA CD/DVD.
 It won&apos;t work with Audio CD and Game CopyProtected cd&apos;s</source>
        <translation type="obsolete">Mějte na paměti, že tento nástroj funguje pouze pro běžné datové CD / DVD.
 Nepracuje s audio CD a herními CD chráněnými proti kopírování</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image</source>
        <translation type="obsolete">AcetoneISO2::Zvolit Image</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Md5 text file</source>
        <translation type="obsolete">AcetoneISO2::Uložit Md5 do txt souboru</translation>
    </message>
    <message>
        <source>Md5 (*.md5)</source>
        <translation>Md5 (*.md5)</translation>
    </message>
    <message>
        <source>All Virtual Drives are busy,
Unmount some Virtual Drive first!</source>
        <translation>Všechny Virtuální mechaniky jsou obsazeny,
Odpojte některou Virtuální mechaniku!</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Parts</source>
        <translation type="obsolete">AcetoneISO2::Zvolit části</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save merged image</source>
        <translation type="obsolete">AcetoneISO2::Uložit spojený Image</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation>Proces zdárně dokončen!</translation>
    </message>
    <message>
        <source>Operation succesfully finished!</source>
        <translation>Operace zdárně dokončena!</translation>
    </message>
    <message>
        <source>Operation succesfully finished!
To mount the converted file, open a terminal and run as root:
modprobe hfsplus
mount -t hfsplus -o loop &lt;converted-image.img&gt; /folder_you_want</source>
        <translation>Operace zdárně dokončena!
Pro připojení převedeného souboru, spusťte terminál pod root:
modprobe hfsplus
mount -t hfsplus -o loop &lt;prevedeny_soubor.img&gt; /adresar_kam_pripojit</translation>
    </message>
    <message>
        <source>Image succesfully merged</source>
        <translation>Image zdárně spojen</translation>
    </message>
    <message>
        <source>Select DVD-Movie to Play</source>
        <translation>Vyberte filmové DVD pro přehrání</translation>
    </message>
    <message>
        <source>DVD-Movie Image (*.iso *.bin *.img *.mdf *.nrg)</source>
        <translation>DVD-Movie Image (*.iso *.bin *.img *.mdf *.nrg)</translation>
    </message>
    <message>
        <source> mounted</source>
        <translation type="obsolete">Přpojeno</translation>
    </message>
    <message>
        <source>Without Poweriso some functions will be unavailable!</source>
        <translation type="obsolete">Některé funkce nebudou bez PowerISO dostupné!</translation>
    </message>
    <message>
        <source>Poweriso downloaded and extracted!</source>
        <translation>Poweriso stažen a rozbalen!</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save BIN file</source>
        <translation type="obsolete">AcetoneISO2::Uložit BIN soubor</translation>
    </message>
    <message>
        <source>select an image to delete</source>
        <translation>vyberte image pro smazazání</translation>
    </message>
    <message>
        <source>Open Image to be splitted</source>
        <translation>Otevřít Image pro rozdělení</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder where the image will be splitted</source>
        <translation type="obsolete">AcetoneISO::Určete kam rozdělit Image</translation>
    </message>
    <message>
        <source>AcetoneISO2::Split number</source>
        <translation type="obsolete">AcetoneISO2::Počet částí</translation>
    </message>
    <message>
        <source>Please insert the split number in MegaByte:</source>
        <translation type="obsolete">Vložte velikost v MB:</translation>
    </message>
    <message>
        <source>no split file found in /usr/bin</source>
        <translation type="obsolete">split nenalezen v /usr/bin</translation>
    </message>
    <message>
        <source>DVD-Movie </source>
        <translation type="obsolete">Filmové DVD</translation>
    </message>
    <message>
        <source>select an image to unmount from the virtual-drives display</source>
        <translation>Vyberte Image pro odpojení z virtuální mechaniky</translation>
    </message>
    <message>
        <source>Open Compressed Image</source>
        <translation>Otevřít zabalený Image</translation>
    </message>
    <message>
        <source>Image Files (*.7z)</source>
        <translation>Image Files (*.7z)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder where the uncompressed Image will be saved</source>
        <translation type="obsolete">AcetoneISO2::Určete adresář pro uložení rozbaleného Image</translation>
    </message>
    <message>
        <source>no 7z found in /usr/bin, please install p7zip-full package</source>
        <translation>7z nenalezen v /usr/bin, nainstalujte balíček p7zip</translation>
    </message>
    <message>
        <source>to donate go here: http://www.acetoneiso.netsons.org/viewpage.php?page_id=10</source>
        <translation type="obsolete">to donate go here: http://www.acetoneiso.netsons.org/viewpage.php?page_id=10</translation>
    </message>
    <message>
        <source>for the manual go here: http://www.acetoneiso.netsons.org/viewpage.php?page_id=4</source>
        <translation type="obsolete">stránka s manuálem: http://www.acetoneiso.netsons.org/viewpage.php?page_id=4</translation>
    </message>
    <message>
        <source>Manual Umount</source>
        <translation>Ruční odpojení</translation>
    </message>
    <message>
        <source>Click to save the dvd cover</source>
        <translation type="obsolete">Klikněte pro uložení DVD obalu</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Soubor</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation type="obsolete">Nástroje</translation>
    </message>
    <message>
        <source>Split Image</source>
        <translation type="obsolete">Rozdělit Image</translation>
    </message>
    <message>
        <source>Encrypt Image</source>
        <translation>Kódovat Image</translation>
    </message>
    <message>
        <source>Mount in a specified folder</source>
        <translation>Připojit do určitého adresáře</translation>
    </message>
    <message>
        <source>Compress Image</source>
        <translation>Zabalit Image</translation>
    </message>
    <message>
        <source>Conversion</source>
        <translation type="obsolete">Převod</translation>
    </message>
    <message>
        <source>MS-DOS Boot</source>
        <translation>MS-DOS Boot</translation>
    </message>
    <message>
        <source>Convert Image to ISO</source>
        <translation>Převést Image do ISO</translation>
    </message>
    <message>
        <source>Generate ISO from CD/DVD</source>
        <translation type="obsolete">Vytvořit ISO z CD/DVD</translation>
    </message>
    <message>
        <source>Generate ISO from folder</source>
        <translation>Vytvořit ISO z adresáře</translation>
    </message>
    <message>
        <source>Rip a PSX1 game for epsxe/psx emulators</source>
        <translation>Ripovat PSX1 hru pro epsxe/psx emulátory</translation>
    </message>
    <message>
        <source>Split</source>
        <translation>Rozdělit</translation>
    </message>
    <message>
        <source>Merge Splitted Image</source>
        <translation>Spojit rozdělený Image</translation>
    </message>
    <message>
        <source>Encrypt</source>
        <translation>Kódovat</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>Odkódovat</translation>
    </message>
    <message>
        <source>Mount</source>
        <translation>Připojit</translation>
    </message>
    <message>
        <source>Unmount</source>
        <translation>Odpojit</translation>
    </message>
    <message>
        <source>Extract Image Content to a folder</source>
        <translation>Extrahovat obsah Image do adresáře</translation>
    </message>
    <message>
        <source>Compress</source>
        <translation>Zabalit</translation>
    </message>
    <message>
        <source>Uncompress</source>
        <translation>Rozbalit</translation>
    </message>
    <message>
        <source>Generate Cue for BIN/IMG images</source>
        <translation>Vytvořit Cue z BIN/IMG Image</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg)</source>
        <translation>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg)</translation>
    </message>
    <message>
        <source>Image Files (*.dmg)</source>
        <translation>Image Files (*.dmg)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save DVD Cover</source>
        <translation type="obsolete">AcetoneISO2::Uložit DVD obal</translation>
    </message>
    <message>
        <source>Images (*.jpg)</source>
        <translation type="obsolete">Obrázky (*.jpg)</translation>
    </message>
    <message>
        <source>Boot</source>
        <translation>Boot</translation>
    </message>
    <message>
        <source>Please note this utility will generate a BIN image which could not be mounted or read in any way . 
However You can burn it later with cdrdao command from terminal.</source>
        <translation type="obsolete">Vezměte prosím na vědomí že tento nástroj vytváří BIN Image, které nelze připojit ani přečíst. 
Nicméně je můžete později vypálit pomocí příkazu cdrdao z terminálu.</translation>
    </message>
    <message>
        <source>NOTE: If you want to mount an image in a root folder like /media/cdrom, please launch AcetoneISO2 as root user. </source>
        <translation type="obsolete">POZNÁMKA: Pokud chcete připojit Image v kořenovém adresáři, jako je /media/cdrom, spusťte prosím AcetoneISO2 jako root.</translation>
    </message>
    <message>
        <source>Error, could not mount image.

Solution:
http://acetoneiso2.svn.sourceforge.net/viewvc/*checkout*/acetoneiso2/src/manual/manual.html</source>
        <translation type="obsolete">Chyba, nemohu připojit Image.

Řešení:
http://acetoneiso2.svn.sourceforge.net/viewvc/*checkout*/acetoneiso2/src/manual/manual.html</translation>
    </message>
    <message>
        <source>Do you want to download Poweriso?
If you click yes you accept PowerISO&apos;s Freeware Licence.
Remember: if you are running a 64-bit OS, you need libc6-i386 package and maybe others installed.</source>
        <translation type="obsolete">Chcete stáhnout Poweriso?
Pokud kliklente na Ano, sohlasíte s Freeware licencí Poweriso.
Pamatujte: pokud používáte 64-bit OS, potřebujete mít nainstalovaný balíček libc6-i386.</translation>
    </message>
    <message>
        <source>Please Unmount the movie first</source>
        <translation>Prosím odpojte nejdříve film</translation>
    </message>
    <message>
        <source>Choose a method to play the movie.
Method 1 generally works, if it doesn&apos;t try Method 2.</source>
        <translation>Vyberte metodu pro přehrání filmu.
Metoda 1 obecně funguje, pokud ne zkuste Metodu 2.</translation>
    </message>
    <message>
        <source>Method 1</source>
        <translation>Metoda 1</translation>
    </message>
    <message>
        <source>Method 2</source>
        <translation>Metoda 2</translation>
    </message>
    <message>
        <source>
This is error is mostly because the image you are trying to convert is already ISO-9660.
To check, open a terminal and type: file nameimage.xxx
If it is already ISO-9660, there is no need to convert it. Simply Extract it or Mount with AcetoneISO2.</source>
        <translation type="obsolete">
Tato chyba je většinou způsobena pokusem převést Image který je již ISO-9660.
Pro kontrolu otevřete terminál a napište: file nameimage.xxx
Pokud je ISO-9660, nepotřebuje převádět. Jednoduše přpojte nebo extrahujte.</translation>
    </message>
    <message>
        <source>Mount UDF ISO</source>
        <translation>Připojit UDF ISO</translation>
    </message>
    <message>
        <source>UDF ISO are particular images that hold files bigger than 2GB.
This utility will load the udf module and mount the ISO.
Please note that administrator password is required.</source>
        <translation type="obsolete">UDF ISO jsou Image které obsahují soubory větší než 2GB.
Tento nástroj tyto Image umožňuje připojit.
Upozorňujeme, že je vyžadováno heslo správce.</translation>
    </message>
    <message>
        <source>Video!</source>
        <translation type="obsolete">Video!</translation>
    </message>
    <message>
        <source>Convert FLV 2 AVI</source>
        <translation>Převést FLV na AVI</translation>
    </message>
    <message>
        <source>Please be sure the DVD disc is inserted in device and then press OK.</source>
        <translation>Ujistěte se že jste vložili DVD disk do mechaniky a stiskněte OK.</translation>
    </message>
    <message>
        <source>Encoding Pass 1 has succesfully finished.
Pass 2 will be done now. Please choose the bitrate in the next dialog and then choose where to save the video.</source>
        <translation>Kódování Pass 1 dokončeno.
Pass 2 bude následně dokončeno. Vybete datový tok videa a poté kam uložit video.</translation>
    </message>
    <message>
        <source>AcetoneISO2::Bitrate</source>
        <translation type="obsolete">AcetoneISO2::Datový tok</translation>
    </message>
    <message>
        <source>Please insert Bitrate. Higher bitrate means more quality but will generate a bigger file.</source>
        <translation>Zadejte datový tok. Vyšší znamená větší kvalitu a větší velikost souboru.</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Video file</source>
        <translation type="obsolete">AcetoneISO::Uložit video soubor</translation>
    </message>
    <message>
        <source>Video (*.avi)</source>
        <translation>Video (*.avi)</translation>
    </message>
    <message>
        <source>Select Video</source>
        <translation>Zvolit video</translation>
    </message>
    <message>
        <source>AcetoneISO2::Fixed Quant</source>
        <translation type="obsolete">AcetoneISO2::Fixovaná velikost</translation>
    </message>
    <message>
        <source>Please insert the Fixed Quant number.
Lowering the number will result in a higher quality video.</source>
        <translation>Zadejte pevné číslo velikosti.
Snížení počtu povede k vyšší kvalitě videa.</translation>
    </message>
    <message>
        <source>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf )</source>
        <translation type="obsolete">Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf )</translation>
    </message>
    <message>
        <source>Convert generic video 2 Xvid AVI</source>
        <translation>Obecný převod videa na Xvid AVI</translation>
    </message>
    <message>
        <source>Rip DVD 2 Xvid AVI</source>
        <translation>Ripovat DVD na Xvid AVI</translation>
    </message>
    <message>
        <source>Select FLV Video</source>
        <translation>Zvolit FLV video</translation>
    </message>
    <message>
        <source>Video Files (*.flv )</source>
        <translation>Video Files (*.flv )</translation>
    </message>
    <message>
        <source>An error has occured.
Please try converting the FLV video with Convert generic video to Xvid AVI feature</source>
        <translation>Došlo k chybě.
Zkuste prosím převést FLV videa s funkcí Obecný převod Xvid AVI</translation>
    </message>
    <message>
        <source>YouTube Download Video</source>
        <translation>YouTube Stáhnout Video</translation>
    </message>
    <message>
        <source>AcetoneISO2::YouTube</source>
        <translation type="obsolete">AcetoneISO2::YouTube</translation>
    </message>
    <message>
        <source>Insert YouTube&apos;s URL:
Note: YouTube&apos;s server is often very slow, big files can require a lot of time to download!</source>
        <translation>Zadejte YouTube URL:
Poznámka: YouTube je často velmi pomalý, velké soubory potřebují více času na stahování!</translation>
    </message>
    <message>
        <source>Video (*.flv)</source>
        <translation>Video (*.flv)</translation>
    </message>
    <message>
        <source>An error occurred while unmounting.
The image has been unmounted but you must close and reopen AcetoneISO2 to mount a new image.</source>
        <translation type="obsolete">Vyskytla se chyba během odpojování.
Image byl odpojen, ale musíte vypnout a zapnout AcetoneISO2 pro připojení nového Image.</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Soubor</translation>
    </message>
    <message>
        <source>&amp;Utilities</source>
        <translation>&amp;Nástroje</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Nápo&amp;věda</translation>
    </message>
    <message>
        <source>Generate ISO from CD/DVD and it is:</source>
        <translation>Vytvořit ISO z CD/DVD:</translation>
    </message>
    <message>
        <source>Play DVD image</source>
        <translation>Přehrát DVD Image</translation>
    </message>
    <message>
        <source>&amp;Exit</source>
        <translation type="obsolete">&amp;Ukončit</translation>
    </message>
    <message>
        <source>O&amp;ptions</source>
        <translation>N&amp;astavení</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Otevřít</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Přehrát</translation>
    </message>
    <message>
        <source>Umount</source>
        <translation type="obsolete">Odpojit</translation>
    </message>
    <message>
        <source>Donate</source>
        <translation>Darovat</translation>
    </message>
    <message>
        <source>Anonymous Login</source>
        <translation>Anonymní přihlášení</translation>
    </message>
    <message>
        <source>User Account Login</source>
        <translation>Přihlášení uživatele</translation>
    </message>
    <message>
        <source>Burn CUE</source>
        <translation>Vypálit CUE</translation>
    </message>
    <message>
        <source>CD</source>
        <translation>CD</translation>
    </message>
    <message>
        <source>DVD</source>
        <translation>DVD</translation>
    </message>
    <message>
        <source>to CD</source>
        <translation>na CD</translation>
    </message>
    <message>
        <source>to DVD</source>
        <translation>na DVD</translation>
    </message>
    <message>
        <source>Burn TOC</source>
        <translation>Vypálit TOC</translation>
    </message>
    <message>
        <source>Copy a normal CD/DVD data</source>
        <translation>Kopírovat datové CD/DVD</translation>
    </message>
    <message>
        <source>Copy a CD Audio</source>
        <translation>Kopírovat audio CD</translation>
    </message>
    <message>
        <source>Copy a protected PC Game CD/DVD</source>
        <translation>Kopírovat chráněné herní CD/DVD</translation>
    </message>
    <message>
        <source>a standard data CD/DVD</source>
        <translation>standardní datové CD/DVD</translation>
    </message>
    <message>
        <source>a CD Audio</source>
        <translation>audio CD</translation>
    </message>
    <message>
        <source>a Playstation 1 Game</source>
        <translation>Playstation 1</translation>
    </message>
    <message>
        <source>a protected PC Game CD/DVD</source>
        <translation>chráněné herní CD/DVD</translation>
    </message>
    <message>
        <source>a DVD Video</source>
        <translation>DVD video</translation>
    </message>
    <message>
        <source>Copy a DVD Video</source>
        <translation>Kopírovat DVD video</translation>
    </message>
    <message>
        <source>Copy a Playstation 1 Game</source>
        <translation>Kopírovat hru Playstation 1</translation>
    </message>
    <message>
        <source>
Did you insert correct CD/DVD device?</source>
        <translation>
Vložili jste správné CD/DVD?</translation>
    </message>
    <message>
        <source>Without Poweriso you won&apos;t be able to convert and extract images to ISO or folders!</source>
        <translation>Bez Poweriso nebudete moci převést Image na ISO a extrahovat Image do adresáře!</translation>
    </message>
    <message>
        <source>
Please see the log file in   </source>
        <translation>Prosím podívejte se do log souboru v   </translation>
    </message>
    <message>
        <source>
If the log file says:&quot;No conversion is needed.&quot; then just rename the image to *.iso to mount, extract or burn it .</source>
        <translation type="obsolete">
Když je v log souboru uvedeno: &quot;Převod není potřeba.&quot; Pak stačí přejmenovat Image na *.iso a poté připojit rozbalit nebo vypálit .</translation>
    </message>
    <message>
        <source>You are about to delete </source>
        <translation>Chystáte se vymazat</translation>
    </message>
    <message>
        <source>
Are You sure?</source>
        <translation>
Jste si jisti?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ano</translation>
    </message>
    <message>
        <source>No way!</source>
        <translation>Ani nápad!</translation>
    </message>
    <message>
        <source>no genisoimage found in /usr/bin</source>
        <translation>genisoimage nenalezen v /usr/bin</translation>
    </message>
    <message>
        <source>The image </source>
        <translation>Image</translation>
    </message>
    <message>
        <source> can&apos;t be mounted. You must convert it to ISO or extract content to a folder.
Please choose what to do:</source>
        <translation>Nemůže být připojen. Musíte převést image na ISO nebo extrahovat do adresáře.
Co chcete udělat:</translation>
    </message>
    <message>
        <source> Convert to ISO </source>
        <translation>Převést na ISO</translation>
    </message>
    <message>
        <source> Extract image to a folder </source>
        <translation>Extrahovat Image do adresáře </translation>
    </message>
    <message>
        <source>Please insert the Byte Size.
Leaving default is the best solution!</source>
        <translation>Zadejte velikost v B.
Výchozí je nejlepší!</translation>
    </message>
    <message>
        <source>Please insert your YouTube&apos;s username</source>
        <translation>Zadejte uživatelské jméno na YouTube</translation>
    </message>
    <message>
        <source>your username</source>
        <translation>vaše uživatelské jméno</translation>
    </message>
    <message>
        <source>Please insert your YouTube&apos;s password</source>
        <translation>Zadejte heslo na YouTube</translation>
    </message>
    <message>
        <source>Select a format type:
Fast method is recommended.</source>
        <translation>Vyberte typ formátu:
rychlá metoda je doporučená.</translation>
    </message>
    <message>
        <source>Fast</source>
        <translation>Rychle</translation>
    </message>
    <message>
        <source>Complete</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <source>Please insert the erasing speed:</source>
        <translation>Zadejte rychlost vymazání:</translation>
    </message>
    <message>
        <source>Unable to unmount the CD/DVD device.
Be sure there is no process that is locking the device.
Please click on Cancel button in the next dialog.</source>
        <translation>Nemohu odpojit CD/DVD mechaniku.
Ujistěte že ji nepoužívá nějaký proces.
Klikněte na storno v dalším okně.</translation>
    </message>
    <message>
        <source>This utility will not do a 1:1 copy of your game! It will simply skip copyprotection errors.
You will need a no-cd fix cd/dvd to make the game work also known as crack.
Note: if the game is very old and uses a mixed data/audio file system, this utility won&apos;t work. Sorry :(</source>
        <translation>Tento nástroj nedělá 1:1 kopie vašich her! Přeskakuje chráněné oblasti.
Budete potřebovat crack.
Poznámka: Pokud je hra stará a používá kombinaci data/audio tak tento nástroj nebude fungovat. Sorry :(</translation>
    </message>
    <message>
        <source>Please specify your CD/DVD mount point. If you aren&apos;t sure just leave default.
Typical mount points are:
/media/cdrom or /media/cdrom0 or /media/cdrom1 and follow this symbolism.</source>
        <translation>Určete váš CD/DVD přípojný bod. Pokud si nejste jisti nechte výchozí.
Typické přípojné body jsou:
/media/cdrom nebo /media/cdrom0 nebo /media/cdrom1.</translation>
    </message>
    <message>
        <source>AcetoneISO</source>
        <translation>AcetoneISO</translation>
    </message>
    <message>
        <source>Real time updates from the net</source>
        <translation>Aktualizace z internetu</translation>
    </message>
    <message>
        <source>http://www.acetoneteam.org/clients.html</source>
        <translation>http://www.acetoneteam.org/clients.html</translation>
    </message>
    <message>
        <source>Double click an image to open in file manager</source>
        <translation type="obsolete">Dvojklikem otevřete Image ve správci souborů</translation>
    </message>
    <message>
        <source>Click to mount an image</source>
        <translation>Kliknout pro připojení Image</translation>
    </message>
    <message>
        <source>Click a mounted image on the display to unmount it</source>
        <translation>Na obrazovce klikněte na připojený Image a poté odpojit</translation>
    </message>
    <message>
        <source>&amp;Image Conversion</source>
        <translation>&amp;Převod Image</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <source>Archive Manager</source>
        <translation type="obsolete">Správce Archívů</translation>
    </message>
    <message>
        <source>Split Image in Volumes</source>
        <translation>Rozdělit Image</translation>
    </message>
    <message>
        <source>search:</source>
        <translation>hledat:</translation>
    </message>
    <message>
        <source>type a letter/s to filter the search</source>
        <translation>Napište text pro vyhledání</translation>
    </message>
    <message>
        <source>Double click to mount. Right click for context menu</source>
        <translation>Dvojklik pro připojení. Pravé tlačítko pro kontextové menu</translation>
    </message>
    <message>
        <source>select an image on display to delete</source>
        <translation>Vyberte Image pro smazání</translation>
    </message>
    <message>
        <source>Click to update  database&apos;s display</source>
        <translation>Klikněte pro aktualizaci databáze na obrazovce</translation>
    </message>
    <message>
        <source>PornoTube Download Video</source>
        <translation>PornoTube Stáhnout Video</translation>
    </message>
    <message>
        <source>MetaCafe Download Video</source>
        <translation>MetaCafe Stáhnout Video</translation>
    </message>
    <message>
        <source>Rip CD Audio 2 MP3</source>
        <translation>Ripovat Audio CD na MP3</translation>
    </message>
    <message>
        <source>Convert WMA 2 MP3</source>
        <translation>Převést WMA na MP3</translation>
    </message>
    <message>
        <source>Convert WAV 2 MP3</source>
        <translation>Převést WAV na MP3</translation>
    </message>
    <message>
        <source>Extract</source>
        <translation>Extrahovat</translation>
    </message>
    <message>
        <source>Extract a RAR password protected</source>
        <translation>Extrahovat zaheslovaný RAR soubor</translation>
    </message>
    <message>
        <source>ISO 2 CSO</source>
        <translation>ISO na CSO</translation>
    </message>
    <message>
        <source>CSO 2 ISO</source>
        <translation>CSO na ISO</translation>
    </message>
    <message>
        <source>Extract Audio from a Video file</source>
        <translation>Extrahovat audio z video souboru</translation>
    </message>
    <message>
        <source>AcetoneISO::Insert cd/dvd device</source>
        <translation>AcetoneISO::Vložte CD/DVD</translation>
    </message>
    <message>
        <source>AcetoneISO::Save BIN Audio file</source>
        <translation>AcetoneISO::Uložit BIN Audio soubor</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to compress</source>
        <translation>AcetoneISO::Vyberte Image pro komprimaci</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.gpg)</source>
        <translation>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.gpg)</translation>
    </message>
    <message>
        <source>AcetoneISO::Save Compressed Image</source>
        <translation>AcetoneISO::Uložit komprimovaný Image</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder where the uncompressed Image will be saved</source>
        <translation>AcetoneISO::Určete adresář pro uložení rozbaleného RAR archívu</translation>
    </message>
    <message>
        <source>Open RAR password protected</source>
        <translation>Otevřít zaheslovaný RAR soubor</translation>
    </message>
    <message>
        <source>RAR File (*.rar *.rev *.r00)</source>
        <translation>RAR File (*.rar *.rev *.r00)</translation>
    </message>
    <message>
        <source>AcetoneISO::Insert password</source>
        <translation>AcetoneISO::Zadejte heslo</translation>
    </message>
    <message>
        <source>Please insert the password of the RAR archive</source>
        <translation>Prosím zadejte helso RAR archívu</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder where the uncompressed RAR will be extracted</source>
        <translation>AcetoneISO::Určete adresář pro rozbalení RAR archívu</translation>
    </message>
    <message>
        <source>no unrar-nonfree found in /usr/bin. Please install unrar-nonfree package.</source>
        <translation>unrar-nonfree nenalezen v /usr/bin. Prosím nainstalujte balíček unrar-nonfree.</translation>
    </message>
    <message>
        <source>AcetoneISO::Save ISO file</source>
        <translation>AcetoneISO::Uložit ISO soubor</translation>
    </message>
    <message>
        <source>It is highly recommended to use &quot;Extract to folder&quot; feature.
This is because the converted ISO image is not a true ISO-9660 filesystem and requires to be mounted from terminal. A loaded hfsplus module is also needed.
Extracting the image contents to a folder is way easier and faster, and if you need you can always convert the folder to ISO in a second moment with AcetoneISO!
Choose what to do:  </source>
        <translation>Je doporučeno použít funkci &quot;Extrhovat do adresáře&quot;.
Tohle nastává protože převedený ISO Image není pravý ISO-9660 a vyžaduje připojení přes terminál. Je potřeba nahrát modul hfsplus.
Extrahovat Image do adresáře je lehčí a rychlejší, a když potřebujete můžete vždy převést adresář do ISO s AcetoneISO!
Co chcete udělat:</translation>
    </message>
    <message>
        <source> Extract to folder (best solution) </source>
        <translation>Extrahovat do adresáře (nejlepší řešení)</translation>
    </message>
    <message>
        <source> Convert to ISO (worst solution) </source>
        <translation>Převést na ISO (nejhorší řešení)</translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to extract image</source>
        <translation>AcetoneISO::Určete kam extrahovat Image</translation>
    </message>
    <message>
        <source>Do you want to download Poweriso?
If you click yes you accept PowerISO&apos;s Freeware(proprietary but gratis) License.
Remember: if you are running a 64-bit OS, you need ia32-libs package installed and maybe others.</source>
        <translation>Chcete stáhnout Poweriso?
Když kliklente na Ano, sohlasíte s Freeware licencí Poweriso.
Pamatujte: pokud používáte 64-bit OS, potřebujete mít nainstalovaný balíček libc6-i386.</translation>
    </message>
    <message>
        <source>to donate go here: http://www.acetoneteam.org/</source>
        <translation>to donate go here: http://www.acetoneteam.org/</translation>
    </message>
    <message>
        <source>This feature is untested, we can&apos;t guarantee it will work.
Sorry.</source>
        <translation type="obsolete">Tahle vlastnost není testována, nemůžeme zaručit že to bude fungovat.
Sorry.</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to encrypt</source>
        <translation>AcetoneISO::Vyberte Image pro kódování</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to decrypt</source>
        <translation>AcetoneISO::Vyberte Image pro dekódování</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder to be Converted</source>
        <translation>AcetoneISO::Určete adresář pro převod</translation>
    </message>
    <message>
        <source>AcetoneISO::Save ISO</source>
        <translation>AcetoneISO2::Uložit ISO</translation>
    </message>
    <message>
        <source>This tool doesn&apos;t do anything special.
It will only create a file with the following lines referred to the BIN/IMG you select:
FILE  + $image_file + BINARY
TRACK 01 MODE1/2352
INDEX 01 00:00:00
note: it doesn&apos;t make sense to use this feature with multisector images.</source>
        <translation>Tenhle nástroj nedělá nic speciálního.
Vytváří pouze soubory s následujícími řádky v BIN/IMG:
FILE  + $image_file + BINARY
TRACK 01 MODE1/2352
INDEX 01 00:00:00
Poznámka: nemá smysl používat tuto funkci na multisector Image.</translation>
    </message>
    <message>
        <source>AcetoneISO::Select *bin or *img</source>
        <translation>AcetoneISO::Vyberte *bin nebo *img</translation>
    </message>
    <message>
        <source>NOTE: If you want to mount an image in a root folder like /media/cdrom, please launch AcetoneISO as root user. </source>
        <translation>POZNÁMKA: Pokud chcete připojit Image v kořenovém adresáři, jako je /media/cdrom, spusťte prosím AcetoneISO jako root.</translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to mount image</source>
        <translation>AcetoneISO::Určete kam připojit Image</translation>
    </message>
    <message>
        <source>AcetoneISO::Select folder to unmount</source>
        <translation>Vyberte adresář pro odpojení</translation>
    </message>
    <message>
        <source>AcetoneISO::Inser cd/dvd device</source>
        <translation>AcetoneISO::Vložte CD/DVD</translation>
    </message>
    <message>
        <source>AcetoneISO::Byte Size</source>
        <translation>AcetoneISO::Velikost v B</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image</source>
        <translation>AcetoneISO2::Vyberte image</translation>
    </message>
    <message>
        <source>AcetoneISO::Save Md5 text file</source>
        <translation>AcetoneISO::Uložit Md5 do txt souboru</translation>
    </message>
    <message>
        <source>Operation succesfully finished!
Find the file in </source>
        <translation>Operace zdárně dokončena!
Soubor naleznete v </translation>
    </message>
    <message>
        <source> can&apos;t be mounted. You must convert it to ISO or extract content to a folder.
Please choose what to do:
note: in the next dialog, you will have to select again the image. Sorry about this.</source>
        <translation type="obsolete">Nemůže být připojen. Musíte převést image na ISO nebo extrahovat do adresáře.
Co chcete udělat:
Poznámka: v dalším okně budete muset zvolit Image znovu. Sorry.</translation>
    </message>
    <message>
        <source>An error occurred while unmounting.
The image has been unmounted but it is highly recommended to close and reopen AcetoneISO to mount a new image.</source>
        <translation>Vyskytla se chyba behem odpojování.
Image byl odpojen ale je doporučeno vypnout a zapnout AcetoneISO pro připojení nového Image.</translation>
    </message>
    <message>
        <source>Error, could not mount image.

Solution:
Try converting the image to ISO or extract the content to a folder from the upper menu &quot;Image Conversion.&quot;
NOTE: it is NOT possible to mount multi-sector images.
For more information, please visit official website: http://www.acetoneteam.org</source>
        <translation>Chyba, nemohu připojit Image.

Řešení:
Zkuste převést Image na ISO nebo extrahujte obsah do složky z horního menu &quot;Převod Image&apos;&apos;.
Poznámka: Nelze připojit multi.section Image.
Pro více informací http://www.acetoneteam.org</translation>
    </message>
    <message>
        <source>AcetoneISO::Save BIN file</source>
        <translation>AcetoneISO2::Uložit BIN soubor</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg *.gpg)</source>
        <translation>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg *.gpg)</translation>
    </message>
    <message>
        <source>AcetoneISO::Insert volume name</source>
        <translation>AcetoneISO::Zadejte jméno svazku</translation>
    </message>
    <message>
        <source>AcetoneISO::Split number</source>
        <translation>AcetoneISO2::Počet částí</translation>
    </message>
    <message>
        <source>Please insert the volume number in MegaByte:</source>
        <translation>Zadejte velikost svazku v MB:</translation>
    </message>
    <message>
        <source>Select first volume part</source>
        <translation>Určete první část svazku</translation>
    </message>
    <message>
        <source>7Z 001 (*.001)</source>
        <translation>7Z 001 (*.001)</translation>
    </message>
    <message>
        <source>to be done</source>
        <translation>je třeba udělat</translation>
    </message>
    <message>
        <source>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm )</source>
        <translation>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm )</translation>
    </message>
    <message>
        <source>AcetoneISO::Save Video file</source>
        <translation>AcetoneISO::Uložit video soubor</translation>
    </message>
    <message>
        <source>AcetoneISO::Fixed Quant</source>
        <translation>AcetoneISO::Stejné množství</translation>
    </message>
    <message>
        <source>AcetoneISO::Bitrate</source>
        <translation>AcetoneISO::Datový tok</translation>
    </message>
    <message>
        <source>AcetoneISO::YouTube</source>
        <translation>AcetoneISO::YouTube</translation>
    </message>
    <message>
        <source>AcetoneISO::PornoTube</source>
        <translation type="obsolete">AcetoneISO::PornoTube</translation>
    </message>
    <message>
        <source>Insert PornoTube&apos;s URL:
Note:
The URL to insert is not the link in the address bar of the browser, but it is in the bottom of the video where it says &quot;Media URL&quot;.
The correct URL has this type of format: http://pornotube.com/media.php?m=xyz .</source>
        <translation type="obsolete">Vložte PornTube URL:
Poznámka:
Vložená URL není v adresním řádku, ale je v dolní části, kde je napsáno &quot;Media URL&quot;.
Správná URL je ve formátu: http://pornotube.com/media.php?m=xyz .</translation>
    </message>
    <message>
        <source>AcetoneISO::MetaCafe</source>
        <translation>AcetoneISO::MetaCafe</translation>
    </message>
    <message>
        <source>Insert MetaCafe&apos;s URL:
</source>
        <translation>Zadejte URL MetaCafe:</translation>
    </message>
    <message>
        <source>
Typical problems:
- URL is wrong.
- The connection was cut suddenly for some reason.
- Video no longer exists.
- youtube/metacafe/pornotube changed their system, and the program no longer works.
Please contact sarbalap+freshmeat@gmail.com so he can update his software. AcetoneISO will automatically download any new version.</source>
        <translation type="obsolete">
Typické problémy:
- špatná URL
- náhlé přerušení spojení
- video delší dobu neexistuje
- youtube/metacafe/pornotube změnili jejich systém a program dlouho nepracuje.
Prosím kontaktujte sarbalap+freshmeat@gmail.com.</translation>
    </message>
    <message>
        <source>We highly recommend to NOT erase a DVD.
AcetoneISO can simply overwrite existing data so there is no need to erase it.
Also remember that erasing a lot of times a dvd will damage the media.
Do You want to continue anyways?</source>
        <translation>Doporučujeme nemazat DVD.
AcetoneISO může přepsat existující data.
Pamatujte že časté mazání opotřebovává DVD.
Chcete pokračovat?</translation>
    </message>
    <message>
        <source>AcetoneISO::Erase Speed</source>
        <translation>AcetoneISO::Rychlost mazání</translation>
    </message>
    <message>
        <source>AcetoneISO::Select WMA Audio File</source>
        <translation>AcetoneISO::Vyberte WMA audio soubor</translation>
    </message>
    <message>
        <source>Audio WMA (*.wma)</source>
        <translation>Audio WMA (*.wma)</translation>
    </message>
    <message>
        <source>AcetoneISO::Save MP3</source>
        <translation>AcetoneISO::Uložit MP3</translation>
    </message>
    <message>
        <source>Audio MP3 (*.mp3)</source>
        <translation>Audio MP3 (*.mp3)</translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to Save ripped CD-Audio</source>
        <translation>AcetoneISO::Určete kam uložit ripované audio CD</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Video File</source>
        <translation>AcetoneISO::Uložit video soubor</translation>
    </message>
    <message>
        <source>Video (*.avi *.mpg *.mpeg *.wmv *.flv *.mov *.asf *.rm)</source>
        <translation type="obsolete">Video (*.avi *.mpg *.mpeg *.wmv *.flv *.mov *.asf *.rm)</translation>
    </message>
    <message>
        <source>AcetoneISO::Save WAV</source>
        <translation>AcetoneISO::Uložit WAV</translation>
    </message>
    <message>
        <source>Audio WAV (*.wav)</source>
        <translation>Audio WAV (*.wav)</translation>
    </message>
    <message>
        <source>AcetoneISO::Select Wav File</source>
        <translation>AcetoneISO::Vyberte WAV soubor</translation>
    </message>
    <message>
        <source>WAV (*.wav)</source>
        <translation>WAV (*.wav)</translation>
    </message>
    <message>
        <source>AcetoneISO::Insert cd/dvd mount point</source>
        <translation>AcetoneISO::Zadejte přípojný bod cd/dvd</translation>
    </message>
    <message>
        <source>delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <source>extract</source>
        <translation>Extrahovat</translation>
    </message>
    <message>
        <source>Please note this utility will generate a BIN image which could not be mounted or read in any way.
However You can burn it later with cdrdao command, generally &quot;cdrdao $namefile.toc&quot; should work.</source>
        <translation type="obsolete">Vezměte prosím na vědomí že tento nástroj vytváří BIN Image, které nelze připojit ani přečíst.
Nicméně je můžete později vypálit. pomocí příkazu &quot;cdrdao $namefile.toc&quot; by to mělo fungovat.</translation>
    </message>
    <message>
        <source>Please specify your CD/DVD device. If you aren&apos;t sure just leave default.
Typical devices are:
/dev/cdrom or /dev/cdrom0 or /dev/cdrom1 or /dev/dvd and follow this symbolism.</source>
        <translation>Určete vaší CD/DVD mechaniku. Pokud si nejste jisti nechte výchozí.
Typické mechaniky jsou:
/dev/cdrom nebo /dev/cdrom0 nebo /dev/cdrom1 nebo /dev/dvd.</translation>
    </message>
    <message>
        <source>Note:
ISO-9660 filesystem does not support multisector images, this means you will loose all sectors above first sector. Generally speaking, the first sector holds data file.
If it&apos;s a video game image in MDF/IMG/CCD format, you will probably loose sectors that hold copyprotection files.</source>
        <translation>Poznámka:
ISO-9660 nepodporuje multisector Image, to znamená že ztratíte všechny sektory kromě prvního. Z toho vyplývá, že první sektor bude obsahovat všechna data.
Pokud je to herní obraz v MDF / IMG / CCD formátu, ztratíte pravděpodobně sektory, které obsahují ochranu proti kopírování souborů.</translation>
    </message>
    <message>
        <source>Reached maximum allowed drives to mount.</source>
        <translation>Dosaženo maxima povolených jednotek pro připojení.</translation>
    </message>
    <message>
        <source>
Typical problems:
- URL is wrong.
- The connection was cut suddenly for some reason.
- Video no longer exists.
- youtube/metacafe changed their system, and the program no longer works.
AcetoneISO will automatically update the software when a new release comes out!</source>
        <translation type="obsolete">Typické problémy:
- Špatné URL.
-.Spojení bylo z nějakého důvodu náhle přerušeno.
-.Video již neexistuje.
- youtube/metacafe změnili svůj systém a program již nefunguje.
AcetoneISO automaticky aktualizuje software když vyjde nová verze!</translation>
    </message>
    <message>
        <source>Mount Images</source>
        <translation>Připojit Image</translation>
    </message>
    <message>
        <source>News &amp;&amp; Updates</source>
        <translation type="obsolete">Novinky &amp;&amp; Aktualizace</translation>
    </message>
    <message>
        <source>&amp;Archive Manager</source>
        <translation>&amp;Správce Archívů</translation>
    </message>
    <message>
        <source>Unmount Image</source>
        <translation>Odpojit Image</translation>
    </message>
    <message>
        <source>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm *.mp4)</source>
        <translation></translation>
    </message>
    <message>
        <source>Video (*.mp4)</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Convert video for PSP™</source>
        <translation>Převést video pro PSP™</translation>
    </message>
    <message>
        <source>You decided to unmount:
</source>
        <translation>Rozhodli jste se odpojit:
</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation>
Jste si jisti?</translation>
    </message>
    <message>
        <source>Delete Image</source>
        <translation type="obsolete">Smazat Image</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <source>Rip CD-Audio to WAV</source>
        <translation>Ripovat Audio CD na WAV</translation>
    </message>
    <message>
        <source>This is the first time you launch AcetoneISO software.
In the next dialog you can set your default file manager, set database and some other things.
Happy AcetoneISO usage from the team:)</source>
        <translation>Toto je poprvé co spouštíte AcetoneISO.
V dalším okně máte možnost nastavit si správce souborů, natavit databázi a další věci.
Šťastné používání AcetoneISO :)</translation>
    </message>
    <message>
        <source>AcetoneISO I love You!</source>
        <translation></translation>
    </message>
    <message>
        <source> doesn&apos;t exist.
I&apos;ll remove it from database display.</source>
        <translation> neexistuje.
Bude odstraněn z databáze.</translation>
    </message>
    <message>
        <source>The History display is already empty!</source>
        <translation>Historie je již prázdná!</translation>
    </message>
    <message>
        <source>You are about to clear the History display.
This won&apos;t delete the images from hard disk.
Clear History?</source>
        <translation>Chystáte se vymazat Historii.
Toto nesmaže Image na disku.
Smazat Historii?</translation>
    </message>
    <message>
        <source>All images that don&apos;t exist have been removed from History</source>
        <translation>Všechny Image, které neexistují byly odstraněny z Historie</translation>
    </message>
    <message>
        <source>History:</source>
        <translation>Historie:</translation>
    </message>
    <message>
        <source>Remove non-existant images from History</source>
        <translation>Odstranit neexistující Image z Historie</translation>
    </message>
    <message>
        <source>Clear History Display</source>
        <translation>Smazat Historii</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Obnovit</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Ukončit</translation>
    </message>
    <message>
        <source>About AcetoneISO</source>
        <translation>O AcetoneISO2</translation>
    </message>
    <message>
        <source>Mount Image</source>
        <translation>Připojit Image</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Ukončit</translation>
    </message>
    <message>
        <source>Do the action specified in the combobox</source>
        <translation></translation>
    </message>
    <message>
        <source>Database set to:  (flag recursive:ON)</source>
        <translation>Databáze nastavena na:  (flag recursive:ON)</translation>
    </message>
    <message>
        <source>Database set to:  (flag recursive:OFF)</source>
        <translation>Databáze nastavena na:  (flag recursive:OFF)</translation>
    </message>
    <message>
        <source>Database set to:</source>
        <translation>Databáze nastavena na:</translation>
    </message>
    <message>
        <source>All images in History fisically exist!</source>
        <translation>Všechny Image v Historii fyzicky existují!</translation>
    </message>
    <message>
        <source> doesn&apos;t exist.
I&apos;ll remove it from history display.</source>
        <translation> neexistuje.
Bude odstraněn z historie.</translation>
    </message>
    <message>
        <source>
This will remove it from history and fisically delete it.</source>
        <translation>
Toto odstraní z Historie i fyzicky z disku.</translation>
    </message>
    <message>
        <source>background-color: rgb(250, 248, 255);
selection-background-color: rgb(248, 146, 255);
selection-color: rgb(82, 1, 93);</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: rgb(244, 251, 255);
selection-background-color: rgb(121, 123, 255);
selection-color: rgb(1, 10, 134);</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: rgb(244, 251, 255);
selection-color: rgb(197, 24, 212);</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: rgb(246, 255, 248);
selection-color: rgb(19, 89, 0);
selection-background-color: rgb(147, 255, 151);</source>
        <translation></translation>
    </message>
    <message>
        <source>Even though the image is mounted, in the options you specified to not open a file manager.
If you want to change this behaviour, please open Options and set file manager there.</source>
        <translation type="obsolete">I přesto, že je Image připojen, nelze jej otevřít ve správci souborů, který jste nasatvili.
Pokud chcete změnit toto chování, spuťte Nastavení a nastavte správce souborů.</translation>
    </message>
    <message>
        <source>open image in file manager</source>
        <translation>Otevřít Image ve správci souborů</translation>
    </message>
    <message>
        <source>mount </source>
        <translation>Připojit</translation>
    </message>
    <message>
        <source>delete </source>
        <translation>Smazat</translation>
    </message>
    <message>
        <source>extract </source>
        <translation>Extrahovat</translation>
    </message>
    <message>
        <source>open </source>
        <translation>Otevřít </translation>
    </message>
    <message>
        <source> in file manager</source>
        <translation> ve správci souborů</translation>
    </message>
    <message>
        <source>unmount </source>
        <translation>Odpojit</translation>
    </message>
    <message>
        <source>Double click an image to open in file manager.
Right click for Context Menu.</source>
        <translation>Dvojklik pro otevření Image ve správci souborů.
Pravé tlačítko pro kontextové menu.</translation>
    </message>
    <message>
        <source>Unable to find</source>
        <translation>Nelze nalézt</translation>
    </message>
    <message>
        <source>in /usr/bin.
Please install it and be sure it&apos;s linked to /usr/bin folder.</source>
        <translation>v /usr/bin.
Prosím, nainstalujte ho a ujistěte se, že souvisí s adresářem /usr/bin.</translation>
    </message>
    <message>
        <source>Process Progress:</source>
        <translation>Průběh procesu:</translation>
    </message>
    <message>
        <source>Hides the Process Display</source>
        <translation>Skrýtí displeje procesu</translation>
    </message>
    <message>
        <source>Hide Process display</source>
        <translation>Skrýt displej procesu</translation>
    </message>
    <message>
        <source>This display shows you the current progress of the process in action</source>
        <translation>Tento displej zobrazuje aktuální průběh procesu v akci</translation>
    </message>
    <message>
        <source>Make a small donation</source>
        <translation></translation>
    </message>
    <message>
        <source>Image Files (*.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.cue)</source>
        <translation></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg *.cue)</source>
        <translation></translation>
    </message>
    <message>
        <source>background-color: rgb(255, 255, 238);
selection-background-color: rgb(85, 0, 255);</source>
        <translation></translation>
    </message>
    <message>
        <source>Choose if you want the audio to be in mp3 format or if
it should be the same of the dvd (for example dolby 5.1)</source>
        <translation>Vyberte, zda chcete, aby by zvuk ve formátu mp3, nebo pokud
by měl být stejný na dvd (např. Dolby 5.1)</translation>
    </message>
    <message>
        <source>Mp3</source>
        <translation></translation>
    </message>
    <message>
        <source>Original Audio</source>
        <translation>Originální Audio</translation>
    </message>
    <message>
        <source>Burn CD/DVD</source>
        <translation>Vypálit CD/DVD</translation>
    </message>
    <message>
        <source>Updates</source>
        <translation>Aktualizace</translation>
    </message>
    <message>
        <source>Unable to find wodim in /usr/bin.
Please install wodim package.</source>
        <translation>Nelze nalézt wodim v usr/bin.
Prosím nainstalujte balíček wodim.</translation>
    </message>
    <message>
        <source>Erase CD-RW</source>
        <translation>Vymazat CD-RW</translation>
    </message>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation>Vymazat DVD±RW</translation>
    </message>
    <message>
        <source>Unable to find dvd+rw-format in /usr/bin.
Please install dvd+rw-tools package.</source>
        <translation>Nelze nalézt dvd+rw-format v /usr/bin.
Prosím nainstalujte balíček dvd+rw-tools.</translation>
    </message>
    <message>
        <source>Burn ISO image to CD</source>
        <translation type="obsolete">Vypálit ISO Image na CD</translation>
    </message>
    <message>
        <source>Burn ISO image to DVD</source>
        <translation type="obsolete">Vypálit ISO Image na DVD</translation>
    </message>
    <message>
        <source>Create CD Data</source>
        <translation type="obsolete">Vytvořit datové CD</translation>
    </message>
    <message>
        <source>Create DVD Data</source>
        <translation type="obsolete">Vytvořit datové DVD</translation>
    </message>
    <message>
        <source>Video (*.avi *.mpg *.mpeg *.wmv *.flv *.mov *.asf *.rm *.mp4)</source>
        <translation></translation>
    </message>
    <message>
        <source>Calculate Md5-Sum</source>
        <translation></translation>
    </message>
    <message>
        <source>Calculate Sha-Sum</source>
        <translation></translation>
    </message>
    <message>
        <source>Sha1</source>
        <translation></translation>
    </message>
    <message>
        <source>Sha256</source>
        <translation></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.bin *.mdf *.nrg *.img)</source>
        <translation></translation>
    </message>
    <message>
        <source>Sha384</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Erase CD-RW or DVD±RW :</source>
        <translation>Vymazat CD-RW nebo DVD±RW :</translation>
    </message>
    <message utf8="true">
        <source>Burn ISO Image to CD-R/RW or DVD±R/RW :</source>
        <translation type="obsolete">Vypálit ISO Image na CD-R/RW nebo DVD±R/RW :</translation>
    </message>
    <message>
        <source>Select where to Save the Youtube Video</source>
        <translation>Určete kam uložit Youtube video</translation>
    </message>
    <message>
        <source>Burn ISO image to CD-R/RW</source>
        <translation type="obsolete">Vypálit ISO Image na CD-R/RW</translation>
    </message>
    <message utf8="true">
        <source>Burn ISO image to DVD±R/RW</source>
        <translation>Vypálit ISO Image na DVD±R/RW</translation>
    </message>
    <message>
        <source>Unable to find growisofs in /usr/bin.
Please install growisofs package.</source>
        <translation>Nelze nalézt growisoft v /usr/bin.
Prosím nainstalujte balíček growisoft.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>This Image appears to have an UDF filesystem.
To correctly mount this image, open a terminal as root user and type:</source>
        <translation>Tento Image vypadá, že má souborový systém UDF.
Chcete-li správně připojit tento Image, otevřete terminál jako root a napište:</translation>
    </message>
    <message>
        <source>Unable to download youtube-dl.
Please try again and be sure your internet connection is alive.
If the problem persists please contact us at acetoneiso@gmail.com .</source>
        <translation>Nelze stáhnout youtube-dl.
Prosím zkuste to znovu a ujistěte se, že jste připojeni k internetu.
Pokud problém přetrvává, prosím kontaktujte nás na acetoneiso@gmail.com.</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <source>Burn Image to CD-R/RW</source>
        <translation type="obsolete">Vypálit Image na CD-R/RW</translation>
    </message>
    <message utf8="true">
        <source>Burn Image ISO/CUE/TOC to CD-R/RW or DVD±R/RW :</source>
        <translation>Vypálit ISO/CUE/TOC Image na CD-R/RW nebo DVD±R/RW :</translation>
    </message>
    <message>
        <source>Please note this utility will generate a TOC/BIN image which could not be mounted or read in any way.
However You can burn it later with AcetoneISO burning tools!</source>
        <translation>Vezměte prosím na vědomí že tento nástroj vytváří TOC/BIN Image, které nelze připojit ani přečíst. 
Nicméně je můžete později vypálit pomocí AcetoneISO!</translation>
    </message>
    <message>
        <source>Burn ISO/TOC/CUE to CD-R/RW</source>
        <translation>Vypálit ISO/TOC/CUE na CD-R/RW</translation>
    </message>
</context>
<context>
    <name>burniso2cd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation>CD/DVD jednotka nenalezena.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation>CD/DVD jednotka nenalezena</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="obsolete">Nenalezena CD/DVD jednotka, která umožňuje zápis na CD-RW disky.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>The CD-RW is getting blanked...</source>
        <translation type="obsolete">CD-RW je mazáno...</translation>
    </message>
    <message>
        <source>Insert a CD-RW disc.</source>
        <translation type="obsolete">Vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-RW. Please insert a CD-RW disc.</source>
        <translation type="obsolete">Tento disk není CD-RW. Prosím vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>CD-RW succesfully found in device.</source>
        <translation type="obsolete">CD-RW nalezeno v jednotce.</translation>
    </message>
    <message>
        <source>You decided to blank the CD-RW.
Are you sure?</source>
        <translation type="obsolete">Rozhodli jste se smazat CD-RW.
Jste si jisti?</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation>Proces zdárně dokončen!</translation>
    </message>
    <message>
        <source>Burn ISO to CD-R/RW</source>
        <translation type="obsolete">Vypálit ISO na CD-R/RW</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation>Jednotka:</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation>Toto okno ukazuje všechny CD-RW jednotky nalezené ve vašem systému</translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation>Rychlost:</translation>
    </message>
    <message>
        <source>Select ISO to burn to CD-R/RW :</source>
        <translation type="obsolete">Vyberte ISO pro vypálení na CD-R/RW:</translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation type="obsolete">Začít s mazáním vašeho disku</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Začít</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation>Tohle vysune váš disk po dokončení mazání</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation>Vysunout disk po dokončení práce</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation>Při ukončení přehrát zvukové upozornění</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Průběh:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="obsolete">Tento displej zobrazuje průběh procesu mazání</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-R/RW discs.
If you think this is a bug please report it.</source>
        <translation>Nenalezena CD/DVD jednotka, která umožňuje zápis na CD-RW disky.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>AcetoneISO is burning your ISO to the</source>
        <translation type="obsolete">AcetoneISO vypaluje vaše ISO na</translation>
    </message>
    <message>
        <source>Insert a CD-R/RW disc.</source>
        <translation>Vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-R/RW. Please insert a CD-R/RW disc.</source>
        <translation>Tento disk není CD-RW. Prosím vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>You inserted a CD-RW disc, however your CD/DVD device is uncapable of writing to CD-RW discs.</source>
        <translation>Vložili jste CD-RW disk, bohužel vaše CD/DVD jednotka nepodporuje zápis na CD-RW disky.</translation>
    </message>
    <message>
        <source>The CD-R isn&apos;t empty. Please insert an empty CD-R/RW disc.</source>
        <translation>Tento disk CD-R není prázdný. Prosím vložte prázdný CD-R/RW disk.</translation>
    </message>
    <message>
        <source>The CD-RW isn&apos;t empty.
Please insert an empty CD-R/RW disc or blank the CD-RW with the appropriate AcetoneISO&apos;s blanking tool.</source>
        <translation>Teto CD-RW není prázdné.
Prosím vložte prázdný CD-R/RW disk nebo jej vymažte pomocí AcetoneISO.</translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation>nalezeno v jednotce.</translation>
    </message>
    <message>
        <source>You decided to burn the</source>
        <translation type="obsolete">Rozhodli jste se vypálit</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation>
Jste si jisti?</translation>
    </message>
    <message>
        <source>Choose writing speed. When putting high values, be sure to have a good optical medium quality.</source>
        <translation>Vyberte rychlost zápisu. Pokud zvolíte vysokou hodnotu, pak se ujistěte, že máte kvalitní optické média.</translation>
    </message>
    <message>
        <source>Click here to browse and choose what image to burn to your optical medium</source>
        <translation>Klikněte zde pro procházení a vyberte Image, který bude vypálen na vaše optické médium</translation>
    </message>
    <message>
        <source>Start burning your image.</source>
        <translation>Začít s vypalováním Image.</translation>
    </message>
    <message>
        <source>Does a burning simulation. This means it will not do a real burn and write data on your CD-R/RW disc.</source>
        <translation>Simulace vypalování. To znamená, že se ve skutečnosti nebudou zapisovat data na váš CD-R/RW disk.</translation>
    </message>
    <message>
        <source>Simulation</source>
        <translation>Simulace</translation>
    </message>
    <message>
        <source>Select Image to Burn</source>
        <translation>Vyberte Image pro vypálení</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.bin *.img)</source>
        <translation type="obsolete">Image Files (*.iso *.bin *.img)</translation>
    </message>
    <message>
        <source>The Image you selected does not exist.</source>
        <translation type="obsolete">Image, který jste zvolili neexistuje.</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> sukund</translation>
    </message>
    <message>
        <source> minutes</source>
        <translation> minut</translation>
    </message>
    <message>
        <source>Estimated time to burn </source>
        <translation>Odhadovaná doba vypalování </translation>
    </message>
    <message>
        <source>Select ISO/CUE/TOC image to burn to CD-R/RW :</source>
        <translation>Vyberte ISO/CUE/TOC pro vypálení na CD-R/RW :</translation>
    </message>
    <message>
        <source>This display shows the progress of the burning process.</source>
        <translation>Tento displej zobrazuje průběh vypalování.</translation>
    </message>
    <message>
        <source>AcetoneISO is burning your image to the</source>
        <translation>AcetoneISO vypaluje váš Image na</translation>
    </message>
    <message>
        <source>You decided to burn the image on the</source>
        <translation>Rozhodli jste se vypálit Image na</translation>
    </message>
    <message>
        <source>Burn Image to CD-R/RW</source>
        <translation>Vypálit Image na CD-R/RW</translation>
    </message>
    <message>
        <source>The Image you selected is too big to fit into a CD-R/RW.</source>
        <translation>Image, který jste vybrali je příliš velký na to, aby se vešel na CD-R/RW.</translation>
    </message>
    <message>
        <source>Image Files ISO/CUE/TOC (*.iso *.cue *.toc)</source>
        <translation>Image Files ISO/CUE/TOC (*.iso *.cue *.toc)</translation>
    </message>
    <message>
        <source>The Image you selected is unsupported from AcetoneISO.</source>
        <translation>Image, který jste vybrali, není podporován AcetoneISO.</translation>
    </message>
    <message>
        <source>The Image you selected does not exist.
If trying to burn a CUE/TOC image, be sure the image file is in the exact folder where the CUE/TOC file is.
Be also sure they have same name except the CUE/TOC file ending with .toc extension.</source>
        <translation>Image, který jste vybrali neexistuje.
Pokud se snažíte vypálit CUE/TOC Image, tak se ujistěte, že Image je přesně ve složce, kde je CUE / TOC soubor.
Ujistěte se také, že mají stejný název, s vyjímkou CUE/TOC souboru s koncovkou. toc.</translation>
    </message>
    <message>
        <source>Program cue2toc not found in /usr/bin
Please install cue2toc package.</source>
        <translation>cue2toc nenalezen v /usr/bin
Prosím nainstalujte cue2toc.</translation>
    </message>
    <message>
        <source>Unable to generate toc file from the cue file you selected.</source>
        <translation>Není možné generovat toc soubor z vybraného cue souboru.</translation>
    </message>
</context>
<context>
    <name>burniso2dvd</name>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation type="obsolete">Vymazat DVD±RW</translation>
    </message>
    <message utf8="true">
        <source>Selecting this will completely blank your DVD±RW. This is not recommended and may damage your media on if used several times</source>
        <translation type="obsolete">Toto smaže kompletně vaše DVD±RW. Toto není doporučeno a pokud to použijete několikrát, může dojít k poškození vašeho média</translation>
    </message>
    <message>
        <source>Blank  the entire disk (not recommended)</source>
        <translation type="obsolete">Smazat celý disk (není doporučeno)</translation>
    </message>
    <message>
        <source>Quick Blank</source>
        <translation type="obsolete">Rychlé smazání</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="obsolete">Tohle vysune váš disk po dokončení mazání</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="obsolete">Vysunout disk po dokončení práce</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Průběh:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation>Tento displej zobrazuje průběh procesu mazání</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation>Při ukončení přehrát zvukové upozornění</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation>Jednotka:</translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the DVD±RW capable devices found in your system</source>
        <translation type="obsolete">Toto okno ukazuje všechny DVD±RW jednotky nalezené ve vašem systému</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Začít</translation>
    </message>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation>CD/DVD jednotka nenalezena.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation>CD/DVD jednotka nenalezena</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to DVD-RW discs.
If you think this is a bug please report it.</source>
        <translation>Nenalezena CD/DVD jednotka, která umožňuje zápis na DVD-RW disky.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>The</source>
        <translation type="obsolete"> </translation>
    </message>
    <message>
        <source>is getting blanked...</source>
        <translation type="obsolete">je mazázáno...</translation>
    </message>
    <message>
        <source>Insert a DVD</source>
        <translation>Vložte DVD</translation>
    </message>
    <message>
        <source>disc.</source>
        <translation>disk.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a DVD</source>
        <translation>Tento disk není DVD</translation>
    </message>
    <message>
        <source>Please insert a DVD</source>
        <translation>Prosím vložte DVD</translation>
    </message>
    <message>
        <source>You inserted a </source>
        <translation>Vložili jste </translation>
    </message>
    <message>
        <source>You inserted a DVD+RW disc, however your CD/DVD device is uncapable of writing to DVD+RW discs.</source>
        <translation type="obsolete">Vložili jste DVD+RW disk, bohužel vaše CD/DVD jednotka nepodporuje zápis na DVD+RW disky.</translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation>nalezeno v jednotce.</translation>
    </message>
    <message>
        <source>You decided to blank the</source>
        <translation type="obsolete">Rozhodli jste se smazat</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation>
Jste si jisti?</translation>
    </message>
    <message>
        <source>is already formatted.
There is no need to format it because you can simply overwrite the media.
If you really want to blank it, choose Blank the Entire disc in the below window but we highly discourage you from doing so.
Overwriting the</source>
        <translation type="obsolete">je již naformátované.
Není nutno formátovat, protože můžete jednoduše médium přepsat.
Pokud jej opravdu chcete smazat, zvolte dole v okně Smazat celý disk, ale důrazně toto nedoporučujeme.
Přepisování </translation>
    </message>
    <message>
        <source>is the simplest and safest thing to do.</source>
        <translation type="obsolete">je nejjednodušší a nejbezpečnější věc.</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation>Proces zdárně dokončen!</translation>
    </message>
    <message>
        <source> that is not Empty. Please put an empty DVD</source>
        <translation> není prázdné. Prosím vložte prázdné DVD</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation type="obsolete">Toto okno ukazuje všechny CD-RW jednotky nalezené ve vašem systému</translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation>Rychlost:</translation>
    </message>
    <message>
        <source>Choose writing speed. When putting high values, be sure to have a good optical medium quality.</source>
        <translation>Vyberte rychlost zápisu. Pokud zvolíte vysokou hodnotu, pak se ujistěte, že máte kvalitní optické média.</translation>
    </message>
    <message>
        <source>Click here to browse and choose what image to burn to your optical medium</source>
        <translation>Klikněte zde pro procházení a vyberte Image, který bude vypálen na vaše optické médium</translation>
    </message>
    <message>
        <source>Start burning your image.</source>
        <translation>Začít s vypalováním Image.</translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the dvd DVD±R/RW capable devices found in your system</source>
        <translation>Toto okno ukazuje všechny DVD±RW jednotky nalezené ve vašem systému</translation>
    </message>
    <message utf8="true">
        <source>Select ISO image to burn to DVD±R/RW :</source>
        <translation>Vyberte ISO pro vypálení na DVD±R/RW:</translation>
    </message>
    <message utf8="true">
        <source>Burn ISO to DVD±R/RW</source>
        <translation>Vypálit ISO na DVD±R/RW</translation>
    </message>
    <message>
        <source> disc, however your CD/DVD device is uncapable of writing to such discs.</source>
        <translation> disk, ale vaše CD/DVD jednotka není schopná zápisovat na tyto disky.</translation>
    </message>
    <message>
        <source>Select Image to Burn</source>
        <translation type="obsolete">Vyberte Image pro vypálení</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.bin *.img)</source>
        <translation type="obsolete">Image Files (*.iso *.bin *.img)</translation>
    </message>
    <message>
        <source>The Image you selected does not exist.</source>
        <translation>Image, který jste zvolili neexistuje.</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation> sukund</translation>
    </message>
    <message>
        <source> minutes</source>
        <translation> minut</translation>
    </message>
    <message>
        <source>Estimated time to burn </source>
        <translation>Odhadovaná doba vypalování </translation>
    </message>
    <message>
        <source> that is not Empty. If you continue, AcetoneISO will overwrite your disc!</source>
        <translation> není prázdný. Pokud bude pokračovat, AcetoneISO přepíše váš disk!</translation>
    </message>
    <message>
        <source>You decided to burn the image on the</source>
        <translation>Rozhodli jste se vypálit Image na</translation>
    </message>
    <message>
        <source>.
The disc is NOT empty so if you continue,
AcetoneISO will overwrite all your data.
Are you sure?</source>
        <translation>.
Tento disk není prázdný, takže pokud budete pokračovat,
AcetoneISO přepíše všechna vaše data.
Jste si jisti?</translation>
    </message>
    <message>
        <source>AcetoneISO is burning your image to the</source>
        <translation>AcetoneISO vypaluje váš Image na</translation>
    </message>
    <message>
        <source>Select ISO Image to Burn</source>
        <translation>Vyberte ISO Image pro vypálení</translation>
    </message>
    <message>
        <source>ISO Image Files (*.iso)</source>
        <translation>ISO Image Files (*.iso)</translation>
    </message>
    <message>
        <source>The Image you selected is unsupported from AcetoneISO.</source>
        <translation>Image, který jste vybrali, není podporován AcetoneISO.</translation>
    </message>
</context>
<context>
    <name>erasecd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation>CD/DVD jednotka nenalezena.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation>CD/DVD jednotka nenalezena</translation>
    </message>
    <message>
        <source>The CD-RW is getting blanked...</source>
        <translation>CD-RW je mazáno...</translation>
    </message>
    <message>
        <source>Insert a CD-RW disc.</source>
        <translation>Vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-RW. Please insert a CD-RW disc.</source>
        <translation>Tento disk není CD-RW. Prosím vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>CD-RW succesfully found in device.</source>
        <translation>CD-RW nalezeno v jednotce.</translation>
    </message>
    <message>
        <source>You decided to blank the CD-RW.
Are you sure?</source>
        <translation>Rozhodli jste se smazat CD-RW.
Jste si jisti?</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation>Proces zdárně dokončen!</translation>
    </message>
    <message>
        <source>Erase CD</source>
        <translation>Vymazat CD</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation>Jednotka:</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom capable devices found in your system</source>
        <translation type="obsolete">Toto okno ukazuje všechny cdrom jednotky nalezené ve vašem systému</translation>
    </message>
    <message>
        <source>Selecting this will completely blank your CD-RW</source>
        <translation>Tohle smaže kompletně vaše CD-RW</translation>
    </message>
    <message>
        <source>Blank  the entire disk</source>
        <translation>Smazat celý disk</translation>
    </message>
    <message>
        <source>This will not delete files but only PMA, TOC and the pregap</source>
        <translation>Tohle nesmaže soubory, ale pouze PMA, TOC a pregap</translation>
    </message>
    <message>
        <source>Minimally blank the entire disk (PMA, TOC, pregap)</source>
        <translation>Rychlé smazání disku (PMA, TOC, pregap)</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation>Tohle vysune váš disk po dokončení mazání</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation>Vysunout disk po dokončení práce</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Průběh:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation></translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation>Začít s mazáním vašeho disku</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Začít</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-RW discs.
If you think this is a bug please report it.</source>
        <translation>Nenalezena CD/DVD jednotka, která umožňuje zápis na CD-RW disky.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation>Při ukončení přehrát zvukové upozornění</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation>Toto okno ukazuje všechny CD-RW jednotky nalezené ve vašem systému</translation>
    </message>
</context>
<context>
    <name>erasedvd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation>CD/DVD jednotka nenalezena.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation>CD/DVD jednotka nenalezena</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="obsolete">Nenalezena CD/DVD jednotka, která umožňuje zápis na CD-RW disky.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>The CD-RW is getting blanked...</source>
        <translation type="obsolete">CD-RW je mazáno...</translation>
    </message>
    <message>
        <source>Insert a CD-RW disc.</source>
        <translation type="obsolete">Vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-RW. Please insert a CD-RW disc.</source>
        <translation type="obsolete">Tento disk není CD-RW. Prosím vložte CD-RW disk.</translation>
    </message>
    <message>
        <source>CD-RW succesfully found in device.</source>
        <translation type="obsolete">CD-RW nalezeno v jednotce.</translation>
    </message>
    <message>
        <source>You decided to blank the CD-RW.
Are you sure?</source>
        <translation type="obsolete">Rozhodli jste se smazat CD-RW.
Jste si jistý?</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation>Proces zdárně dokončen!</translation>
    </message>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation>Vymazat DVD±RW</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation>Jednotka:</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom capable devices found in your system</source>
        <translation type="obsolete">Toto okno ukazuje všechny cdrom jednotky nalezené ve vašem systému</translation>
    </message>
    <message>
        <source>Selecting this will completely blank your CD-RW</source>
        <translation type="obsolete">Tohle smaže kompletně vaše CD-RW</translation>
    </message>
    <message>
        <source>Blank  the entire disk</source>
        <translation type="obsolete">Smazat celý disk</translation>
    </message>
    <message>
        <source>This will not delete files but only PMA, TOC and the pregap</source>
        <translation type="obsolete">Tohle nesmaže soubory, ale pouze PMA, TOC a pregap</translation>
    </message>
    <message>
        <source>Minimally blank the entire disk (PMA, TOC, pregap)</source>
        <translation type="obsolete">Rychlé smazání disku (PMA, TOC, pregap)</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation>Tohle vysune váš disk po dokončení mazání</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation>Vysunout disk po dokončení práce</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation>Průběh:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation>Tento displej zobrazuje průběh procesu mazání</translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation>Začít s mazáním vašeho disk</translation>
    </message>
    <message>
        <source>Start</source>
        <translation>Začít</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation>Při ukončení přehrát zvukové upozornění</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to DVD-RW discs.
If you think this is a bug please report it.</source>
        <translation>Nenalezena CD/DVD jednotka, která umožňuje zápis na DVD-RW disky.
Pokud si myslíte, že je to bug, nahlašte jej.</translation>
    </message>
    <message>
        <source>Insert a DVD</source>
        <translation>Vložte DVD</translation>
    </message>
    <message>
        <source>disc.</source>
        <translation>disk.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a DVD</source>
        <translation>Tento disk není DVD</translation>
    </message>
    <message>
        <source>Please insert a DVD</source>
        <translation>Prosím vložte DVD</translation>
    </message>
    <message>
        <source>You inserted a DVD+RW disc, however your CD/DVD device is uncapable of writing to DVD+RW discs.</source>
        <translation>Vložili jste DVD+RW disk, bohužel vaše CD/DVD jednotka nepodporuje zápis na DVD+RW disky.</translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation>nalezeno v jednotce.</translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the DVD±RW capable devices found in your system</source>
        <translation>Toto okno ukazuje všechny DVD±RW jednotky nalezené ve vašem systému</translation>
    </message>
    <message>
        <source>The</source>
        <translation> </translation>
    </message>
    <message>
        <source>is getting blanked...</source>
        <translation>je mazázáno...</translation>
    </message>
    <message>
        <source>You decided to blank the</source>
        <translation>Rozhodli jste se smazat</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation>
Jste si jisti?</translation>
    </message>
    <message utf8="true">
        <source>Selecting this will completely blank your DVD±RW. This is not recommended and may damage your media on if used several times</source>
        <translation>Toto smaže kompletně vaše DVD±RW. Toto není doporučeno a pokud to použijete několikrát, může dojít k poškození vašeho média</translation>
    </message>
    <message>
        <source>Blank  the entire disk (not recommended)</source>
        <translation>Smazat celý disk (není doporučeno)</translation>
    </message>
    <message>
        <source>Quick Blank</source>
        <translation>Rychlé smazání</translation>
    </message>
    <message>
        <source>is already formatted.
There is no need to format it because you can simply overwrite the media.
If you really want to blank it, choose Blank the Entire disc in the below window but we highly discourage you from doing so.
Overwriting the</source>
        <translation>je již naformátované.
Není nutno formátovat, protože můžete jednoduše médium přepsat.
Pokud jej opravdu chcete smazat, zvolte dole v okně Smazat celý disk, ale důrazně toto nedoporučujeme.
Přepisování </translation>
    </message>
    <message>
        <source>is the simplest and safest thing to do.</source>
        <translation>je nejjednodušší a nejbezpečnější věc.</translation>
    </message>
</context>
<context>
    <name>manual</name>
    <message>
        <source>AcetoneISO2::Manual</source>
        <translation type="obsolete">AcetoneISO2::Manuál</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Ukončit</translation>
    </message>
    <message>
        <source>AcetoneISO::Manual</source>
        <translation>AcetoneISO::Manuál</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>options</name>
    <message>
        <source>AcetoneISO2::Options</source>
        <translation type="obsolete">AcetoneISO2::Nastavení</translation>
    </message>
    <message>
        <source>Iso from folder</source>
        <translation>ISO z adresáře</translation>
    </message>
    <message>
        <source>Standard Settings</source>
        <translation>Standardní nastavení</translation>
    </message>
    <message>
        <source>will let you add an ID to the ISO</source>
        <translation>Umožní vám přidat ID k ISO</translation>
    </message>
    <message>
        <source>User Settings</source>
        <translation>Uživatelské nastavení</translation>
    </message>
    <message>
        <source>Media player</source>
        <translation>Přehrávač</translation>
    </message>
    <message>
        <source>Kaffeine</source>
        <translation>Kaffeine</translation>
    </message>
    <message>
        <source>Vlc</source>
        <translation>VLC</translation>
    </message>
    <message>
        <source>SMPlayer</source>
        <translation>SMPlayer</translation>
    </message>
    <message>
        <source>File manager</source>
        <translation>Správce souborů</translation>
    </message>
    <message>
        <source>it will use kde&apos;s default file manager</source>
        <translation>Bude použit výchozí správce souborů KDE</translation>
    </message>
    <message>
        <source>Kde</source>
        <translation>KDE</translation>
    </message>
    <message>
        <source>it will use Nautilus file manager</source>
        <translation>Bude použit správce souborů Nautilus</translation>
    </message>
    <message>
        <source>Nautilus</source>
        <translation>Nautilus</translation>
    </message>
    <message>
        <source>ok</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Databáze</translation>
    </message>
    <message>
        <source>Set database root folder</source>
        <translation type="obsolete">Nastavit kořenový adresář databáze</translation>
    </message>
    <message>
        <source>Reset options to default values.</source>
        <translation>Resetovat nastavení na výchozí hodnoty.</translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation>Výchozí</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Použít</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Storno</translation>
    </message>
    <message>
        <source>Thunar</source>
        <translation></translation>
    </message>
    <message>
        <source>Don&apos;t Open a file manager</source>
        <translation>Neotvírat správce souborů</translation>
    </message>
    <message>
        <source>What is Database?</source>
        <translation>Co je databáze?</translation>
    </message>
    <message>
        <source>Set database root folder:</source>
        <translation>Nastavit kořenový adresář databáze:</translation>
    </message>
    <message>
        <source>Scan Subdirectories (read below)</source>
        <translation>Prohledání podadresáře (čtěte níže)</translation>
    </message>
    <message>
        <source>General Options</source>
        <translation>Hlavní nastavení</translation>
    </message>
    <message>
        <source>Advanced Options</source>
        <translation>Pokročilé nastavení</translation>
    </message>
    <message>
        <source>AcetoneISO::Options</source>
        <translation>AcetoneISO::Nastavení</translation>
    </message>
    <message>
        <source>Enable Tray Icon (requires application restart)</source>
        <translation>Povolit Tray Icon (vyžaduje restart aplikace)</translation>
    </message>
    <message>
        <source>Close in Tray Icon</source>
        <translation>Zavřít v Tray Icon</translation>
    </message>
    <message>
        <source>Automatically clean History display on restart</source>
        <translation>Automaticky smazat Historii při restartu</translation>
    </message>
    <message>
        <source>Tray Icon:</source>
        <translation></translation>
    </message>
    <message>
        <source>History:</source>
        <translation>Historie:</translation>
    </message>
    <message>
        <source>Automatically remove non-existant images from History display on restart</source>
        <translation>Automaticky odstranit neexistující Image z Historie při restartu</translation>
    </message>
    <message>
        <source>Lxde</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;If you activate Scan Subdirectories checkbox, avoid setting database root folder directly to your ~home folder or system folders.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>optionsDiag</name>
    <message>
        <source>AcetoneISO::Select Database Folder</source>
        <translation>AcetoneISO::Zvolit adresář s databází</translation>
    </message>
    <message>
        <source>Database is a quick and easy feature for managing your images.
Place them all in a folder and set the Database path to it, you will see all the images in the database display.
You can quickly mount them by simply clicking on them or right click for more options.</source>
        <translation>Databáze je rychlý a jednoduchý nástroj pro správu vašich Image.
Umístěte je všechny do jednoho adresáře a nastavte cestu databáze, poté uvidíte všechny Image v databázi.
Můžete je rychle připojovat jednoduchým kliknutím nebo pravým kliknutím vyvoláte nabídku pro více možností.</translation>
    </message>
</context>
<context>
    <name>progress</name>
    <message>
        <source>AcetoneISO2::Progress</source>
        <translation type="obsolete">AcetoneISO2::Průběh</translation>
    </message>
    <message>
        <source>Please wait... work in progress</source>
        <translation>Čekejte... Pracuji</translation>
    </message>
    <message>
        <source>AcetoneISO::Progress</source>
        <translation>AcetoneISO::Průběh</translation>
    </message>
</context>
</TS>
