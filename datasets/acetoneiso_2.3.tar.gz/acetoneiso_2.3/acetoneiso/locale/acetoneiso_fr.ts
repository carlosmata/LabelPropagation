<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>about</name>
    <message>
        <source>About AcetoneISO2</source>
        <translation type="obsolete">A propos d&apos;AcetoneISO2</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Auteurs</translation>
    </message>
    <message>
        <source>&lt;html&gt;
&lt;head&gt;
  &lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;
 http-equiv=&quot;content-type&quot;&gt;
  &lt;title&gt;&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;span style=&quot;font-weight: bold;&quot;&gt;AcetoneISO2&lt;/span&gt; &lt;br&gt;
The cd/dvd image manipulator for linux&lt;br&gt;
is created by:&lt;br&gt;
&lt;br style=&quot;font-style: italic;&quot;&gt;
&lt;span style=&quot;font-style: italic;&quot;&gt;Fabrizio Di Marco&lt;/span&gt;
&amp;amp; &lt;span style=&quot;font-style: italic;&quot;&gt;Marco Di
Antonio&lt;/span&gt;
&lt;/body&gt;
&lt;/html&gt;
</source>
        <translation type="obsolete">&lt;html&gt;
&lt;head&gt;
&lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;
http-equiv=&quot;content-type&quot;&gt;
&lt;title&gt;&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;span style=&quot;font-weight: bold;&quot;&gt;AcetoneISO2&lt;/span&gt; &lt;br&gt;
Manipulateur d&apos;images cd/dvd pour linux&lt;br&gt;
créé par :&lt;br&gt;
&lt;br style=&quot;font-style: italic;&quot;&gt;
&lt;span style=&quot;font-style: italic;&quot;&gt;Fabrizio Di Marco&lt;/span&gt;
&amp;amp; &lt;span style=&quot;font-style: italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Contacts</translation>
    </message>
    <message>
        <source>&lt;html&gt;
&lt;head&gt;
  &lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;
 http-equiv=&quot;content-type&quot;&gt;
  &lt;title&gt;&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
You have many ways to contact us:&lt;big&gt;&lt;br&gt;
&lt;br&gt;
&lt;/big&gt;email: &lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;acetoneiso@gmail.com&lt;/a&gt;&lt;br&gt;
website: &lt;a href=&quot;http://acetoneiso.netsons.org&quot;&gt;http://acetoneiso.netsons.org&lt;/a&gt;&lt;br&gt;
irc: #acetoneiso server azzurra
&lt;/body&gt;
&lt;/html&gt;
</source>
        <translation type="obsolete">&lt;html&gt;
&lt;head&gt; 
&lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;
http-equiv=&quot;content-type&quot;&gt;
&lt;title&gt;&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
Vous pouvez nous contacter de plusieurs façons :&lt;big&gt;&lt;br&gt;
&lt;br&gt;
&lt;/big&gt;Email : &lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;acetoneiso@gmail.com&lt;/a&gt;&lt;br&gt;
Site Web : &lt;a href=&quot;http://acetoneiso.netsons.org&quot;&gt;http://acetoneiso.netsons.org&lt;/a&gt;&lt;br&gt;
irc : #acetoneiso server azzurra
&lt;/body&gt;
&lt;/html&gt;</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;span style=&quot; font-size:large;&quot;&gt;GNU GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Version 3, 29 June 2007 &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright © 2007 Free Software Foundation, Inc. &amp;lt;http://fsf.org/&amp;gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed. &lt;/p&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;preamble&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:large;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-size:large;&quot;&gt;reamble &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The GNU General Public License is a free, copyleft license for software and other kinds of works. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program--to make sure it remains free software for all its users. We, the Free Software Foundation, use the GNU General Public License for most of our software; it applies also to any other work released this way by its authors. You can apply it to your programs, too. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Developers that use the GNU GPL protect your rights with two steps: (1) assert copyright on the software, and (2) offer you this License giving you legal permission to copy, distribute and/or modify it. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For the developers&apos; and authors&apos; protection, the GPL clearly explains that there is no warranty for this free software. For both users&apos; and authors&apos; sake, the GPL requires that modified versions be marked as changed, so that their problems will not be attributed erroneously to authors of previous versions. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Some devices are designed to deny users access to install or run modified versions of the software inside them, although the manufacturer can do so. This is fundamentally incompatible with the aim of protecting users&apos; freedom to change the software. The systematic pattern of such abuse occurs in the area of products for individuals to use, which is precisely where it is most unacceptable. Therefore, we have designed this version of the GPL to prohibit the practice for those products. If such problems arise substantially in other domains, we stand ready to extend this provision to those domains in future versions of the GPL, as needed to protect the freedom of users. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Finally, every program is threatened constantly by software patents. States should not allow patents to restrict development and use of software on general-purpose computers, but in those that do, we wish to avoid the special danger that patents applied to a free program could make it effectively proprietary. To prevent this, the GPL assures that patents cannot be used to render the program non-free. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. &lt;/p&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;terms&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:large;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-size:large;&quot;&gt;ERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section0&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;0&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Definitions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;?This License? refers to version 3 of the GNU General Public License. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;?Copyright? also means copyright-like laws that apply to other kinds of works, such as semiconductor masks. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;?The Program? refers to any copyrightable work licensed under this License. Each licensee is addressed as ?you?. ?Licensees? and ?recipients? may be individuals or organizations. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To ?modify? a work means to copy from or adapt all or part of the work in a fashion requiring copyright permission, other than the making of an exact copy. The resulting work is called a ?modified version? of the earlier work or a work ?based on? the earlier work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A ?covered work? means either the unmodified Program or a work based on the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To ?propagate? a work means to do anything with it that, without permission, would make you directly or secondarily liable for infringement under applicable copyright law, except executing it on a computer or modifying a private copy. Propagation includes copying, distribution (with or without modification), making available to the public, and in some countries other activities as well. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To ?convey? a work means any kind of propagation that enables other parties to make or receive copies. Mere interaction with a user through a computer network, with no transfer of a copy, is not conveying. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;An interactive user interface displays ?Appropriate Legal Notices? to the extent that it includes a convenient and prominently visible feature that (1) displays an appropriate copyright notice, and (2) tells the user that there is no warranty for the work (except to the extent that warranties are provided), that licensees may convey the work under this License, and how to view a copy of this License. If the interface presents a list of user commands or options, such as a menu, a prominent item in the list meets this criterion. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Source Code. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The ?source code? for a work means the preferred form of the work for making modifications to it. ?Object code? means any non-source form of a work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A ?Standard Interface? means an interface that either is an official standard defined by a recognized standards body, or, in the case of interfaces specified for a particular programming language, one that is widely used among developers working in that language. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The ?System Libraries? of an executable work include anything, other than the work as a whole, that (a) is included in the normal form of packaging a Major Component, but which is not part of that Major Component, and (b) serves only to enable use of the work with that Major Component, or to implement a Standard Interface for which an implementation is available to the public in source code form. A ?Major Component?, in this context, means a major essential component (kernel, window system, and so on) of the specific operating system (if any) on which the executable work runs, or a compiler used to produce the work, or an object code interpreter used to run it. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The ?Corresponding Source? for a work in object code form means all the source code needed to generate, install, and (for an executable work) run the object code and to modify the work, including scripts to control those activities. However, it does not include the work&apos;s System Libraries, or general-purpose tools or generally available free programs which are used unmodified in performing those activities but which are not part of the work. For example, Corresponding Source includes interface definition files associated with source files for the work, and the source code for shared libraries and dynamically linked subprograms that the work is specifically designed to require, such as by intimate data communication or control flow between those subprograms and other parts of the work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The Corresponding Source need not include anything that users can regenerate automatically from other parts of the Corresponding Source. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The Corresponding Source for a work in source code form is that same work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;2&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Basic Permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All rights granted under this License are granted for the term of copyright on the Program, and are irrevocable provided the stated conditions are met. This License explicitly affirms your unlimited permission to run the unmodified Program. The output from running a covered work is covered by this License only if the output, given its content, constitutes a covered work. This License acknowledges your rights of fair use or other equivalent, as provided by copyright law. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Conveying under any other circumstances is permitted solely under the conditions stated below. Sublicensing is not allowed; section 10 makes it unnecessary. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Protecting Users&apos; Legal Rights From Anti-Circumvention Law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;No covered work shall be deemed part of an effective technological measure under any applicable law fulfilling obligations under article 11 of the WIPO copyright treaty adopted on 20 December 1996, or similar laws prohibiting or restricting circumvention of such measures. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When you convey a covered work, you waive any legal power to forbid circumvention of technological measures to the extent such circumvention is effected by exercising rights under this License with respect to the covered work, and you disclaim any intention to limit operation or modification of the work as a means of enforcing, against the work&apos;s users, your or third parties&apos; legal rights to forbid circumvention of technological measures. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;4&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Conveying Verbatim Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may convey verbatim copies of the Program&apos;s source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice; keep intact all notices stating that this License and any non-permissive terms added in accord with section 7 apply to the code; keep intact all notices of the absence of any warranty; and give all recipients a copy of this License along with the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may charge any price or no price for each copy that you convey, and you may offer support or warranty protection for a fee. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section5&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;5&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Conveying Modified Source Versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may convey a work based on the Program, or the modifications to produce it from the Program, in the form of source code under the terms of section 4, provided that you also meet all of these conditions: &lt;/p&gt;
&lt;ul style=&quot;-qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) The work must carry prominent notices stating that you modified it, and giving a relevant date. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) The work must carry prominent notices stating that it is released under this License and any conditions added under section 7. This requirement modifies the requirement in section 4 to ?keep intact all notices?. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) You must license the entire work, as a whole, under this License to anyone who comes into possession of a copy. This License will therefore apply, along with any applicable section 7 additional terms, to the whole of the work, and all its parts, regardless of how they are packaged. This License gives no permission to license the work in any other way, but it does not invalidate such permission if you have separately received it. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) If the work has interactive user interfaces, each must display Appropriate Legal Notices; however, if the Program has interactive interfaces that do not display Appropriate Legal Notices, your work need not make them do so. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A compilation of a covered work with other separate and independent works, which are not by their nature extensions of the covered work, and which are not combined with it such as to form a larger program, in or on a volume of a storage or distribution medium, is called an ?aggregate? if the compilation and its resulting copyright are not used to limit the access or legal rights of the compilation&apos;s users beyond what the individual works permit. Inclusion of a covered work in an aggregate does not cause this License to apply to the other parts of the aggregate. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section6&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;6&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Conveying Non-Source Forms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may convey a covered work in object code form under the terms of sections 4 and 5, provided that you also convey the machine-readable Corresponding Source under the terms of this License, in one of these ways: &lt;/p&gt;
&lt;ul style=&quot;-qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by the Corresponding Source fixed on a durable physical medium customarily used for software interchange. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by a written offer, valid for at least three years and valid for as long as you offer spare parts or customer support for that product model, to give anyone who possesses the object code either (1) a copy of the Corresponding Source for all the software in the product that is covered by this License, on a durable physical medium customarily used for software interchange, for a price no more than your reasonable cost of physically performing this conveying of source, or (2) access to copy the Corresponding Source from a network server at no charge. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Convey individual copies of the object code with a copy of the written offer to provide the Corresponding Source. This alternative is allowed only occasionally and noncommercially, and only if you received the object code with such an offer, in accord with subsection 6b. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Convey the object code by offering access from a designated place (gratis or for a charge), and offer equivalent access to the Corresponding Source in the same way through the same place at no further charge. You need not require recipients to copy the Corresponding Source along with the object code. If the place to copy the object code is a network server, the Corresponding Source may be on a different server (operated by you or a third party) that supports equivalent copying facilities, provided you maintain clear directions next to the object code saying where to find the Corresponding Source. Regardless of what server hosts the Corresponding Source, you remain obligated to ensure that it is available for as long as needed to satisfy these requirements. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Convey the object code using peer-to-peer transmission, provided you inform other peers where the object code and Corresponding Source of the work are being offered to the general public at no charge under subsection 6d. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A separable portion of the object code, whose source code is excluded from the Corresponding Source as a System Library, need not be included in conveying the object code work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A ?User Product? is either (1) a ?consumer product?, which means any tangible personal property which is normally used for personal, family, or household purposes, or (2) anything designed or sold for incorporation into a dwelling. In determining whether a product is a consumer product, doubtful cases shall be resolved in favor of coverage. For a particular product received by a particular user, ?normally used? refers to a typical or common use of that class of product, regardless of the status of the particular user or of the way in which the particular user actually uses, or expects or is expected to use, the product. A product is a consumer product regardless of whether the product has substantial commercial, industrial or non-consumer uses, unless such uses represent the only significant mode of use of the product. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;?Installation Information? for a User Product means any methods, procedures, authorization keys, or other information required to install and execute modified versions of a covered work in that User Product from a modified version of its Corresponding Source. The information must suffice to ensure that the continued functioning of the modified object code is in no case prevented or interfered with solely because modification has been made. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you convey an object code work under this section in, or with, or specifically for use in, a User Product, and the conveying occurs as part of a transaction in which the right of possession and use of the User Product is transferred to the recipient in perpetuity or for a fixed term (regardless of how the transaction is characterized), the Corresponding Source conveyed under this section must be accompanied by the Installation Information. But this requirement does not apply if neither you nor any third party retains the ability to install modified object code on the User Product (for example, the work has been installed in ROM). &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The requirement to provide Installation Information does not include a requirement to continue to provide support service, warranty, or updates for a work that has been modified or installed by the recipient, or for the User Product in which it has been modified or installed. Access to a network may be denied when the modification itself materially and adversely affects the operation of the network or violates the rules and protocols for communication across the network. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Corresponding Source conveyed, and Installation Information provided, in accord with this section must be in a format that is publicly documented (and with an implementation available to the public in source code form), and must require no special password or key for unpacking, reading or copying. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section7&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;7&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Additional Terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;?Additional permissions? are terms that supplement the terms of this License by making exceptions from one or more of its conditions. Additional permissions that are applicable to the entire Program shall be treated as though they were included in this License, to the extent that they are valid under applicable law. If additional permissions apply only to part of the Program, that part may be used separately under those permissions, but the entire Program remains governed by this License without regard to the additional permissions. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When you convey a copy of a covered work, you may at your option remove any additional permissions from that copy, or from any part of it. (Additional permissions may be written to require their own removal in certain cases when you modify the work.) You may place additional permissions on material, added by you to a covered work, for which you have or can give appropriate copyright permission. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Notwithstanding any other provision of this License, for material you add to a covered work, you may (if authorized by the copyright holders of that material) supplement the terms of this License with terms: &lt;/p&gt;
&lt;ul style=&quot;-qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Disclaiming warranty or limiting liability differently from the terms of sections 15 and 16 of this License; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Requiring preservation of specified reasonable legal notices or author attributions in that material or in the Appropriate Legal Notices displayed by works containing it; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Prohibiting misrepresentation of the origin of that material, or requiring that modified versions of such material be marked in reasonable ways as different from the original version; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Limiting the use for publicity purposes of names of licensors or authors of the material; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Declining to grant rights under trademark law for use of some trade names, trademarks, or service marks; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;f) Requiring indemnification of licensors and authors of that material by anyone who conveys the material (or modified versions of it) with contractual assumptions of liability to the recipient, for any liability that these contractual assumptions directly impose on those licensors and authors. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All other non-permissive additional terms are considered ?further restrictions? within the meaning of section 10. If the Program as you received it, or any part of it, contains a notice stating that it is governed by this License along with a term that is a further restriction, you may remove that term. If a license document contains a further restriction but permits relicensing or conveying under this License, you may add to a covered work material governed by the terms of that license document, provided that the further restriction does not survive such relicensing or conveying. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you add terms to a covered work in accord with this section, you must place, in the relevant source files, a statement of the additional terms that apply to those files, or a notice indicating where to find the applicable terms. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Additional terms, permissive or non-permissive, may be stated in the form of a separately written license, or stated as exceptions; the above requirements apply either way. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section8&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;8&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Termination. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may not propagate or modify a covered work except as expressly provided under this License. Any attempt otherwise to propagate or modify it is void, and will automatically terminate your rights under this License (including any patent licenses granted under the third paragraph of section 11). &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, you do not qualify to receive new licenses for the same material under section 10. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section9&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;9&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;. Acceptance Not Required for Having Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You are not required to accept this License in order to receive or run a copy of the Program. Ancillary propagation of a covered work occurring solely as a consequence of using peer-to-peer transmission to receive a copy likewise does not require acceptance. However, nothing other than this License grants you permission to propagate or modify any covered work. These actions infringe copyright if you do not accept this License. Therefore, by modifying or propagating a covered work, you indicate your acceptance of this License to do so. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section10&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;0. Automatic Licensing of Downstream Recipients. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each time you convey a covered work, the recipient automatically receives a license from the original licensors, to run, modify and propagate that work, subject to this License. You are not responsible for enforcing compliance by third parties with this License. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;An ?entity transaction? is a transaction transferring control of an organization, or substantially all assets of one, or subdividing an organization, or merging organizations. If propagation of a covered work results from an entity transaction, each party to that transaction who receives a copy of the work also receives whatever licenses to the work the party&apos;s predecessor in interest had or could give under the previous paragraph, plus a right to possession of the Corresponding Source of the work from the predecessor in interest, if the predecessor has it or can get it with reasonable efforts. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may not impose any further restrictions on the exercise of the rights granted or affirmed under this License. For example, you may not impose a license fee, royalty, or other charge for exercise of rights granted under this License, and you may not initiate litigation (including a cross-claim or counterclaim in a lawsuit) alleging that any patent claim is infringed by making, using, selling, offering for sale, or importing the Program or any portion of it. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section11&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1. Patents. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A ?contributor? is a copyright holder who authorizes use under this License of the Program or a work on which the Program is based. The work thus licensed is called the contributor&apos;s ?contributor version?. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A contributor&apos;s ?essential patent claims? are all patent claims owned or controlled by the contributor, whether already acquired or hereafter acquired, that would be infringed by some manner, permitted by this License, of making, using, or selling its contributor version, but do not include claims that would be infringed only as a consequence of further modification of the contributor version. For purposes of this definition, ?control? includes the right to grant patent sublicenses in a manner consistent with the requirements of this License. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each contributor grants you a non-exclusive, worldwide, royalty-free patent license under the contributor&apos;s essential patent claims, to make, use, sell, offer for sale, import and otherwise run, modify and propagate the contents of its contributor version. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In the following three paragraphs, a ?patent license? is any express agreement or commitment, however denominated, not to enforce a patent (such as an express permission to practice a patent or covenant not to sue for patent infringement). To ?grant? such a patent license to a party means to make such an agreement or commitment not to enforce a patent against the party. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you convey a covered work, knowingly relying on a patent license, and the Corresponding Source of the work is not available for anyone to copy, free of charge and under the terms of this License, through a publicly available network server or other readily accessible means, then you must either (1) cause the Corresponding Source to be so available, or (2) arrange to deprive yourself of the benefit of the patent license for this particular work, or (3) arrange, in a manner consistent with the requirements of this License, to extend the patent license to downstream recipients. ?Knowingly relying? means you have actual knowledge that, but for the patent license, your conveying the covered work in a country, or your recipient&apos;s use of the covered work in a country, would infringe one or more identifiable patents in that country that you have reason to believe are valid. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If, pursuant to or in connection with a single transaction or arrangement, you convey, or propagate by procuring conveyance of, a covered work, and grant a patent license to some of the parties receiving the covered work authorizing them to use, propagate, modify or convey a specific copy of the covered work, then the patent license you grant is automatically extended to all recipients of the covered work and works based on it. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A patent license is ?discriminatory? if it does not include within the scope of its coverage, prohibits the exercise of, or is conditioned on the non-exercise of one or more of the rights that are specifically granted under this License. You may not convey a covered work if you are a party to an arrangement with a third party that is in the business of distributing software, under which you make payment to the third party based on the extent of your activity of conveying the work, and under which the third party grants, to any of the parties who would receive the covered work from you, a discriminatory patent license (a) in connection with copies of the covered work conveyed by you (or copies made from those copies), or (b) primarily for and in connection with specific products or compilations that contain the covered work, unless you entered into that arrangement, or that patent license was granted, prior to 28 March 2007. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nothing in this License shall be construed as excluding or limiting any implied license or other defenses to infringement that may otherwise be available to you under applicable patent law. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section12&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;2. No Surrender of Others&apos; Freedom. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot convey a covered work so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not convey it at all. For example, if you agree to terms that obligate you to collect a royalty for further conveying from those to whom you convey the Program, the only way you could satisfy both those terms and this License would be to refrain entirely from conveying the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section13&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;3. Use with the GNU Affero General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Notwithstanding any other provision of this License, you have permission to link or combine any covered work with a work licensed under version 3 of the GNU Affero General Public License into a single combined work, and to convey the resulting work. The terms of this License will continue to apply to the part which is the covered work, but the special requirements of the GNU Affero General Public License, section 13, concerning interaction through a network will apply to the combination as such. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section14&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;4. Revised Versions of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The Free Software Foundation may publish revised and/or new versions of the GNU General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each version is given a distinguishing version number. If the Program specifies that a certain numbered version of the GNU General Public License ?or any later version? applies to it, you have the option of following the terms and conditions either of that numbered version or of any later version published by the Free Software Foundation. If the Program does not specify a version number of the GNU General Public License, you may choose any version ever published by the Free Software Foundation. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If the Program specifies that a proxy can decide which future versions of the GNU General Public License can be used, that proxy&apos;s public statement of acceptance of a version permanently authorizes you to choose that version for the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Later license versions may give you additional or different permissions. However, no additional obligations are imposed on any author or copyright holder as a result of your choosing to follow a later version. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section15&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;5. Disclaimer of Warranty. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM ?AS IS? WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section16&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;6. Limitation of Liability. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;section17&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium;&quot;&gt;7. Interpretation of Sections 15 and 16. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If the disclaimer of warranty and limitation of liability provided above cannot be given local legal effect according to their terms, reviewing courts shall apply local law that most closely approximates an absolute waiver of all civil liability in connection with the Program, unless a warranty or assumption of liability accompanies a copy of the Program in return for a fee. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;END OF TERMS AND CONDITIONS &lt;/p&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;a name=&quot;howto&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:large;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-size:large;&quot;&gt;ow to Apply These Terms to Your New Programs &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you develop a new program, and you want it to be of the greatest possible use to the public, the best way to achieve this is to make it free software which everyone can redistribute and change under these terms. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To do so, attach the following notices to the program. It is safest to attach them to the start of each source file to most effectively state the exclusion of warranty; and each file should have at least the ?copyright? line and a pointer to where the full notice is found. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    &amp;lt;one line to give the program&apos;s name and a brief idea of what it does.&amp;gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This program is free software: you can redistribute it and/or modify&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    it under the terms of the GNU General Public License as published by&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    the Free Software Foundation, either version 3 of the License, or&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    (at your option) any later version.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This program is distributed in the hope that it will be useful,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    GNU General Public License for more details.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    You should have received a copy of the GNU General Public License&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    along with this program.  If not, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Also add information on how to contact you by electronic and paper mail. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If the program does terminal interaction, make it output a short notice like this when it starts in an interactive mode: &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    &amp;lt;program&amp;gt;  Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This is free software, and you are welcome to redistribute it&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    under certain conditions; type `show c&apos; for details. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate parts of the General Public License. Of course, your program&apos;s commands might be different; for a GUI interface, you would use an ?about box?. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You should also get your employer (if you work as a programmer) or school, if any, to sign a ?copyright disclaimer? for the program, if necessary. For more information on this, and how to apply and follow the GNU GPL, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The GNU General Public License does not permit incorporating your program into proprietary programs. If your program is a subroutine library, you may consider it more useful to permit linking proprietary applications with the library. If this is what you want to do, use the GNU Lesser General Public License instead of this License. But first, please read &amp;lt;http://www.gnu.org/philosophy/why-not-lgpl.htm&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">taille de police&lt;h3 style=&quot;text-align:center&quot;&gt;&lt;big&gt;L&lt;/big&gt;ICENCE &lt;big&gt;P&lt;/big&gt;UBLIQUE &lt;big&gt;G&lt;/big&gt;ÉNÉRALE &lt;big&gt;GNU&lt;/big&gt;&lt;/h3&gt;
&lt;p style=&quot;text-align:center&quot;&gt;Version 3, du 29 juin 2007.&lt;/p&gt;
&lt;p&gt;Copyright (C) 2007 Free Software Foundation, Inc. &amp;lt;&lt;a href=&quot;http://fsf.org/&quot;&gt;http://fsf.org/&lt;/a&gt;&amp;gt;&lt;/p&gt;
&lt;p&gt;Chacun est autorisé à copier et distribuer des copies conformes de ce
document de licence, mais toute modification en est proscrite.&lt;/p&gt;

&lt;div class=&quot;notice&quot; style=&quot;border:2px solid #DDDDDD;background:#EEEEEE;color:#000000;padding:0.5em&quot;&gt;
&lt;script type=&quot;text/javascript&quot;&gt;&lt;!--
 a=&apos;&amp;#x40;&apos;;p=&apos;.&apos;;z=&apos;fr&apos;;h=&apos;wan&amp;#x61;doo&apos;;u=&apos;verdy&amp;#x5f;p&apos;;
 document.write(&apos;&lt;p&gt;&lt;strong&gt;Traduction française&lt;/strong&gt; par Philippe Verdy&apos;+
  &apos; &amp;lt;&lt;a href=&quot;mai&apos;+&apos;lto&apos;+&apos;:&apos;+u+a+h+p+z+&apos;&quot;&gt;&apos;+u + &apos; &lt;em&gt;(à)&lt;/em&gt; &apos;+h+&apos; &lt;em&gt;(point)&lt;/em&gt; &apos;+z+
  &apos;&lt;/a&gt;&amp;gt;, le 30 juin 2007.&lt;/p&gt;&apos;);
//--&gt;&lt;/script&gt;&lt;noscript&gt;&lt;p&gt;&lt;strong&gt;Traduction française&lt;/strong&gt; par Philippe Verdy
 &amp;lt;&lt;a&gt;verdy&amp;#x5f;p &lt;em&gt;(à)&lt;/em&gt; wan&amp;#x61;doo &lt;em&gt;(point)&lt;/em&gt; fr&lt;/a&gt;&amp;gt;,
 le 30 juin 2007.&lt;/p&gt;&lt;/noscript&gt;
 &lt;h3&gt;Avertissement important au sujet de cette traduction française.&lt;/h3&gt;
 &lt;p&gt;Ceci est une traduction en français de la licence &lt;em lang=&quot;en&quot;&gt;“GNU
  General Public License”&lt;/em&gt; (GPL). Cette traduction est fournie ici dans
  l’espoir qu’elle facilitera sa compréhension, mais elle ne constitue pas
  une traduction officielle ou approuvée d’un point de vue juridique.&lt;/p&gt;
 &lt;p&gt;La &lt;em lang=&quot;en&quot;&gt;Free Software Foundation&lt;/em&gt; (FSF) ne publie pas cette
  traduction et ne l’a pas approuvée en tant que substitut valide au plan
  légal pour la licence authentique &lt;em lang=&quot;en&quot;&gt;“GNU General Public
  Licence”&lt;/em&gt;. Cette traduction n’a pas encore été passée en revue
  attentivement par un juriste et donc le traducteur ne peut garantir avec
  certitude qu’elle représente avec exactitude la signification légale des
  termes de la licence authentique &lt;em lang=&quot;en&quot;&gt;“GNU General Public
  License”&lt;/em&gt; publiée en anglais. Cette traduction n’établit donc légalement
  aucun des termes et conditions d’utilisation d’un logiciel sous licence GNU
  GPL&amp;nbsp;— seul le texte original en anglais le fait. Si vous souhaitez
  être sûr que les activités que vous projetez seront autorisées par la &lt;em
  lang=&quot;en&quot;&gt;GNU General Public License&lt;/em&gt;, veuillez vous référer à sa seule
  version anglaise authentique.&lt;/p&gt;
 &lt;p&gt;La FSF vous recommande fermement de ne pas utiliser cette traduction en
  tant que termes officiels pour vos propres programmes&amp;nbsp;; veuillez plutôt
  utiliser la version anglaise authentique telle que publiée par la FSF. Si
  vous choisissez d’acheminer cette traduction en même temps qu’un Programme
  sous licence GNU GPL, cela ne vous dispense pas de l’obligation d’acheminer
  en même temps une copie de la licence authentique en anglais, et de
  conserver dans la traduction cet avertissement important en français et son
  équivalent en anglais ci-dessous.&lt;/p&gt;
 &lt;h3&gt;&lt;em lang=&quot;en&quot;&gt;Important Warning About This French Translation.&lt;/em&gt;&lt;/h3&gt;
 &lt;p&gt;&lt;em lang=&quot;en&quot;&gt;This is a translation of the GNU General Public License
  (GPL) into French. This translation is distributed in the hope that it will
  facilitate understanding, but it is not an official or legally approved
  translation.&lt;/em&gt;&lt;/p&gt;
 &lt;p&gt;&lt;em lang=&quot;en&quot;&gt;The Free Software Foundation (FSF) is not the publisher of
  this translation and has not approved it as a legal substitute for the
  authentic GNU General Public License. The translation has not been reviewed
  carefully by lawyers, and therefore the translator cannot be sure that it
  exactly represents the legal meaning of the authentic GNU General Public
  License published in English. This translation does not legally state the
  terms and conditions of use of any Program licenced under GNU GPL&amp;nbsp;—
  only the original English text of the GNU LGPL does that. If you wish to be
  sure whether your planned activities are permitted by the GNU General Public
  License, please refer to its sole authentic English version.&lt;/em&gt;&lt;/p&gt;
 &lt;p&gt;&lt;em lang=&quot;en&quot;&gt;The FSF strongly urges you not to use this translation as
  the official distribution terms for your programs; instead, please use the
  authentic English version published by the FSF. If you choose to convey
  this translation along with a Program covered by the GPL Licence, this does
  not remove your obligation to convey at the same time a copy of the
  authentic GNU GPL License in English, and you must keep in this translation
  this important warning in English and its equivalent in French above.&lt;/em&gt;&lt;/p&gt;
&lt;/div&gt;

&lt;h3&gt;&lt;a name=&quot;preamble&quot;&gt;&lt;/a&gt;Préambule&lt;/h3&gt;

&lt;p&gt;La Licence Publique Générale GNU (&lt;em lang=&quot;en&quot;&gt;“GNU General Public
License”&lt;/em&gt;) est une licence libre, en &lt;em lang=&quot;en&quot;&gt;“copyleft”&lt;/em&gt;,
destinée aux œuvres logicielles et d’autres types de travaux.&lt;/p&gt;

&lt;p&gt;Les licences de la plupart des œuvres logicielles et autres travaux de
pratique sont conçues pour ôter votre liberté de partager et modifier ces
travaux. En contraste, la Licence Publique Générale GNU a pour but de garantir
votre liberté de partager et changer toutes les versions d’un programme&amp;nbsp;—
afin d’assurer qu’il restera libre pour tous les utilisateurs. Nous, la &lt;em
lang=&quot;en&quot;&gt;Free Software Foundation&lt;/em&gt;, utilisons la Licence Publique
Générale GNU pour la plupart de nos logiciels&amp;nbsp;; cela s’applique aussi à
tout autre travail édité de cette façon par ses auteurs. Vous pouvez, vous
aussi, l’appliquer à vos propres programmes.&lt;/p&gt;

&lt;p&gt;Quand nous parlons de logiciel libre (&lt;em lang=&quot;en&quot;&gt;“free”&lt;/em&gt;), nous
nous référons à la liberté (&lt;em lang=&quot;en&quot;&gt;“freedom”&lt;/em&gt;), pas au prix. Nos
Licences Publiques Générales sont conçues pour assurer que vous ayez la
liberté de distribuer des copies de logiciel libre (et le facturer si vous le
souhaitez), que vous receviez le code source ou pouviez l’obtenir si vous le
voulez, que vous pouviez modifier le logiciel ou en utiliser toute partie dans
de nouveaux logiciels libres, et que vous sachiez que vous avez le droit de
faire tout ceci.&lt;/p&gt;

&lt;p&gt;Pour protéger vos droits, nous avons besoin d’empêcher que d’autres vous
restreignent ces droits ou vous demande de leur abandonner ces droits. En
conséquence, vous avez certaines responsabilités si vous distribuez des copies
d’un tel programme ou si vous le modifiez : les responsabilités de respecter la
liberté des autres.&lt;/p&gt;

&lt;p&gt;Par exemple, si vous distribuez des copies d’un tel programme, que ce soit
gratuit ou contre un paiement, vous devez accorder aux Destinataires les mêmes
libertés que vous avez reçues. Vous devez aussi vous assurer qu’eux aussi
reçoivent ou peuvent recevoir son code source. Et vous devez leur montrer les
termes de cette licence afin qu’ils connaissent leurs droits.&lt;/p&gt;

&lt;p&gt;Les développeurs qui utilisent la GPL GNU protègent vos droits en deux
étapes&amp;nbsp;: (1) ils affirment leur droits d’auteur (&lt;em
lang=&quot;en&quot;&gt;“copyright”&lt;/em&gt;) sur le logiciel, et (2) vous accordent cette
Licence qui vous donne la permission légale de le copier, le distribuer et/ou
le modifier.&lt;/p&gt;

&lt;p&gt;Pour la protection des développeurs et auteurs, la GPL stipule clairement
qu’il n’y a pas de garantie pour ce logiciel libre. Aux fins à la fois des
utilisateurs et auteurs, la GPL requière que les versions modifiées soient
marquées comme changées, afin que leurs problèmes ne soient pas attribués de
façon erronée aux auteurs des versions précédentes.&lt;/p&gt;

&lt;p&gt;Certains dispositifs sont conçus pour empêcher l’accès des utilisateurs à
l’installation ou l’exécution de versions modifiées du logiciel à l’intérieur
de ces dispositifs, alors que les fabricants le peuvent. Ceci est
fondamentalement incompatible avec le but de protéger la liberté des
utilisateurs de modifier le logiciel. L’aspect systématique de tels abus se
produit dans le secteur des produits destinés aux utilisateurs individuels, ce
qui est précidément ce qui est le plus inacceptable. Aussi, nous avons conçu
cette version de la GPL pour prohiber cette pratique pour ces produits. Si de
tels problèmes surviennent dans d’autres domaines, nous nous tenons prêt à
étendre cette restriction à ces domaines dans de futures versions de la GPL,
autant qu’il sera nécessaire pour protéger la liberté des utilisateurs.&lt;/p&gt;

&lt;p&gt;Finalement, chaque programme est constamment menacé par les brevets
logiciels. Les États ne devraient pas autoriser de tels brevets à restreindre
le développement et l’utilisation de logiciels libres sur des ordinateurs
d’usage général&amp;nbsp;; mais dans ceux qui le font, nous voulons spécialement
éviter le danger que les brevets appliqués à un programme libre puisse le
rendre effectivement propriétaire. Pour empêcher ceci, la GPL assure que les
brevets ne peuvent être utilisés pour rendre le programme non-libre.&lt;/p&gt;

&lt;p&gt;Les termes précis et conditions concernant la copie, la distribution et la
modification suivent.&lt;/p&gt;

&lt;h3&gt;&lt;a name=&quot;terms&quot;&gt;&lt;/a&gt;&lt;big&gt;T&lt;/big&gt;ERMES ET CONDITIONS&lt;/h3&gt;

&lt;h4&gt;&lt;a name=&quot;section0&quot;&gt;&lt;/a&gt;Article 0. Définitions.&lt;/h4&gt;

&lt;p&gt;«&amp;nbsp;Cette Licence&amp;nbsp;» se réfère à la version 3 de la &lt;em lang=&quot;en&quot;&gt;“GNU General
Public License”&lt;/em&gt; (le texte original en anglais).&lt;/p&gt;

&lt;p&gt;«&amp;nbsp;Droit d’Auteur&amp;nbsp;» signifie aussi les droits du “copyright” ou
voisins qui s’appliquent à d’autres types de travaux, tels que ceux sur les
masques de semi-conducteurs.&lt;/p&gt;
 
&lt;p&gt;«&amp;nbsp;Le Programme&amp;nbsp;» se réfère à tout travail qui peut être sujet au Droit
d’Auteur (“copyright”) et dont les droits d’utilisation sont concédés en vertu
de cette Licence. Chacun des Licenciés, à qui cette Licence est concédée, est
désigné par «&amp;nbsp;vous.&amp;nbsp;» Les «&amp;nbsp;Licenciés&amp;nbsp;» et les «&amp;nbsp;Destinataires&amp;nbsp;»
peuvent être des personnes physiques ou morales (individus ou organisations).&lt;/p&gt;

&lt;p&gt;«&amp;nbsp;Modifier&amp;nbsp;» un travail signifie en obtenir une copie et adapter
tout ou partie du travail d’une façon nécessitant une autorisation d’un
titulaire de Droit d’Auteur, autre que celle permettant d’en produire une
copie conforme. Le travail résultant est appelé une «&amp;nbsp;version modifiée&amp;nbsp;»
du précédent travail, ou un travail «&amp;nbsp;basé sur&amp;nbsp;» le précédent travail.&lt;/p&gt;

&lt;p&gt;Un «&amp;nbsp;Travail Couvert&amp;nbsp;» signifie soit le Programme non modifié soit un
travail basé sur le Programme.&lt;/p&gt;

&lt;p&gt;«&amp;nbsp;Propager&amp;nbsp;» un travail signifie faire quoi que ce soit avec lui qui, sans
permission, vous rendrait directement ou indirectement responsable d’un délit
de contrefaçon suivant les lois relatives au Droit d’Auteur, à l’exception de
son exécution sur un ordinateur ou de la modification d’une copie privée. La
propagation inclue la copie, la distribution (avec ou sans modification), la
mise à disposition envers le public, et aussi d&apos;autres activités dans certains
pays.&lt;/p&gt;

&lt;p&gt;«&amp;nbsp;Acheminer&amp;nbsp;» un travail signifie tout moyen de propagation de
celui-ci qui permet à d’autres parties de réaliser ou recevoir des copies. La
simple interaction d’un utilisateur à travers un réseau informatique, sans
transfert effectif d’une copie, ne constitue pas un acheminement.&lt;/p&gt;

&lt;p&gt;Une interface utilisateur interactive affiche des «&amp;nbsp;Notices Légales
Appropriées&amp;nbsp;» quand elle comprend un dispositif convenable, bien visible
et évident qui (1) affiche une notice appropriée sur les droits d’auteur et
(2) informe l’utilisateur qu’il n’y a pas de garantie pour le travail (sauf si
des garanties ont été fournies hors du cadre de cette Licence), que les
licenciés peuvent acheminer le travail sous cette Licence, et comment voir une
copie de cette Licence. Si l’interface présente une liste de commandes
utilisateur ou d’options, tel qu’un menu, un élément évident dans la liste
présentée remplit ce critère.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section1&quot;&gt;&lt;/a&gt;Article 1. Code source.&lt;/h4&gt;

&lt;p&gt;Le «&amp;nbsp;code source&amp;nbsp;» d’un travail signifie la forme préférée du travail
permettant ou facilitant les modifications de celui-ci. Le «&amp;nbsp;code objet&amp;nbsp;»
d’un travail signifie toute forme du travail qui n’en est pas le code source.&lt;/p&gt;

&lt;p&gt;Une «&amp;nbsp;Interface Standard&amp;nbsp;» signifie une interface qui est soit celle d’une
norme officielle définie par un organisme de normalisation reconnu ou, dans le
cas des interfaces spécifiées pour un langage de programmation particulier,
une interface largement utilisée parmi les développeurs travaillant dans ce
langage.&lt;/p&gt;

&lt;p&gt;Les «&amp;nbsp;Bibliothèques Système&amp;nbsp;» d’un travail exécutable incluent tout ce qui,
en dehors du travail dans son ensemble, (a) est inclus dans la forme usuelle
de paquetage d’un Composant Majeur mais ne fait pas partie de ce Composant
Majeur et (b) sert seulement à permettre l’utilisation du travail avec ce
Composant Majeur ou à implémenter une Interface Standard pour laquelle une
implémentation est disponible au public sous forme de code source&amp;nbsp;; un
«&amp;nbsp;Composant Majeur&amp;nbsp;» signifie, dans ce contexte, un composant majeur essentiel
(noyau, système de fenêtrage, etc.) du système d’exploitation (le cas échéant)
d’un système sur lequel le travail exécutable fonctionne, ou bien un
compilateur utilisé pour produire le code objet du travail, ou un interprète
de code objet utilisé pour exécuter celui-ci.&lt;/p&gt;

&lt;p&gt;Le «&amp;nbsp;Source Correspondant&amp;nbsp;» d’un travail sous forme de code objet
signifie l’ensemble des codes sources nécessaires pour générer, installer et
(dans le cas d’un travail exécutable) exécuter le code objet et modifier le
travail, y compris les scripts pour contrôler ces activités. Cependant, cela
n’inclue pas les Bibliothèques Système du travail, ni les outils d’usage
général ou les programmes libres généralement disponibles qui peuvent être
utilisés sans modification pour achever ces activités mais ne sont pas partie
de ce travail. Par exemple le Source Correspondant inclut les fichiers de
définition d’interfaces associés aux fichiers sources du travail, et le code
source des bibliothèques partagées et des sous-routines liées dynamiquement,
pour lesquelles le travail est spécifiquement conçu pour les requérir via,
par exemple, des communications de données ou contrôles de flux internes entre
ces sous-programmes et d’autres parties du travail.&lt;/p&gt;

&lt;p&gt;Le Source Correspondant n’a pas besoin d’inclure tout ce que les
utilisateurs peuvent regénérer automatiquement à partir d’autres parties du
Source Correspondant.&lt;/p&gt;

&lt;p&gt;Le Source Correspondant pour un travail sous forme de code source est ce
même travail.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section2&quot;&gt;&lt;/a&gt;Article 2. Permissions de base.&lt;/h4&gt;

&lt;p&gt;Tous les droits accordés suivant cette Licence le sont jusqu’au terme des
Droits d’Auteur (“copyright”) sur le Programme, et sont irrévocables pourvu
que les conditions établies soient remplies. Cette Licence affirme
explicitement votre permission illimitée d’exécuter le Programme non modifié.
La sortie produite par l’exécution d’un Travail Couvert n’est couverte par
cette Licence que si cette sortie, étant donné leur contenu, constitue un
Travail Couvert. Cette Licence reconnait vos propres droits d’usage
raisonnable (“fair use” en législation des États-Unis d’Amérique) ou autres
équivalents, tels qu’ils sont pourvus par la loi applicable sur le Droit
d’Auteur (“copyright”).&lt;/p&gt;

&lt;p&gt;Vous pouvez créer, exécuter et propager sans condition des Travaux Couverts
que vous n’acheminez pas, aussi longtemps que votre licence demeure en vigueur.
Vous pouvez acheminer des Travaux Couverts à d’autres personnes dans le seul
but de leur faire réaliser des modifications à votre usage exclusif, ou pour
qu’ils vous fournissent des facilités vous permettant d’exécuter ces travaux,
pourvu que vous vous conformiez aux termes de cette Licence lors de
l’acheminement de tout matériel dont vous ne contrôlez pas le 
Droit d’Auteur
(“copyright”). Ceux qui, dès lors, réalisent ou exécutent pour vous les
Travaux Couverts ne doivent alors le faire qu’exclusivement pour votre propre
compte, sous votre direction et votre contrôle, suivant des termes qui leur
interdisent de réaliser, en dehors de leurs relations avec vous, toute copie
de votre matériel soumis au Droit d’Auteur.&lt;/p&gt;

&lt;p&gt;L’acheminement dans toutes les autres circonstances n’est permis que selon
les conditions établies ci-dessous. La concession de sous-licences n’est pas
autorisé&amp;nbsp;; l’article 10 rend cet usage non nécessaire.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section3&quot;&gt;&lt;/a&gt;Article 3. Protection des droits légaux des utilisateurs envers les lois anti-contournement.&lt;/h4&gt;

&lt;p&gt;Aucun Travail Couvert ne doit être vu comme faisant partie d’une mesure
technologique effective selon toute loi applicable remplissant les obligations
prévues à l’article 11 du traité international sur le droit d’auteur adopté à
l’OMPI le 20 décembre 1996, ou toutes lois similaires qui prohibent ou
restreignent le contournement de telles mesures.&lt;/p&gt;

&lt;p&gt;Si vous acheminez un Travail Couvert, vous renoncez à tout pouvoir légal
d’interdire le contournement des mesures technologiques dans tous les cas où
un tel contournement serait effectué en exerçant les droits prévus dans cette
Licence pour ce Travail Couvert, et vous déclarez rejeter toute intention de
limiter l’opération ou la modification du Travail, en tant que moyens de
renforcer, à l’encontre des utilisateurs de ce Travail, vos droits légaux ou
ceux de tierces parties d’interdire le contournement des mesures
technologiques.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section4&quot;&gt;&lt;/a&gt;Article 4. Acheminement des copies conformes.&lt;/h4&gt;

&lt;p&gt;Vous pouvez acheminer des copies conformes du code source du Programme tel
que vous l’avez reçu, sur n’importe quel support, pourvu que vous publiiez
scrupuleusement et de façon appropriée sur chaque copie une notice de Droit
d’Auteur appropriée&amp;nbsp;; gardez intactes toutes les notices établissant que
cette Licence et tous les termes additionnels non permissifs ajoutés en accord

avec l’article 7 s’appliquent à ce code&amp;nbsp;; et donnez à chacun des
Destinataires une copie de cette Licence en même temps que le Programme.&lt;/p&gt;

&lt;p&gt;Vous pouvez facturer un prix quelconque, y compris gratuit, pour chacune
des copies que vous acheminez, et vous pouvez offrir une protection
additionnelle de support ou de garantie en échange d’un paiement.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section5&quot;&gt;&lt;/a&gt;Article 5. Acheminement des versions sources modifiées.&lt;/h4&gt;

&lt;p&gt;Vous pouvez acheminer un travail basé sur le Programme, ou bien les
modifications pour le produire à partir du Programme, sous la forme de code
source suivant les termes de l’article 4, pourvu que vous satisfassiez aussi
à chacune des conditions requises suivantes&amp;nbsp;:&lt;/p&gt;

&lt;ul&gt;
&lt;li&gt;a) Le travail doit comporter des notices évidentes établissant que vous
 l’avez modifié et donnant la date correspondante.&lt;/li&gt;

&lt;li&gt;b) Le travail doit comporter des notices évidentes établissant qu’il est
 édité selon cette Licence et les conditions ajoutées d’après l’article 7.
 Cette obligation vient modifier l’obligation de l’article 4 de «&amp;nbsp;garder
 intactes toutes les notices.&amp;nbsp;»&lt;/li&gt;

&lt;li&gt;c) Vous devez licencier le travail entier, comme un tout, suivant cette
 Licence à quiconque entre en possession d’une copie. Cette Licence
 s’appliquera en conséquence, avec les termes additionnels applicables prévus
 par l’article 7, à la totalité du travail et chacune de ses parties,
 indépendamment de la façon dont ils sont empaquetés. Cette licence ne donne
 aucune permission de licencier le travail d’une autre façon, mais elle
 n’invalide pas une telle permission si vous l’avez reçue séparément.&lt;/li&gt;

&lt;li&gt;d) Si le travail a des interfaces utilisateurs interactives, chacune doit
 afficher les Notices Légales Appropriées&amp;nbsp;; cependant si le Programme a
 des interfaces qui n’affichent pas les Notices Légales Appropriées, votre
 travail n’a pas à les modifier pour qu’elles les affichent.&lt;/li&gt;
&lt;/ul&gt;

&lt;p&gt;Une compilation d’un Travail Couvert avec d’autres travaux séparés et
indépendants, qui ne sont pas par leur nature des extensions du Travail
Couvert, et qui ne sont pas combinés avec lui de façon à former un programme
plus large, dans ou sur un volume de stockage ou un support de distribution,
est appelé un «&amp;nbsp;aggrégat&amp;nbsp;» si la compilation et son Droit d’Auteur
résultant ne sont pas utilisés pour limiter l’accès ou les droits légaux des
utilisateurs de la compilation en deça de ce que permettent les travaux
individuels. L’inclusion d’un Travail Couvert dans un aggrégat ne cause pas
l’application de cette Licence aux autres parties de l’aggrégat.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section6&quot;&gt;&lt;/a&gt;Article 6. Acheminement des formes non sources.&lt;/h4&gt;

&lt;p&gt;Vous pouvez acheminer sous forme de code objet un Travail Couvert suivant
les termes des articles 4 et 5, pourvu que vous acheminiez également suivant
les termes de cette Licence le Source Correspondant lisible par une machine,
d’une des façons suivantes&amp;nbsp;:&lt;/p&gt;

&lt;ul&gt;
&lt;li&gt;a) Acheminer le code objet sur, ou inclus dans, un produit physique (y
 compris un support de distribution physique), accompagné par le Source
 Correspondant fixé sur un support physique durable habituellement utilisé
 pour les échanges de logiciels.&lt;/li&gt;

&lt;li&gt;b) Acheminer le code objet sur, ou inclus dans, un produit physique (y
 compris un support de distribution physique), accompagné d’une offre écrite,
 valide pour au moins trois années et valide pour aussi longtemps que vous
 fournissez des pièces de rechange ou un support client pour ce modèle de
 produit, afin de donner à quiconque possède le code objet soit (1) une copie
 du Source Correspondant à tout logiciel dans ce produit qui est couvert par
 cette Licence, sur un support physique durable habituellement utilisé pour
 les échanges de logiciels, pour un prix non supérieur au coût raisonnable
 de la réalisation physique de l’acheminement de la source, ou soit (2) un
 accès permettant de copier le Source Correspondant depuis un serveur réseau
 sans frais.&lt;/li&gt;

&lt;li&gt;c) Acheminer des copies individuelles du code objet avec une copie de
 l’offre écrite de fournir le Source Correspondant. Cette alternative est
 permise seulement occasionellement et non-commercialement, et seulement si
 vous avez reçu le code objet avec une telle offre, en accord avec
 l’article 6 alinéa b.&lt;/li&gt;

&lt;li&gt;d) Acheminer le code objet en offrant un accès depuis un emplacement
 désigné (gratuit ou contre facturation) et offrir un accès équivalent au
 Source Correspondant de la même façon via le même emplacement et sans
 facturation supplémentaire. Vous n’avez pas besoin d’obliger les
 Destinataires à copier le Source Correspondant en même temps que le code
 objet. Si l’emplacement pour copier le code objet est un serveur réseau,
 le Source Correspondant peut être sur un serveur différent (opéré par vous
 ou par un tiers) qui supporte des facilités équivalentes de copie, pourvu
 que vous mainteniez des directions claires à proximité du code objet
 indiquant où trouver le Source Correspondant. Indépendamment de quel serveur
 héberge le Source Correspondant, vous restez obligé de vous assurer qu’il
 reste disponible aussi longtemps que nécessaire pour satisfaire à ces
 obligations.&lt;/li&gt;

&lt;li&gt;e) Acheminer le code objet en utilisant une transmission 
d’égal-à-égal,
 pourvu que vous informiez les autres participants sur où le code objet et
 le Source Correspondant du travail sont offerts sans frais au public
 général suivant l’article 6 alinéa d.&lt;/li&gt;
&lt;/ul&gt;

&lt;p&gt;Une portion séparable du code objet, dont le code source est exclu du
Source Correspondant en tant que Bibliothèque Système, n’a pas besoin d’être
inclu dans l’acheminement du travail sous forme de code objet.&lt;/p&gt;

&lt;p&gt;Un «&amp;nbsp;Produit Utilisateur&amp;nbsp;» est soit (1) un «&amp;nbsp;Produit de Consommation,&amp;nbsp;»
ce qui signifie toute propriété personnelle tangible normalement utilisée à
des fins personnelles, familiales ou relatives au foyer, soit (2) toute
chose conçue ou vendue pour l’incorporation dans un lieu d’habitation. Pour
déterminer si un produit constitue un Produit de Consommation, les cas ambigus
sont résolus en fonction de la couverture. Pour un produit particulier reçu
par un utilisateur particulier, l’expression «&amp;nbsp;normalement utilisée&amp;nbsp;» ci-avant
se réfère à une utilisation typique ou l’usage commun de produits de même
catégorie, indépendamment du statut de cet utilisateur particulier ou de la
façon spécifique dont cet utilisateur particulier utilise effectivement ou
s’attend lui-même ou est attendu à utiliser ce produit. Un produit est un
Produit de Consommation indépendamment du fait que ce produit a ou n’a pas
d’utilisations substantielles commerciales, industrielles ou hors
Consommation, à moins que de telles utilisations représentent le seul mode
significatif d’utilisation du produit.&lt;/p&gt;

&lt;p&gt;Les «&amp;nbsp;Informations d’Installation&amp;nbsp;» d’un Produit Utilisateur signifient
toutes les méthodes, procédures, clés d’autorisation ou autres informations
requises pour installer et exécuter des versions modifiées d’un Travail
Couvert dans ce Produit Utilisateur à partir d’une version modifiée de son
Source Correspondant. Les informations qui suffisent à assurer la continuité
de fonctionnement du code objet modifié ne doivent en aucun cas être empêchées
ou interférées du seul fait qu’une modification a été effectuée.&lt;/p&gt;

&lt;p&gt;Si vous acheminez le code objet d’un Travail Couvert dans, ou avec, ou
spécifiquement pour l’utilisation dans, un Produit Utilisateur et
l’acheminement se produit en tant qu’élément d’une transaction dans laquelle
le droit de possession et d’utilisation du Produit Utilisateur est transféré
au Destinataire définitivement ou pour un terme fixé (indépendamment de la
façon dont la transaction est caractérisée), le Source Correspondant acheminé
selon cet article-ci doit être accompagné des Informations d’Installation.
Mais cette obligation ne s’applique pas si ni vous ni aucune tierce partie
ne détient la possibilité d’intaller un code objet modifié sur le Produit
Utilisateur (par exemple, le travail a été installé en mémoire morte).&lt;/p&gt;

&lt;p&gt;L’obligation de fournir les Informations d’Installation n’inclue pas
celle de continuer à fournir un service de support, une garantie ou des mises
à jour pour un travail qui a été modifié ou installé par le Destinataire, ou
pour le Produit Utilisateur dans lequel il a été modifié ou installé. L’accès
à un réseau peut être rejeté quand la modification elle-même affecte
matériellement et défavorablement les opérations du réseau ou viole les règles
et protocoles de communication au travers du réseau.&lt;/p&gt;

&lt;p&gt;Le Source Correspondant acheminé et les Informations d’Installation
fournies, en accord avec cet article, doivent être dans un format publiquement
documenté (et dont une implémentation est disponible auprès du public sous
forme de code source) et ne doit nécessiter aucune clé ou mot de passe spécial
pour le dépaquetage, la lecture ou la copie.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section7&quot;&gt;&lt;/a&gt;Article 7. Termes additionnels.&lt;/h4&gt;

&lt;p&gt;Les « permissions additionelles » désignent les termes qui supplémentent
ceux de cette Licence en émettant des exceptions à l’une ou plusieurs de ses
conditions. Les permissions additionnelles qui sont applicables au Programme
entier doivent être traitées comme si elles étaient incluent dans cette
Licence, dans les limites de leur validité suivant la loi applicable. Si des
permissions additionnelles s’appliquent seulement à une partie du Programme,
cette partie peut être utilisée séparément suivant ces permissions, mais le
Programme tout entier reste gouverné par cette Licence sans regard aux
permissions additionelles.&lt;/p&gt;

&lt;p&gt;Quand vous acheminez une copie d’un Travail Couvert, vous pouvez à votre
convenance ôter toute permission additionelle de cette copie, ou de n’importe
quelle partie de celui-ci. (Des permissions additionnelles peuvent être
rédigées de façon à requérir leur propre suppression dans certains cas où vous
modifiez le travail.) Vous pouvez placer les permissions additionnelles sur le
matériel acheminé, ajoutées par vous à un Travail Couvert pour lequel vous
avez ou pouvez donner les permissions de Droit d’Auteur (“copyright”)
appropriées.&lt;/p&gt;

&lt;p&gt;Nonobstant toute autre clause de cette Licence, pour tout constituant
que vous ajoutez à un Travail Couvert, vous pouvez (si autorisé par les
titulaires de Droit d’Auteur pour ce constituant) supplémenter les termes de
cette Licence avec des termes&amp;nbsp;:&lt;/p&gt;

&lt;ul&gt;
&lt;li&gt;a) qui rejettent la garantie ou limitent la responsabilité de façon
 différente des termes des articles 15 et 16 de cette Licence&amp;nbsp;;
 ou&lt;/li&gt;

&lt;li&gt;b) qui requièrent la préservation de notices légales raisonnables
 spécifiées ou les attributions d’auteur dans ce constituant ou dans les
 Notices Légales Appropriées affichées par les travaux qui le
 contiennent&amp;nbsp;; ou&lt;/li&gt;

&lt;li&gt;c) qui prohibent la représentation incorrecte de l’origine de ce
 constituant, ou qui requièrent que les versions modifiées d’un tel
 constituant soit marquées par des moyens raisonnables comme différentes de la
 version originale&amp;nbsp;; ou&lt;/li&gt;

&lt;li&gt;d) qui limitent l’usage à but publicitaire des noms des concédants de
 licence et des auteurs du constituant&amp;nbsp;; ou&lt;/li&gt;

&lt;li&gt;e) qui refusent à accorder des droits selon la législation relative aux
 marques commerciales, pour l’utilisation dans des noms commerciaux, marques
 commerciales ou marques de services&amp;nbsp;; ou&lt;/li&gt;

&lt;li&gt;f) qui requièrent l’indemnisation des concédants de licences et auteurs du
 constituant par quiconque achemine ce constituant (ou des versions modifiées
 de celui-ci) en assumant contractuellement la responsabilité envers le
 Destinataire, pour toute responsabilité que ces engagements contractuels
 imposent directement à ces octroyants de licences et auteurs.&lt;/li&gt;
&lt;/ul&gt;

&lt;p&gt;Tous les autres termes additionnels non permissifs sont considérés comme
des « restrictions avancées » dans le sens de l’article 10. Si le Programme
tel que vous l’avez reçu, ou toute partie de celui-ci, contient une notice
établissant qu’il est gouverné par cette Licence en même temps qu’un terme qui
est une restriction avancée, vous pouvez ôter ce terme. Si un document de
licence contient une restriction avancée mais permet la reconcession de
licence ou l’acheminement suivant cette Licence, vous pouvez ajouter un Travail
Couvert constituant gouverné par les termes de ce document de licence, pourvu
que la restriction avancée ne survit pas à un telle cession de licence ou
acheminement.&lt;/p&gt;

&lt;p&gt;Si vous ajoutez des termes à un Travail Couvert en accord avec cet article,
vous devez placer, dans les fichiers sources appropriés, une déclaration des
termes additionnels qui s’appliquent à ces fichiers, ou une notice indiquant
où trouver les termes applicables.&lt;/p&gt;

&lt;p&gt;Les termes additionnels, qu’ils soient permissifs ou non permissifs,
peuvent être établis sous la forme d’une licence écrite séparément, ou établis
comme des exceptions&amp;nbsp;; les obligations ci-dessus s’appliquent dans chacun
de ces cas.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section8&quot;&gt;&lt;/a&gt;Article 8. Terminaison.&lt;/h4&gt;

&lt;p&gt;Vous ne pouvez ni propager ni modifier un Travail Couvert autrement que
suivant les termes de cette Licence. Toute autre tentative de le propager ou
le modifier est nulle et terminera automatiquement vos droits selon cette
Licence (y compris toute licence de brevet accordée selon le troisième
paragraphe de l’article 11).&lt;/p&gt;

&lt;p&gt;Cependant, si vous cessez toute violation de cette Licence, alors votre
licence depuis un titulaire de Droit d’Auteur (“copyright”) est réinstaurée
(a) à titre provisoire à moins que et jusqu’à ce que le titulaire de Droit
d’Auteur termine finalement et explicitement votre licence, et (b) de façon
permanente si le titulaire de Droit d’Auteur ne parvient pas à vous notifier
de la violation par quelque moyen raisonnable dans les soixante (60) jours
après la cessation.&lt;/p&gt;

&lt;p&gt;De plus, votre licence depuis un titulaire particulier de Droit d’Auteur
est réinstaurée de façon permanente si ce titulaire vous notifie de la
violation par quelque moyen raisonnable, c’est la première fois que vous avez
reçu une notification deviolation de cette Licence (pour un travail
quelconque) depuis ce titulaire de Droit d’Auteur, et vous résolvez la
violation dans les trente (30) jours qui suivent votre réception de la
notification.&lt;/p&gt;

&lt;p&gt;La terminaison de vos droits suivant cette section ne terminera pas les
licences des parties qui ont reçu des copies ou droits de votre part suivant
cette Licence. Si vos droits ont été terminés et non réinstaurés de façon
permanente, vous n’êtes plus qualifié à recevoir de nouvelles licences pour
les mêmes constituants selon l’article 10.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section9&quot;&gt;&lt;/a&gt;Article 9. Acceptation non requise pour obtenir des copies.&lt;/h4&gt;

&lt;p&gt;Vous n’êtes pas obligé d’accepter cette licence afin de recevoir ou
exécuter une copie du Programme. La propagation asservie d’un Travail Couvert
qui se produit simplement en conséquence d’une transmission d’égal-à-égal
pour recevoir une copie ne nécessite pas l’acceptation. Cependant, rien
d’autre que cette Licence ne vous accorde la permission de propager ou
modifier un quelconque Travail Couvert. Ces actions enfreignent le Droit
d’Auteur si vous n’acceptez pas cette Licence. Par conséquent, en modifiant
ou propageant un Travail Couvert, vous indiquez votre acceptation de cette
Licence pour agir ainsi.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section10&quot;&gt;&lt;/a&gt;Article 10. Cession automatique de Licence aux Destinataires et intermédiaires.&lt;/h4&gt;

&lt;p&gt;Chaque fois que vous acheminez un Travail Couvert, le Destinataire reçoit
automatiquement une licence depuis les concédants originaux, pour exécuter,
modifier et propager ce travail, suivant les termes de cette Licence. Vous
n’êtes pas responsable du renforcement de la conformation des tierces parties
avec cette Licence.&lt;/p&gt;

&lt;p&gt;Une «&amp;nbsp;transaction d’entité&amp;nbsp;» désigne une transaction qui transfère le
contrôle d’une organisation, ou de substantiellement tous ses actifs, ou la
subdivision d’une organisation, ou la fusion de plusieurs organisations. Si
la propagation d’un Travail Couvert résulte d’une transaction d’entité,
chaque partie à cette transaction qui reçoit une copie du travail reçoit
aussi les licences pour le travail que le prédécesseur intéressé à cette
partie avait ou pourrait donner selon le paragraphe précédent, plus un
droit de possession du Source Correspondant de ce travail depuis le
prédécesseur intéressé si ce prédécesseur en dispose ou peut l’obtenir par des
efforts raisonnables.&lt;/p&gt;

&lt;p&gt;Vous ne pouvez imposer aucune restriction avancée dans l’exercice des
droits accordés ou affirmés selon cette Licence. Par exemple, vous ne pouvez
imposer aucun paiement pour la licence, aucune royaltie, ni aucune autre
charge pour l’exercice des droits accordés selon cette Licence&amp;nbsp;; et vous ne
pouvez amorcer aucun litige judiciaire (y compris une réclamation croisée ou
contre-réclamation dans un procès) sur l’allégation qu’une revendication de
brevet est enfreinte par la réalisation, l’utilisation, la vente, l’offre de
vente, ou l’importation du Programme ou d’une quelconque portion de
celui-ci.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section11&quot;&gt;&lt;/a&gt;Article 11. Brevets.&lt;/h4&gt;

&lt;p&gt;Un « contributeur » est un titulaire de Droit d’Auteur (&lt;em lang=&quot;en&quot;&gt;“copyright”&lt;/em&gt;) qui
autorise l’utilisation selon cette Licence du Programme ou du travail sur
lequel le Programme est basé. Le travail ainsi soumis à licence est appelé la
«&amp;nbsp;version contributive&amp;nbsp;» de ce contributeur.&lt;/p&gt;

&lt;p&gt;Les «&amp;nbsp;revendications de brevet essentielles&amp;nbsp;» sont toutes les
revendications de brevets détenues ou contrôlées par le contributeur, qu’elles
soient déjà acquises par lui ou acquises subséquemment, qui pourraient être
enfreintes de quelque manière, permises par cette Licence, sur la réalisation,
l’utilisation ou la vente de la version contributive de celui-ci. Aux fins de
cette définition, le «&amp;nbsp;contrôle&amp;nbsp;» inclue le droit de concéder des
sous-licences de brevets d’une manière consistante, nécessaire et suffisante,
avec les obligations de cette Licence.&lt;/p&gt;

&lt;p&gt;Chaque contributeur vous accorde une licence de brevet non exclusive,
mondiale et libre de toute royaltie, selon les revendications de brevet
essentielles, pour réaliser, utiliser, vendre, offrir à la vente, importer
et autrement exécuter, modifier et propager les contenus de sa version
contributive.&lt;/p&gt;

&lt;p&gt;Dans les trois paragraphes suivants, une «&amp;nbsp;licence de brevet&amp;nbsp;» désigne
tous les accords ou engagements exprimés, quel que soit le nom que vous lui
donnez, de ne pas mettre en vigueur un brevet (telle qu’une permission
explicite pour mettre en pratique un brevet, ou un accord pour ne pas
poursuivre un Destinataire pour cause de violation de brevet).
«&amp;nbsp;Accorder&amp;nbsp;» une telle licence de brevet à une partie signifie
conclure un tel accord ou engagement à ne pas faire appliquer le brevet à
cette partie.&lt;/p&gt;

&lt;p&gt;Si vous acheminez un Travail Couvert, dépendant en connaissance d’une
licence de brevet, et si le Source Correspondant du travail n’est pas
disponible à quiconque copie, sans frais et suivant les termes de cette
Licence, à travers un serveur réseau publiquement acessible ou tout autre
moyen immédiatement accessible, alors vous devez soit (1) rendre la Source
Correspondante ainsi disponible, soit (2) vous engager à vous priver pour
vous-même du bénéfice de la licence de brevet pour ce travail particulier,
soit (3) vous engager, d’une façon consistante avec les obligations de cette
Licence, à étendre la licence de brevet aux Destinataires de ce travail.
«&amp;nbsp;Dépendant en connaissance&amp;nbsp;» signifie que vous avez effectivement
connaissance que, selon la licence de brevet, votre acheminement du Travail
Couvert dans un pays, ou l’utilisation du Travail Couvert par votre
Destinataire dans un pays, infreindrait un ou plusieurs brevets identifiables
dans ce pays où vous avez des raisons de penser qu’ils sont valides.&lt;/p&gt;
 
&lt;p&gt;Si, conformément à ou en liaison avec une même transaction ou un même
arrangement, vous acheminez, ou propagez en procurant un acheminement de,
un Travail Couvert et accordez une licence de brevet à l’une des parties
recevant le Travail Couvert pour lui permettre d’utiliser, propager, modifier
ou acheminer une copie spécifique du Travail Couvert, alors votre accord est
automatiquement étendu à tous les Destinataires du Travail Couvert et des
travaux basés sur celui-ci.&lt;/p&gt;

&lt;p&gt;Une licence de brevet est «&amp;nbsp;discriminatoire&amp;nbsp;» si, dans le champ de sa
couverture, elle n’inclut pas un ou plusieurs des droits qui sont spécifiquement
accordés selon cette Licence, ou en prohibe l’exercice, ou est conditionnée
par le non-exercice d’un ou plusieurs de ces droits. Vous ne pouvez pas
acheminer un Travail Couvert si vous êtes partie à un arrangement selon lequel
une partie tierce exerçant son activité dans la distribution de logiciels et à
laquelle vous effectuez un paiement fondé sur l’étendue de votre activité
d’acheminement du travail, et selon lequel la partie tierce accorde, à une
quelconque partie qui recevrait depuis vous le Travail Couvert, une licence
de brevet discriminatoire (a) en relation avec les copies du Travail Couvert
acheminées par vous (ou les copies réalisées à partir de ces copies), ou (b)
avant tout destinée et en relation avec des produits spécifiques ou
compilations contenant le Travail Couvert, à moins que vous ayez conclu cet
arrangement ou que la licence de brevet ait été accordée avant le 28 mars
2007.&lt;/p&gt;

&lt;p&gt;Rien dans cette Licence ne devrait être interprété comme devant exclure ou
limiter toute licence implicite ou d’autres moyens de défense à une infraction
qui vous seraient autrement disponible selon la loi applicable relative aux
brevets.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section12&quot;&gt;&lt;/a&gt;Article 12. Non abandon de la liberté des autres.&lt;/h4&gt;

&lt;p&gt;Si des conditions vous sont imposées (que ce soit par décision judiciaire,
par un accord ou autrement) qui contredisent les conditions de cette Licence,
elles ne vous excusent pas des conditions de cette Licence. Si vous ne pouvez
pas acheminer un Travail Couvert de façon à satisfaire simulténément vos
obligations suivant cette Licence et toutes autres obligations pertinentes,
alors en conséquence vous ne pouvez pas du tout l’acheminer. Par exemple, si
vous avez un accord sur des termes qui vous obligent à collecter pour le
réacheminement des royalties depuis ceux à qui vous acheminez le Programme,
la seule façon qui puisse vous permettre de satisfaire à la fois à ces termes
et ceux de cette Licence sera de vous abstenir entièrement d’acheminer le
Programme.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section13&quot;&gt;&lt;/a&gt;Article 13. Utilisation avec la Licence Générale Publique Affero GNU.&lt;/h4&gt;

&lt;p&gt;Nonobstant toute autre clause de cette Licence, vous avez la permission de
lier ou combiner tout Travail Couvert avec un travail placé sous la version 3
de la Licence Générale Publique GNU Affero (&lt;em lang=&quot;en&quot;&gt;“GNU Affero General Public
License”&lt;/em&gt;) en un seul travail combiné, et d’acheminer le travail
résultant. Les termes de cette Licence continueront à s’appliquer à la partie
formant un Travail Couvert, mais les obligations spéciales de la Licence
Générale Publique GNU Affero, article 13, concernant l’interaction à travers
un réseau s’appliqueront à la combinaison en tant que telle.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section14&quot;&gt;&lt;/a&gt;Article 14. Versions révisées de cette License.&lt;/h4&gt;

&lt;p&gt;La &lt;em lang=&quot;en&quot;&gt;Free Software Foundation&lt;/em&gt; peut publier des versions révisées et/ou
nouvelles de la Licence Publique Générale GNU (&lt;em lang=&quot;en&quot;&gt;“GNU General Public License”&lt;/em&gt;)
de temps en temps. De telles version nouvelles resteront similaires dans l’esprit
avec la présente version, mais peuvent différer dans le détail afin de traiter
de nouveaux problèmes ou préoccupations.&lt;/p&gt;

&lt;p&gt;Chaque version reçoit un numéro de version distinctif. Si le Programme
indique qu’une version spécifique de la Licence Publique Générale GNU «&amp;nbsp;ou
toute version ultérieure&amp;nbsp;» (&lt;em lang=&quot;en&quot;&gt;“or any later version”&lt;/em&gt;) s’applique à celui-ci,
vous avez le choix de suivre soit les termes et conditions de cette version
numérotée, soit ceux de n’importe quelle version publiée ultérieurement par la
&lt;em lang=&quot;en&quot;&gt;Free Software Foundation&lt;/em&gt;. Si le Programme n’indique pas une version spécifique
de la Licence Publique Générale GNU, vous pouvez choisir l’une quelconque des
versions qui ont été publiées par la &lt;em lang=&quot;en&quot;&gt;Free Software Foundation&lt;/em&gt;.&lt;/p&gt;

&lt;p&gt;Si le Programme spécifie qu’un intermédiaire peut décider quelles versions
futures de la Licence Générale Publique GNU peut être utilisée, la déclaration
publique d’acceptation d’une version par cet intermédiaire vous autorise à
choisir cette version pour le Programme.&lt;/p&gt;

&lt;p&gt;Des versions ultérieures de la licence peuvent vous donner des permissions
additionelles ou différentes. Cependant aucune obligation additionelle n’est
imposée à l’un des auteurs ou titulaires de Droit d’Auteur du fait de votre
choix de suivre une version ultérieure.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section15&quot;&gt;&lt;/a&gt;Article 15. Déclaration d’absence de garantie.&lt;/h4&gt;

&lt;p&gt;&lt;big&gt;I&lt;/big&gt;L N’Y A AUCUNE GARANTIE POUR LE &lt;big&gt;P&lt;/big&gt;ROGRAMME, DANS LES LIMITES PERMISES PAR LA
LOI APPLICABLE. &lt;big&gt;À&lt;/big&gt; MOINS QUE CELA NE SOIT ÉTABLI DIFFÉREMMENT PAR ÉCRIT, LES PROPRIÉTAIRES
DE DROITS ET/OU LES AUTRES PARTIES FOURNISSENT LE &lt;big&gt;P&lt;/big&gt;ROGRAMME «&amp;nbsp;EN L’ÉTAT&amp;nbsp;»
SANS GARANTIE D’AUCUNE SORTE, QU’ELLE SOIT EXPRIMÉE OU IMPLICITE, CECI COMPRENANT,
SANS SE LIMITER À CELLES-CI, LES GARANTIES IMPLICITES DE COMMERCIALISABILITÉ ET
D’ADÉQUATION À UN OBJECTIF PARTICULIER. &lt;big&gt;V&lt;/big&gt;OUS ASSUMEZ LE RISQUE ENTIER CONCERNANT
LA QUALITÉ ET LES PERFORMANCES DU &lt;big&gt;P&lt;/big&gt;ROGRAMME. &lt;big&gt;D&lt;/big&gt;ANS L’ÉVENTUALITÉ OÙ LE &lt;big&gt;P&lt;/big&gt;ROGRAMME
S’AVÉRERAIT DÉFECTUEUX, VOUS ASSUMEZ LES COÛTS DE TOUS LES SERVICES, RÉPARATIONS OU
CORRECTIONS NÉCESSAIRES.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section16&quot;&gt;&lt;/a&gt;Article 16. Limitation de responsabilité.&lt;/h4&gt;

&lt;p&gt;&lt;big&gt;E&lt;/big&gt;N AUCUNE AUTRE CIRCONSTANCE QUE CELLES REQUISES PAR LA LOI APPLICABLE OU
ACCORDÉES PAR ÉCRIT, UN TITULAIRE DE DROITS SUR LE &lt;big&gt;P&lt;/big&gt;ROGRAMME, OU TOUT AUTRE
PARTIE QUI MODIFIE OU ACHEMINE LE &lt;big&gt;P&lt;/big&gt;ROGRAMME COMME PERMIS CI-DESSUS, NE PEUT
ÊTRE TENU POUR RESPONSABLE ENVERS VOUS POUR LES DOMMAGES, INCLUANT TOUT
DOMMAGE GÉNÉRAL, SPÉCIAL, ACCIDENTEL OU INDUIT SURVENANT PAR SUITE DE
L’UTILISATION OU DE L’INCAPACITÉ D’UTILISER LE &lt;big&gt;P&lt;/big&gt;ROGRAMME (Y COMPRIS, SANS
SE LIMITER À CELLES-CI, LA PERTE DE DONNÉES OU L’INEXACTITUDE DES DONNÉES
RETOURNÉES OU LES PERTES SUBIES PAR VOUS OU DES PARTIES TIERCES OU
L’INCAPACITÉ DU &lt;big&gt;P&lt;/big&gt;ROGRAMME À FONCTIONNER AVEC TOUT AUTRE
 PROGRAMME), MÊME SI
UN TEL TITULAIRE OU TOUTE AUTRE PARTIE A ÉTÉ AVISÉ DE LA POSSIBILITÉ DE TELS
DOMMAGES.&lt;/p&gt;

&lt;h4&gt;&lt;a name=&quot;section17&quot;&gt;&lt;/a&gt;Article 17. Interprétation des sections 15 et 16.&lt;/h4&gt;

&lt;p&gt;Si la déclaration d’absence de garantie et la limitation de responsabilité
fournies ci-dessus ne peuvent prendre effet localement selon leurs termes, les
cours de justice qui les examinent doivent appliquer la législation locale qui
approche au plus près possible une levée absolue de toute responsabilité
civile liée au Programme, à moins qu’une garantie ou assumation de
responsabilité accompagne une copie du Programme en échange d’un paiement.&lt;/p&gt;

&lt;p&gt;&lt;big&gt;F&lt;/big&gt;IN DES TERMES ET CONDITIONS.&lt;/p&gt;

&lt;h3&gt;&lt;a name=&quot;howto&quot;&gt;&lt;/a&gt;Comment appliquer ces termes à vos nouveaux
programmes&lt;/h3&gt;

&lt;p&gt;Si vous développez un nouveau programme et voulez qu’il soit le plus
possible utilisable par le public, la meilleure façon d’y parvenir et d’en
faire un logiciel libre que chacun peut redistribuer et changer suivant ces
termes-ci.&lt;/p&gt;

&lt;p&gt;Pour appliquer ces termes, attachez les notices suivantes au programme. Il
est plus sûr de les attacher au début de chacun des fichiers sources afin de
transporter de façon la plus effective possible l’exclusion de garantie&amp;nbsp;;
et chaque fichier devrait comporter au moins la ligne de réservation de droit
(&lt;em lang=&quot;en&quot;&gt;“copyright”&lt;/em&gt;) et une indication permettant de savoir où la
notice complète peut être trouvée&amp;nbsp;:&lt;/p&gt;

&lt;pre&gt;  &lt;var&gt;&amp;lt;une ligne donnant le nom du programme et une brève idée de ce qu’il fait.&amp;gt;&lt;/var&gt;
  Copyright (C) &lt;var&gt;&amp;lt;année&amp;gt;&lt;/var&gt; &lt;var&gt;&amp;lt;nom de l’auteur&amp;gt;&lt;/var&gt; — Tous droits réservés.
  
  Ce programme est un logiciel libre&amp;nbsp;; vous pouvez le redistribuer ou le
  modifier suivant les termes de la &lt;em lang=&quot;en&quot;&gt;“GNU General Public License”&lt;/em&gt; telle que
  publiée par la &lt;em lang=&quot;en&quot;&gt;Free Software Foundation&lt;/em&gt;&amp;nbsp;: soit la version 3 de cette
  licence, soit (à votre gré) toute version ultérieure.
  
  Ce programme est distribué dans l’espoir qu’il vous sera utile, mais SANS
  AUCUNE GARANTIE&amp;nbsp;: sans même la garantie implicite de COMMERCIALISABILITÉ
  ni d’ADÉQUATION À UN OBJECTIF PARTICULIER. Consultez la Licence Générale
  Publique GNU pour plus de détails.
  
  Vous devriez avoir reçu une copie de la Licence Générale Publique GNU avec
  ce programme&amp;nbsp;; si ce n’est pas le cas, consultez&amp;nbsp;:
  &amp;lt;&lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;http://www.gnu.org/licenses/&lt;/a&gt;&amp;gt;.&lt;/pre&gt;

&lt;p&gt;Ajoutez également les informations permettant de vous contacter par
courrier électronique ou postal.&lt;/p&gt;

&lt;p&gt;Si le programme produit une interaction sur un terminal, faites lui
afficher une courte notice comme celle-ci lors de son démarrage en mode
interactif&amp;nbsp;:&lt;/p&gt;

&lt;pre&gt;  &lt;var&gt;&amp;lt;programme&amp;gt;&lt;/var&gt; Copyright (C) &lt;var&gt;&amp;lt;année&amp;gt;&lt;/var&gt; &lt;var&gt;&amp;lt;nom de l’auteur&amp;gt;&lt;/var&gt;
  Ce programme vient SANS ABSOLUMENT AUCUNE GARANTIE ; taper “&lt;var&gt;affiche g&lt;/var&gt;” pour
  les détails. Ceci est un logiciel libre et vous êtes invité à le redistribuer
  suivant certaines conditions&amp;nbsp;; taper “&lt;var&gt;affiche c&lt;/var&gt;” pour les détails.&lt;/pre&gt;

&lt;p&gt;Les commandes hypothétiques “&lt;var&gt;affiche g&lt;/var&gt;” and “&lt;var&gt;affiche c&lt;/var&gt;” devrait afficher
les parties appropriées de la Licence Générale Publique. Bien sûr, les
commandes de votre programme peuvent être différentes ; pour une interface
graphique, vous pourriez utiliser une « boîte À propos. »&lt;/p&gt;

&lt;p&gt;Vous devriez également obtenir de votre employeur (si vous travaillez en
tant que programmeur) ou de votre école un «&amp;nbsp;renoncement aux droits de
propriété&amp;nbsp;» pour ce programme, si nécessaire. Pour plus d’informations
à ce sujet, et comment appliquer la GPL GNU, consultez
&amp;lt;&lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;http://www.gnu.org/licenses/&lt;/a&gt;&amp;gt;.&lt;/p&gt;

&lt;p&gt;La Licence Générale Publique GNU ne permet pas d’incorporer votre programme
dans des programmes propriétaires. Si votre programme est une bibliothèque de
sous-routines, vous pourriez considérer qu’il serait plus utile de permettre de
lier des applications propriétaires avec la bibliothèque. Si c’est ce que vous
voulez faire, utilisez la Licence Générale Publique Limitée GNU au lieu de
cette Licence ; mais d’abord, veuillez lire
&amp;lt;&lt;a href=&quot;http://www.gnu.org/philosophy/why-not-lgpl.html&quot;&gt;http://www.gnu.org/philosophy/why-not-lgpl.html&lt;/a&gt;&amp;gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>ok</source>
        <translation type="obsolete">ok</translation>
    </message>
    <message>
        <source>About AcetoneISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Honor &amp;&amp; Glory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;You can contact us by email at:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0000ff;&quot;&gt;acetoneiso@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Official Website:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.acetoneteam.org/&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.acetoneteam.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;GNU GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Version 3, 29 June 2007 &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Copyright © 2007 Free Software Foundation, Inc. &amp;lt;http://fsf.org/&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;preamble&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;reamble &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The GNU General Public License is a free, copyleft license for software and other kinds of works. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program--to make sure it remains free software for all its users. We, the Free Software Foundation, use the GNU General Public License for most of our software; it applies also to any other work released this way by its authors. You can apply it to your programs, too. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Developers that use the GNU GPL protect your rights with two steps: (1) assert copyright on the software, and (2) offer you this License giving you legal permission to copy, distribute and/or modify it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For the developers&apos; and authors&apos; protection, the GPL clearly explains that there is no warranty for this free software. For both users&apos; and authors&apos; sake, the GPL requires that modified versions be marked as changed, so that their problems will not be attributed erroneously to authors of previous versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Some devices are designed to deny users access to install or run modified versions of the software inside them, although the manufacturer can do so. This is fundamentally incompatible with the aim of protecting users&apos; freedom to change the software. The systematic pattern of such abuse occurs in the area of products for individuals to use, which is precisely where it is most unacceptable. Therefore, we have designed this version of the GPL to prohibit the practice for those products. If such problems arise substantially in other domains, we stand ready to extend this provision to those domains in future versions of the GPL, as needed to protect the freedom of users. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Finally, every program is threatened constantly by software patents. States should not allow patents to restrict development and use of software on general-purpose computers, but in those that do, we wish to avoid the special danger that patents applied to a free program could make it effectively proprietary. To prevent this, the GPL assures that patents cannot be used to render the program non-free. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;terms&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;ERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section0&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;0&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Definitions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“This License” refers to version 3 of the GNU General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Copyright” also means copyright-like laws that apply to other kinds of works, such as semiconductor masks. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“The Program” refers to any copyrightable work licensed under this License. Each licensee is addressed as “you”. “Licensees” and “recipients” may be individuals or organizations. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “modify” a work means to copy from or adapt all or part of the work in a fashion requiring copyright permission, other than the making of an exact copy. The resulting work is called a “modified version” of the earlier work or a work “based on” the earlier work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “covered work” means either the unmodified Program or a work based on the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “propagate” a work means to do anything with it that, without permission, would make you directly or secondarily liable for infringement under applicable copyright law, except executing it on a computer or modifying a private copy. Propagation includes copying, distribution (with or without modification), making available to the public, and in some countries other activities as well. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “convey” a work means any kind of propagation that enables other parties to make or receive copies. Mere interaction with a user through a computer network, with no transfer of a copy, is not conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;An interactive user interface displays “Appropriate Legal Notices” to the extent that it includes a convenient and prominently visible feature that (1) displays an appropriate copyright notice, and (2) tells the user that there is no warranty for the work (except to the extent that warranties are provided), that licensees may convey the work under this License, and how to view a copy of this License. If the interface presents a list of user commands or options, such as a menu, a prominent item in the list meets this criterion. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Source Code. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “source code” for a work means the preferred form of the work for making modifications to it. “Object code” means any non-source form of a work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “Standard Interface” means an interface that either is an official standard defined by a recognized standards body, or, in the case of interfaces specified for a particular programming language, one that is widely used among developers working in that language. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “System Libraries” of an executable work include anything, other than the work as a whole, that (a) is included in the normal form of packaging a Major Component, but which is not part of that Major Component, and (b) serves only to enable use of the work with that Major Component, or to implement a Standard Interface for which an implementation is available to the public in source code form. A “Major Component”, in this context, means a major essential component (kernel, window system, and so on) of the specific operating system (if any) on which the executable work runs, or a compiler used to produce the work, or an object code interpreter used to run it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “Corresponding Source” for a work in object code form means all the source code needed to generate, install, and (for an executable work) run the object code and to modify the work, including scripts to control those activities. However, it does not include the work&apos;s System Libraries, or general-purpose tools or generally available free programs which are used unmodified in performing those activities but which are not part of the work. For example, Corresponding Source includes interface definition files associated with source files for the work, and the source code for shared libraries and dynamically linked subprograms that the work is specifically designed to require, such as by intimate data communication or control flow between those subprograms and other parts of the work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Corresponding Source need not include anything that users can regenerate automatically from other parts of the Corresponding Source. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Corresponding Source for a work in source code form is that same work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;2&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Basic Permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;All rights granted under this License are granted for the term of copyright on the Program, and are irrevocable provided the stated conditions are met. This License explicitly affirms your unlimited permission to run the unmodified Program. The output from running a covered work is covered by this License only if the output, given its content, constitutes a covered work. This License acknowledges your rights of fair use or other equivalent, as provided by copyright law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Conveying under any other circumstances is permitted solely under the conditions stated below. Sublicensing is not allowed; section 10 makes it unnecessary. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Protecting Users&apos; Legal Rights From Anti-Circumvention Law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No covered work shall be deemed part of an effective technological measure under any applicable law fulfilling obligations under article 11 of the WIPO copyright treaty adopted on 20 December 1996, or similar laws prohibiting or restricting circumvention of such measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When you convey a covered work, you waive any legal power to forbid circumvention of technological measures to the extent such circumvention is effected by exercising rights under this License with respect to the covered work, and you disclaim any intention to limit operation or modification of the work as a means of enforcing, against the work&apos;s users, your or third parties&apos; legal rights to forbid circumvention of technological measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;4&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Verbatim Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey verbatim copies of the Program&apos;s source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice; keep intact all notices stating that this License and any non-permissive terms added in accord with section 7 apply to the code; keep intact all notices of the absence of any warranty; and give all recipients a copy of this License along with the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may charge any price or no price for each copy that you convey, and you may offer support or warranty protection for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section5&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;5&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Modified Source Versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey a work based on the Program, or the modifications to produce it from the Program, in the form of source code under the terms of section 4, provided that you also meet all of these conditions: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) The work must carry prominent notices stating that you modified it, and giving a relevant date. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) The work must carry prominent notices stating that it is released under this License and any conditions added under section 7. This requirement modifies the requirement in section 4 to “keep intact all notices”. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) You must license the entire work, as a whole, under this License to anyone who comes into possession of a copy. This License will therefore apply, along with any applicable section 7 additional terms, to the whole of the work, and all its parts, regardless of how they are packaged. This License gives no permission to license the work in any other way, but it does not invalidate such permission if you have separately received it. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) If the work has interactive user interfaces, each must display Appropriate Legal Notices; however, if the Program has interactive interfaces that do not display Appropriate Legal Notices, your work need not make them do so. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A compilation of a covered work with other separate and independent works, which are not by their nature extensions of the covered work, and which are not combined with it such as to form a larger program, in or on a volume of a storage or distribution medium, is called an “aggregate” if the compilation and its resulting copyright are not used to limit the access or legal rights of the compilation&apos;s users beyond what the individual works permit. Inclusion of a covered work in an aggregate does not cause this License to apply to the other parts of the aggregate. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section6&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;6&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Non-Source Forms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey a covered work in object code form under the terms of sections 4 and 5, provided that you also convey the machine-readable Corresponding Source under the terms of this License, in one of these ways: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by the Corresponding Source fixed on a durable physical medium customarily used for software interchange. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by a written offer, valid for at least three years and valid for as long as you offer spare parts or customer support for that product model, to give anyone who possesses the object code either (1) a copy of the Corresponding Source for all the software in the product that is covered by this License, on a durable physical medium customarily used for software interchange, for a price no more than your reasonable cost of physically performing this conveying of source, or (2) access to copy the Corresponding Source from a network server at no charge. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Convey individual copies of the object code with a copy of the written offer to provide the Corresponding Source. This alternative is allowed only occasionally and noncommercially, and only if you received the object code with such an offer, in accord with subsection 6b. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Convey the object code by offering access from a designated place (gratis or for a charge), and offer equivalent access to the Corresponding Source in the same way through the same place at no further charge. You need not require recipients to copy the Corresponding Source along with the object code. If the place to copy the object code is a network server, the Corresponding Source may be on a different server (operated by you or a third party) that supports equivalent copying facilities, provided you maintain clear directions next to the object code saying where to find the Corresponding Source. Regardless of what server hosts the Corresponding Source, you remain obligated to ensure that it is available for as long as needed to satisfy these requirements. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Convey the object code using peer-to-peer transmission, provided you inform other peers where the object code and Corresponding Source of the work are being offered to the general public at no charge under subsection 6d. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A separable portion of the object code, whose source code is excluded from the Corresponding Source as a System Library, need not be included in conveying the object code work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “User Product” is either (1) a “consumer product”, which means any tangible personal property which is normally used for personal, family, or household purposes, or (2) anything designed or sold for incorporation into a dwelling. In determining whether a product is a consumer product, doubtful cases shall be resolved in favor of coverage. For a particular product received by a particular user, “normally used” refers to a typical or common use of that class of product, regardless of the status of the particular user or of the way in which the particular user actually uses, or expects or is expected to use, the product. A product is a consumer product regardless of whether the product has substantial commercial, industrial or non-consumer uses, unless such uses represent the only significant mode of use of the product. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Installation Information” for a User Product means any methods, procedures, authorization keys, or other information required to install and execute modified versions of a covered work in that User Product from a modified version of its Corresponding Source. The information must suffice to ensure that the continued functioning of the modified object code is in no case prevented or interfered with solely because modification has been made. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you convey an object code work under this section in, or with, or specifically for use in, a User Product, and the conveying occurs as part of a transaction in which the right of possession and use of the User Product is transferred to the recipient in perpetuity or for a fixed term (regardless of how the transaction is characterized), the Corresponding Source conveyed under this section must be accompanied by the Installation Information. But this requirement does not apply if neither you nor any third party retains the ability to install modified object code on the User Product (for example, the work has been installed in ROM). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The requirement to provide Installation Information does not include a requirement to continue to provide support service, warranty, or updates for a work that has been modified or installed by the recipient, or for the User Product in which it has been modified or installed. Access to a network may be denied when the modification itself materially and adversely affects the operation of the network or violates the rules and protocols for communication across the network. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Corresponding Source conveyed, and Installation Information provided, in accord with this section must be in a format that is publicly documented (and with an implementation available to the public in source code form), and must require no special password or key for unpacking, reading or copying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section7&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;7&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Additional Terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Additional permissions” are terms that supplement the terms of this License by making exceptions from one or more of its conditions. Additional permissions that are applicable to the entire Program shall be treated as though they were included in this License, to the extent that they are valid under applicable law. If additional permissions apply only to part of the Program, that part may be used separately under those permissions, but the entire Program remains governed by this License without regard to the additional permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When you convey a copy of a covered work, you may at your option remove any additional permissions from that copy, or from any part of it. (Additional permissions may be written to require their own removal in certain cases when you modify the work.) You may place additional permissions on material, added by you to a covered work, for which you have or can give appropriate copyright permission. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, for material you add to a covered work, you may (if authorized by the copyright holders of that material) supplement the terms of this License with terms: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Disclaiming warranty or limiting liability differently from the terms of sections 15 and 16 of this License; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Requiring preservation of specified reasonable legal notices or author attributions in that material or in the Appropriate Legal Notices displayed by works containing it; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Prohibiting misrepresentation of the origin of that material, or requiring that modified versions of such material be marked in reasonable ways as different from the original version; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Limiting the use for publicity purposes of names of licensors or authors of the material; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Declining to grant rights under trademark law for use of some trade names, trademarks, or service marks; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;f) Requiring indemnification of licensors and authors of that material by anyone who conveys the material (or modified versions of it) with contractual assumptions of liability to the recipient, for any liability that these contractual assumptions directly impose on those licensors and authors. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;All other non-permissive additional terms are considered “further restrictions” within the meaning of section 10. If the Program as you received it, or any part of it, contains a notice stating that it is governed by this License along with a term that is a further restriction, you may remove that term. If a license document contains a further restriction but permits relicensing or conveying under this License, you may add to a covered work material governed by the terms of that license document, provided that the further restriction does not survive such relicensing or conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you add terms to a covered work in accord with this section, you must place, in the relevant source files, a statement of the additional terms that apply to those files, or a notice indicating where to find the applicable terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Additional terms, permissive or non-permissive, may be stated in the form of a separately written license, or stated as exceptions; the above requirements apply either way. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section8&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;8&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Termination. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may not propagate or modify a covered work except as expressly provided under this License. Any attempt otherwise to propagate or modify it is void, and will automatically terminate your rights under this License (including any patent licenses granted under the third paragraph of section 11). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, you do not qualify to receive new licenses for the same material under section 10. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section9&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;9&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Acceptance Not Required for Having Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You are not required to accept this License in order to receive or run a copy of the Program. Ancillary propagation of a covered work occurring solely as a consequence of using peer-to-peer transmission to receive a copy likewise does not require acceptance. However, nothing other than this License grants you permission to propagate or modify any covered work. These actions infringe copyright if you do not accept this License. Therefore, by modifying or propagating a covered work, you indicate your acceptance of this License to do so. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section10&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;0. Automatic Licensing of Downstream Recipients. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each time you convey a covered work, the recipient automatically receives a license from the original licensors, to run, modify and propagate that work, subject to this License. You are not responsible for enforcing compliance by third parties with this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;An “entity transaction” is a transaction transferring control of an organization, or substantially all assets of one, or subdividing an organization, or merging organizations. If propagation of a covered work results from an entity transaction, each party to that transaction who receives a copy of the work also receives whatever licenses to the work the party&apos;s predecessor in interest had or could give under the previous paragraph, plus a right to possession of the Corresponding Source of the work from the predecessor in interest, if the predecessor has it or can get it with reasonable efforts. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may not impose any further restrictions on the exercise of the rights granted or affirmed under this License. For example, you may not impose a license fee, royalty, or other charge for exercise of rights granted under this License, and you may not initiate litigation (including a cross-claim or counterclaim in a lawsuit) alleging that any patent claim is infringed by making, using, selling, offering for sale, or importing the Program or any portion of it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section11&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1. Patents. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “contributor” is a copyright holder who authorizes use under this License of the Program or a work on which the Program is based. The work thus licensed is called the contributor&apos;s “contributor version”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A contributor&apos;s “essential patent claims” are all patent claims owned or controlled by the contributor, whether already acquired or hereafter acquired, that would be infringed by some manner, permitted by this License, of making, using, or selling its contributor version, but do not include claims that would be infringed only as a consequence of further modification of the contributor version. For purposes of this definition, “control” includes the right to grant patent sublicenses in a manner consistent with the requirements of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each contributor grants you a non-exclusive, worldwide, royalty-free patent license under the contributor&apos;s essential patent claims, to make, use, sell, offer for sale, import and otherwise run, modify and propagate the contents of its contributor version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;In the following three paragraphs, a “patent license” is any express agreement or commitment, however denominated, not to enforce a patent (such as an express permission to practice a patent or covenant not to sue for patent infringement). To “grant” such a patent license to a party means to make such an agreement or commitment not to enforce a patent against the party. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you convey a covered work, knowingly relying on a patent license, and the Corresponding Source of the work is not available for anyone to copy, free of charge and under the terms of this License, through a publicly available network server or other readily accessible means, then you must either (1) cause the Corresponding Source to be so available, or (2) arrange to deprive yourself of the benefit of the patent license for this particular work, or (3) arrange, in a manner consistent with the requirements of this License, to extend the patent license to downstream recipients. “Knowingly relying” means you have actual knowledge that, but for the patent license, your conveying the covered work in a country, or your recipient&apos;s use of the covered work in a country, would infringe one or more identifiable patents in that country that you have reason to believe are valid. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If, pursuant to or in connection with a single transaction or arrangement, you convey, or propagate by procuring conveyance of, a covered work, and grant a patent license to some of the parties receiving the covered work authorizing them to use, propagate, modify or convey a specific copy of the covered work, then the patent license you grant is automatically extended to all recipients of the covered work and works based on it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A patent license is “discriminatory” if it does not include within the scope of its coverage, prohibits the exercise of, or is conditioned on the non-exercise of one or more of the rights that are specifically granted under this License. You may not convey a covered work if you are a party to an arrangement with a third party that is in the business of distributing software, under which you make payment to the third party based on the extent of your activity of conveying the work, and under which the third party grants, to any of the parties who would receive the covered work from you, a discriminatory patent license (a) in connection with copies of the covered work conveyed by you (or copies made from those copies), or (b) primarily for and in connection with specific products or compilations that contain the covered work, unless you entered into that arrangement, or that patent license was granted, prior to 28 March 2007. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Nothing in this License shall be construed as excluding or limiting any implied license or other defenses to infringement that may otherwise be available to you under applicable patent law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section12&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;2. No Surrender of Others&apos; Freedom. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot convey a covered work so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not convey it at all. For example, if you agree to terms that obligate you to collect a royalty for further conveying from those to whom you convey the Program, the only way you could satisfy both those terms and this License would be to refrain entirely from conveying the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section13&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;3. Use with the GNU Affero General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, you have permission to link or combine any covered work with a work licensed under version 3 of the GNU Affero General Public License into a single combined work, and to convey the resulting work. The terms of this License will continue to apply to the part which is the covered work, but the special requirements of the GNU Affero General Public License, section 13, concerning interaction through a network will apply to the combination as such. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section14&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;4. Revised Versions of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Free Software Foundation may publish revised and/or new versions of the GNU General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each version is given a distinguishing version number. If the Program specifies that a certain numbered version of the GNU General Public License “or any later version” applies to it, you have the option of following the terms and conditions either of that numbered version or of any later version published by the Free Software Foundation. If the Program does not specify a version number of the GNU General Public License, you may choose any version ever published by the Free Software Foundation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the Program specifies that a proxy can decide which future versions of the GNU General Public License can be used, that proxy&apos;s public statement of acceptance of a version permanently authorizes you to choose that version for the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Later license versions may give you additional or different permissions. However, no additional obligations are imposed on any author or copyright holder as a result of your choosing to follow a later version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section15&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;5. Disclaimer of Warranty. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section16&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;6. Limitation of Liability. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section17&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;7. Interpretation of Sections 15 and 16. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the disclaimer of warranty and limitation of liability provided above cannot be given local legal effect according to their terms, reviewing courts shall apply local law that most closely approximates an absolute waiver of all civil liability in connection with the Program, unless a warranty or assumption of liability accompanies a copy of the Program in return for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;END OF TERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;howto&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;ow to Apply These Terms to Your New Programs &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you develop a new program, and you want it to be of the greatest possible use to the public, the best way to achieve this is to make it free software which everyone can redistribute and change under these terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To do so, attach the following notices to the program. It is safest to attach them to the start of each source file to most effectively state the exclusion of warranty; and each file should have at least the “copyright” line and a pointer to where the full notice is found. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;one line to give the program&apos;s name and a brief idea of what it does.&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is free software: you can redistribute it and/or modify&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    it under the terms of the GNU General Public License as published by&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    the Free Software Foundation, either version 3 of the License, or&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is distributed in the hope that it will be useful,&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    GNU General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    You should have received a copy of the GNU General Public License&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    along with this program.  If not, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Also add information on how to contact you by electronic and paper mail. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the program does terminal interaction, make it output a short notice like this when it starts in an interactive mode: &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;program&amp;gt;  Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This is free software, and you are welcome to redistribute it&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    under certain conditions; type `show c&apos; for details. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate parts of the General Public License. Of course, your program&apos;s commands might be different; for a GUI interface, you would use an “about box”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You should also get your employer (if you work as a programmer) or school, if any, to sign a “copyright disclaimer” for the program, if necessary. For more information on this, and how to apply and follow the GNU GPL, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The GNU General Public License does not permit incorporating your program into proprietary programs. If your program is a subroutine library, you may consider it more useful to permit linking proprietary applications with the library. If this is what you want to do, use the GNU Lesser General Public License instead of this License. But first, please read &amp;lt;http://www.gnu.org/philosophy/why-not-lgpl.htm&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The cd/dvd image manipulator for linux&lt;br /&gt;is created by:&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Current: &lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-style:italic;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Previous 2006-2009:&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;&lt;br /&gt;Fabrizio Di Marco&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;AcetoneISO Subversion&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;xx/11/2010&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;Translators:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Italian: Original Authors&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Czech: Hanz&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Russian: Arseniy Muravyev&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Polish: Jarek&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Romanian: Aparaschivei Florin&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Hungarian: Sandor Lisovszki&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;German: Johannes Obermayr&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;Special Thanks goes to:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All the people that made a donation!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All package mantainers.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All people that submitted bug-reports, patches and suggestions.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Irc #qt channel on irc.freenode.net for all their help on C++ and Qt4&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Trolltech for releasing such a wonderful framework, Qt4!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All the open source tools AcetoneISO uses, this includes: fuseiso, mencoder, mplayer, mencoder, dd, cdrdao, wodim, growisofs, youtube-dl, 7z, ffmpeg, gnupg, dvd+r-format and more!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;And finally... a big thanks goes to You for using our software!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Thanks to all of You,&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;The AcetoneISO Team&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>acetoneiso</name>
    <message>
        <source>AcetoneISO2</source>
        <translation type="obsolete">AcetoneISO2</translation>
    </message>
    <message>
        <source>mount</source>
        <translation>Monter</translation>
    </message>
    <message>
        <source>Double click an image to browse</source>
        <translation type="obsolete">Double clic sur une image pour la parcourir</translation>
    </message>
    <message>
        <source>Click a mounted iso on the Display and then unmount</source>
        <translation type="obsolete">Démonter une image après l&apos;avoir sélectionnée et cliquer dessus</translation>
    </message>
    <message>
        <source>unmount</source>
        <translation type="unfinished">Démonter</translation>
    </message>
    <message>
        <source>database</source>
        <translation type="unfinished">Dossier des images</translation>
    </message>
    <message>
        <source>Double click to mount image</source>
        <translation type="obsolete">Double clic pour monter une image</translation>
    </message>
    <message>
        <source>set database</source>
        <translation type="obsolete">Sélectionner un dossier</translation>
    </message>
    <message>
        <source>Click an image on the DB and then &quot;delete image&quot;</source>
        <translation type="obsolete">Cliquer sur une image dans la liste puis sur &quot;Supprimer image&quot;</translation>
    </message>
    <message>
        <source>delete image</source>
        <translation type="obsolete">Supprimer image</translation>
    </message>
    <message>
        <source>Click here to update  your Database</source>
        <translation type="obsolete">Cliquer ici pour mettre à jour la liste</translation>
    </message>
    <message>
        <source>update DB</source>
        <translation type="obsolete">Mise à jour de la liste</translation>
    </message>
    <message>
        <source>play</source>
        <translation type="obsolete">Lire</translation>
    </message>
    <message>
        <source>Play DVD-Movie ISO</source>
        <translation type="obsolete">Lire DVD-Movie ISO</translation>
    </message>
    <message>
        <source>umount DVD-Movie</source>
        <translation type="obsolete">Démonter DVD-Movie</translation>
    </message>
    <message>
        <source>Backup CD-Audio</source>
        <translation>Sauvegarder CD-Audio</translation>
    </message>
    <message>
        <source>Md5-Sum</source>
        <translation type="obsolete">Md5-Sum</translation>
    </message>
    <message>
        <source>El Torito</source>
        <translation type="obsolete">El Torito</translation>
    </message>
    <message>
        <source>help</source>
        <translation type="obsolete">Aide</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Quitter</translation>
    </message>
    <message>
        <source>Set Database</source>
        <translation>Sélectionner le dossier</translation>
    </message>
    <message>
        <source>Image Info</source>
        <translation>Image Info</translation>
    </message>
    <message>
        <source>Extract Boot Image</source>
        <translation>Extraire l&apos;image du boot</translation>
    </message>
    <message>
        <source>Generate to file</source>
        <translation>Générer le fichier</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Vérifier</translation>
    </message>
    <message>
        <source>DOS Boot</source>
        <translation>DOS Boot</translation>
    </message>
    <message>
        <source>Generic Floppy-Emulation</source>
        <translation>Generic Floppy-Emulation</translation>
    </message>
    <message>
        <source>Generic No-Emulation</source>
        <translation>Generic No-Emulation</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation>Manuel</translation>
    </message>
    <message>
        <source>About</source>
        <translation>A propos</translation>
    </message>
    <message>
        <source>umount</source>
        <translation>Démonter</translation>
    </message>
    <message>
        <source>To CD</source>
        <translation>Vers CD</translation>
    </message>
    <message>
        <source>To DvD</source>
        <translation>Vers DVD</translation>
    </message>
    <message>
        <source>Click to mount an ISO MDF NRG BIN IMG image</source>
        <translation type="obsolete">Cliquer pour monter une image ISO MDF NRG BIN IMG</translation>
    </message>
    <message>
        <source>please make a small donation for development!</source>
        <translation type="obsolete">S&apos;il vous plaît, faites un don pour le travail effectué et les développements futurs !</translation>
    </message>
    <message>
        <source>play your DVD image of a film</source>
        <translation type="obsolete">Lire un film sur une image DVD</translation>
    </message>
    <message>
        <source>Convert MacOs Image</source>
        <translation>Convertir MacOs Image</translation>
    </message>
    <message>
        <source>Loading GUI...</source>
        <translation type="obsolete">Chargement GUI...</translation>
    </message>
    <message>
        <source>Loading Options...</source>
        <translation type="obsolete">Chargement Options...</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save BIN Audio file</source>
        <translation type="obsolete">AcetoneISO2::Sauvegarder fichier BIN Audio</translation>
    </message>
    <message>
        <source>Images (*.bin)</source>
        <translation>Images (*.bin)</translation>
    </message>
    <message>
        <source>no cdrdao found in /usr/bin</source>
        <translation>cdrdao non trouvé dans /usr/bin</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to compress</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner l&apos;image à compresser</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</source>
        <translation>Fichiers images (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Compressed Image</source>
        <translation type="obsolete">AcetoneISO2::Enregistrer image compressée</translation>
    </message>
    <message>
        <source>Images (*.7z)</source>
        <translation>Images (*.7z)</translation>
    </message>
    <message>
        <source>Do You want to compress in Ultra High mode? (very slow)</source>
        <translation>Voulez-vous compresser en mode Ultra High (très lent)</translation>
    </message>
    <message>
        <source>no 7z found in /usr/bin</source>
        <translation>Programme 7z non trouvé dans /usr/bin</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Ouvrir une image</translation>
    </message>
    <message>
        <source>Image Files (*.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</source>
        <translation type="obsolete">Fichiers images (*.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save ISO file</source>
        <translation type="obsolete">AcetoneISO2::Enregistrer fichier ISO</translation>
    </message>
    <message>
        <source>Images (*.iso)</source>
        <translation>Images (*.iso)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Database Folder</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner dossier Database</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to decrypt</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner l&apos;image à décrypter</translation>
    </message>
    <message>
        <source>Encrypted Image ( *.gpg)</source>
        <translation>Encrypter l&apos;image ( *.gpg)</translation>
    </message>
    <message>
        <source>Please be sure to have mkisofs installed in /usr/bin </source>
        <translation type="obsolete">Vérifier que mkisofs est installé dans /usr/bin </translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder to transform in a bootable ISO</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner le dossier à transformer en ISO bootable</translation>
    </message>
    <message>
        <source>Select Boot File</source>
        <translation type="obsolete">Sélectionner le fichier Boot</translation>
    </message>
    <message>
        <source>Select Boot File Type:</source>
        <translation type="obsolete">Sélectionner le type de fichier Boot :</translation>
    </message>
    <message>
        <source>GRUB</source>
        <translation type="obsolete">GRUB</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to encrypt</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner l&apos;image à encrypter</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select where to extract image</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner l&apos;endroit où extraire le fichier</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder to be Converted</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner le dossier à convertir</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save ISO</source>
        <translation type="obsolete">AcetoneISO2::Enregistrer ISO</translation>
    </message>
    <message>
        <source>ISO ID</source>
        <translation>ISO ID</translation>
    </message>
    <message>
        <source>Please insert an ID for the ISO</source>
        <translation>Veuillez insérer un ID pour l&apos;ISO</translation>
    </message>
    <message>
        <source>no mkisofs found in /usr/bin</source>
        <translation type="obsolete">Programme mkisofs non trouvé dans /usr/bin</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select *bin or *img</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner *bin ou *img</translation>
    </message>
    <message>
        <source>Image Files (*.bin *.img)</source>
        <translation>Fichiers images (*.bin *.img)</translation>
    </message>
    <message>
        <source>Select from where to extract Boot Image:</source>
        <translation>Sélectionner l&apos;endroit où l&apos;image Boot sera extraite :</translation>
    </message>
    <message>
        <source>ISO File</source>
        <translation>ISO File</translation>
    </message>
    <message>
        <source>CD/DVD</source>
        <translation>CD/DVD</translation>
    </message>
    <message>
        <source>Image Files (*.iso)</source>
        <translation>Fichiers images (*.iso)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save boot image</source>
        <translation>AcetoneISO2::Sauvegarder boot image</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.nrg *.bin *.img *.mdf)</source>
        <translation type="obsolete">Fichiers images (*.iso *.nrg *.bin *.img *.mdf)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select where to mount image</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner le dossier où monter l&apos;image</translation>
    </message>
    <message>
        <source>The folder </source>
        <translation>Le dossier </translation>
    </message>
    <message>
        <source> can&apos;t be mounted</source>
        <translation>ne peut être monté</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select folder to unmount</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner le dossier à démonter</translation>
    </message>
    <message>
        <source> is not mounted!</source>
        <translation> n&apos;est pas monté(e) !</translation>
    </message>
    <message>
        <source>Please note that this tool only works for normal DATA CD/DVD.
 It won&apos;t work with Audio CD and Game CopyProtected cd&apos;s</source>
        <translation type="obsolete">Veuillez noter que cet outil ne fonctionne qu&apos;avec des CD/DVD de données. Il ne permet pas l&apos;utilisation de CD Audio et de CD de jeux protégés contre la copie.</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner une image</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Md5 text file</source>
        <translation type="obsolete">AcetoneISO2::Enregistrer fichier Md5 text</translation>
    </message>
    <message>
        <source>Md5 (*.md5)</source>
        <translation>Md5 (*.md5)</translation>
    </message>
    <message>
        <source>All Virtual Drives are busy,
Unmount some Virtual Drive first!</source>
        <translation>Tous les lecteurs virtuels sont occupés,
Démontez un lecteur virtuel au préalable !</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Parts</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner les portions de l&apos;image</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save merged image</source>
        <translation type="obsolete">AcetoneISO2::Enregistrer image fusionnée</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation>Traitement terminé !</translation>
    </message>
    <message>
        <source>Operation succesfully finished!</source>
        <translation type="unfinished">Traitement terminé !</translation>
    </message>
    <message>
        <source>Operation succesfully finished!
To mount the converted file, open a terminal and run as root:
modprobe hfsplus
mount -t hfsplus -o loop &lt;converted-image.img&gt; /folder_you_want</source>
        <translation>Traitement terminé ! 
Pour monter le fichier converti, ouvrir un terminal en tant que root :
modprobe hfsplus
mount -t hfsplus -o loop &lt;converted-image.img&gt; /dossier de votre choix</translation>
    </message>
    <message>
        <source>Image succesfully merged</source>
        <translation>Image fusionnée avec succès !</translation>
    </message>
    <message>
        <source>Select DVD-Movie to Play</source>
        <translation>Sélectionner un film DVD à lire</translation>
    </message>
    <message>
        <source>DVD-Movie Image (*.iso *.bin *.img *.mdf *.nrg)</source>
        <translation>DVD-film Image (*.iso *.bin *.img *.mdf *.nrg)</translation>
    </message>
    <message>
        <source> mounted</source>
        <translation type="obsolete"> monté(e)</translation>
    </message>
    <message>
        <source>Do you want to download Poweriso?
If you click yes you accept PowerISO&apos;s Freeware Licence.
Remember: this tool won&apos;t run on 64-bit Operating System. Download IAT software for such systems.</source>
        <translation type="obsolete">Voulez-vous télécharger Poweriso ?
Si vous cliquez yes, vous acceptez la PowerISO&apos;s Freeware Licence.
Remarque : ce programme ne tourne pas sur les systèmes 64-bit. Pour ces derniers, téléchargez le programme IAT.</translation>
    </message>
    <message>
        <source>Without Poweriso some functions will be unavailable!</source>
        <translation type="obsolete">Sans Poweriso certaines fonctions ne sont pas disponibles !</translation>
    </message>
    <message>
        <source>Poweriso downloaded and extracted!</source>
        <translation>Poweriso téléchargé et décompacté !</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save BIN file</source>
        <translation type="obsolete">AcetoneISO2::Sauvegarder le fichier BIN</translation>
    </message>
    <message>
        <source>select an image to delete</source>
        <translation>Sélectionner l&apos;image à supprimer</translation>
    </message>
    <message>
        <source>Open Image to be splitted</source>
        <translation>Ouvrir l&apos;image à fractionner</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder where the image will be splitted</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner le dossier où l&apos;image sera fractionnée</translation>
    </message>
    <message>
        <source>AcetoneISO2::Split number</source>
        <translation type="obsolete">AcetoneISO2:nombre de fractions</translation>
    </message>
    <message>
        <source>Please insert the split number in MegaByte:</source>
        <translation type="obsolete">Veuillez insérer le nombre de fractions en MegaByte :</translation>
    </message>
    <message>
        <source>no split file found in /usr/bin</source>
        <translation type="obsolete">Programme split non trouvé dans /usr/bin</translation>
    </message>
    <message>
        <source>DVD-Movie </source>
        <translation type="obsolete">DVD-Movie </translation>
    </message>
    <message>
        <source>select an image to unmount from the virtual-drives display</source>
        <translation>Sélectionner une image à démonter dans la fenêtre des disques virtuels</translation>
    </message>
    <message>
        <source>Open Compressed Image</source>
        <translation>Ouvrir l&apos;image compressée</translation>
    </message>
    <message>
        <source>Image Files (*.7z)</source>
        <translation>Fichiers images (*.7z)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder where the uncompressed Image will be saved</source>
        <translation type="obsolete">AcetoneISO2::Sélectionner le dossier ou l&apos;image décompressée sera sauvegardée</translation>
    </message>
    <message>
        <source>no 7z found in /usr/bin, please install p7zip-full package</source>
        <translation>Programme 7z non trouvé dans /usr/bin. Veuillez installer le package p7zip</translation>
    </message>
    <message>
        <source>Please note this utility will generate a BIN image which could not be mounted or read in any way . 
However You can burn it later with AcetoneISO2 using Burn TOC utility(to be implemented in a future release) .</source>
        <translation type="obsolete">Veuillez noter que cet utilitaire générera une image BIN qui ne pourra pas être montée ou lue.
Néanmoins, vous pourrez la graver plus tard avec AcetoneISO2 en utilisant l&apos;utilitaire Burn TOC (implémenté dans une future version).</translation>
    </message>
    <message>
        <source>to donate go here: http://www.acetoneiso.netsons.org/viewpage.php?page_id=10</source>
        <translation type="obsolete">Pour faire un don : http://www.acetoneiso.netsons.org/viewpage.php?page_id=10</translation>
    </message>
    <message>
        <source>for the manual go here: http://www.acetoneiso.netsons.org/viewpage.php?page_id=4</source>
        <translation type="obsolete">Pour voir le manuel aller ici : http://www.acetoneiso.netsons.org/viewpage.php?page_id=4</translation>
    </message>
    <message>
        <source>Error, could not mount image.

Solution:
a) did you activate fuse? go here and read part c  http://www.acetoneiso.netsons.org/viewpage.php?page_id=4
b) maybe the image is a multisector image. Try converting it under Convert tab of the main gui.</source>
        <translation type="obsolete">Erreur, impossible de monter l&apos;image.

Solutions :
a) Avez-vous activé l&apos;utilitaire \&quot;fuse\&quot;? Regardez le chapitre C du manuel ici : http://www.acetoneiso.netsons.org/viewpage.php?page_id=4
b) Peut-être que le fichier est une image de CD multisession. Essayez de la convertir en utilisant le menu Conversion dans la fenêtre principale.</translation>
    </message>
    <message>
        <source>Manual Umount</source>
        <translation>Démontage manuel</translation>
    </message>
    <message>
        <source>Click to save the dvd cover</source>
        <translation type="obsolete">Cliquer pour enregistrer la jaquette du DVD.</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="obsolete">Fichier</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation type="obsolete">Utilitaires</translation>
    </message>
    <message>
        <source>Split Image</source>
        <translation type="obsolete">Découper l&apos;Image</translation>
    </message>
    <message>
        <source>Encrypt Image</source>
        <translation>Encrypter l&apos;image</translation>
    </message>
    <message>
        <source>Mount in a specified folder</source>
        <translation>Monter dans le dossier spécifié</translation>
    </message>
    <message>
        <source>Compress Image</source>
        <translation>Compresser l&apos;Image</translation>
    </message>
    <message>
        <source>Conversion</source>
        <translation type="obsolete">Conversion</translation>
    </message>
    <message>
        <source>MS-DOS Boot</source>
        <translation>MS-DOS Boot</translation>
    </message>
    <message>
        <source>Convert Image to ISO</source>
        <translation>Convertir l&apos;image au format ISO</translation>
    </message>
    <message>
        <source>Generate ISO from CD/DVD</source>
        <translation type="obsolete">Générer ISO à partir d&apos;un CD/DVD</translation>
    </message>
    <message>
        <source>Generate ISO from folder</source>
        <translation>Générer ISO à partir d&apos;un dossier</translation>
    </message>
    <message>
        <source>Rip a PSX1 game for epsxe/psx emulators</source>
        <translation>Ripper un jeux PSX1 pour l&apos;émulateur epsxe/psx</translation>
    </message>
    <message>
        <source>Split</source>
        <translation>Découper</translation>
    </message>
    <message>
        <source>Merge Splitted Image</source>
        <translation>Fusionner une image découpée</translation>
    </message>
    <message>
        <source>Encrypt</source>
        <translation>Crypter</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation>Décrypter</translation>
    </message>
    <message>
        <source>Mount</source>
        <translation>Monter</translation>
    </message>
    <message>
        <source>Unmount</source>
        <translation>Démonter</translation>
    </message>
    <message>
        <source>Extract Image Content to a folder</source>
        <translation>Extraire le contenu d&apos;une image vers un dossier</translation>
    </message>
    <message>
        <source>Compress</source>
        <translation>Compresser</translation>
    </message>
    <message>
        <source>Uncompress</source>
        <translation>Décompresser</translation>
    </message>
    <message>
        <source>Generate Cue for BIN/IMG images</source>
        <translation>Générer un fichier CUE à partie d&apos;une image BIN/IMG</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Options</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg)</source>
        <translation>Fichiers images (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg)</translation>
    </message>
    <message>
        <source>Image Files (*.dmg)</source>
        <translation>Fichiers images (*.dmg)</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save DVD Cover</source>
        <translation type="obsolete">AcetoneISO2::Enregistrer DVD Cover</translation>
    </message>
    <message>
        <source>Images (*.jpg)</source>
        <translation type="obsolete">Images (*.jpg)</translation>
    </message>
    <message>
        <source>Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please Unmount the movie first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a method to play the movie.
Method 1 generally works, if it doesn&apos;t try Method 2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mount UDF ISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert FLV 2 AVI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please be sure the DVD disc is inserted in device and then press OK.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encoding Pass 1 has succesfully finished.
Pass 2 will be done now. Please choose the bitrate in the next dialog and then choose where to save the video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert Bitrate. Higher bitrate means more quality but will generate a bigger file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video (*.avi)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the Fixed Quant number.
Lowering the number will result in a higher quality video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert generic video 2 Xvid AVI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rip DVD 2 Xvid AVI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select FLV Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video Files (*.flv )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error has occured.
Please try converting the FLV video with Convert generic video to Xvid AVI feature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>YouTube Download Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert YouTube&apos;s URL:
Note: YouTube&apos;s server is often very slow, big files can require a lot of time to download!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video (*.flv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generate ISO from CD/DVD and it is:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play DVD image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O&amp;ptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Donate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Anonymous Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User Account Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burn CUE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burn TOC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a normal CD/DVD data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a CD Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a protected PC Game CD/DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a standard data CD/DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a CD Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a Playstation 1 Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a protected PC Game CD/DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a DVD Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a DVD Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a Playstation 1 Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Did you insert correct CD/DVD device?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Without Poweriso you won&apos;t be able to convert and extract images to ISO or folders!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Please see the log file in   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are about to delete </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Are You sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No way!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no genisoimage found in /usr/bin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The image </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> can&apos;t be mounted. You must convert it to ISO or extract content to a folder.
Please choose what to do:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Convert to ISO </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Extract image to a folder </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the Byte Size.
Leaving default is the best solution!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert your YouTube&apos;s username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>your username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert your YouTube&apos;s password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a format type:
Fast method is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the erasing speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to unmount the CD/DVD device.
Be sure there is no process that is locking the device.
Please click on Cancel button in the next dialog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This utility will not do a 1:1 copy of your game! It will simply skip copyprotection errors.
You will need a no-cd fix cd/dvd to make the game work also known as crack.
Note: if the game is very old and uses a mixed data/audio file system, this utility won&apos;t work. Sorry :(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please specify your CD/DVD mount point. If you aren&apos;t sure just leave default.
Typical mount points are:
/media/cdrom or /media/cdrom0 or /media/cdrom1 and follow this symbolism.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Real time updates from the net</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>http://www.acetoneteam.org/clients.html</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to mount an image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click a mounted image on the display to unmount it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Image Conversion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Split Image in Volumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>type a letter/s to filter the search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Double click to mount. Right click for context menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>select an image on display to delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to update  database&apos;s display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PornoTube Download Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaCafe Download Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rip CD Audio 2 MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert WMA 2 MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert WAV 2 MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract a RAR password protected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ISO 2 CSO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSO 2 ISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract Audio from a Video file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Insert cd/dvd device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save BIN Audio file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to compress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.gpg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save Compressed Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder where the uncompressed Image will be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open RAR password protected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RAR File (*.rar *.rev *.r00)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Insert password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the password of the RAR archive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder where the uncompressed RAR will be extracted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no unrar-nonfree found in /usr/bin. Please install unrar-nonfree package.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save ISO file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It is highly recommended to use &quot;Extract to folder&quot; feature.
This is because the converted ISO image is not a true ISO-9660 filesystem and requires to be mounted from terminal. A loaded hfsplus module is also needed.
Extracting the image contents to a folder is way easier and faster, and if you need you can always convert the folder to ISO in a second moment with AcetoneISO!
Choose what to do:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Extract to folder (best solution) </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Convert to ISO (worst solution) </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to extract image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to download Poweriso?
If you click yes you accept PowerISO&apos;s Freeware(proprietary but gratis) License.
Remember: if you are running a 64-bit OS, you need ia32-libs package installed and maybe others.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to donate go here: http://www.acetoneteam.org/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to decrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder to be Converted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save ISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This tool doesn&apos;t do anything special.
It will only create a file with the following lines referred to the BIN/IMG you select:
FILE  + $image_file + BINARY
TRACK 01 MODE1/2352
INDEX 01 00:00:00
note: it doesn&apos;t make sense to use this feature with multisector images.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select *bin or *img</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NOTE: If you want to mount an image in a root folder like /media/cdrom, please launch AcetoneISO as root user. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to mount image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select folder to unmount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Inser cd/dvd device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Byte Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save Md5 text file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Operation succesfully finished!
Find the file in </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred while unmounting.
The image has been unmounted but it is highly recommended to close and reopen AcetoneISO to mount a new image.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error, could not mount image.

Solution:
Try converting the image to ISO or extract the content to a folder from the upper menu &quot;Image Conversion.&quot;
NOTE: it is NOT possible to mount multi-sector images.
For more information, please visit official website: http://www.acetoneteam.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save BIN file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg *.gpg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Insert volume name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Split number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the volume number in MegaByte:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select first volume part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7Z 001 (*.001)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to be done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save Video file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Fixed Quant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::MetaCafe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert MetaCafe&apos;s URL:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We highly recommend to NOT erase a DVD.
AcetoneISO can simply overwrite existing data so there is no need to erase it.
Also remember that erasing a lot of times a dvd will damage the media.
Do You want to continue anyways?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Erase Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select WMA Audio File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio WMA (*.wma)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio MP3 (*.mp3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to Save ripped CD-Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Video File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save WAV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio WAV (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Wav File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WAV (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Insert cd/dvd mount point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>extract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please specify your CD/DVD device. If you aren&apos;t sure just leave default.
Typical devices are:
/dev/cdrom or /dev/cdrom0 or /dev/cdrom1 or /dev/dvd and follow this symbolism.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note:
ISO-9660 filesystem does not support multisector images, this means you will loose all sectors above first sector. Generally speaking, the first sector holds data file.
If it&apos;s a video game image in MDF/IMG/CCD format, you will probably loose sectors that hold copyprotection files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Archive Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mount Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reached maximum allowed drives to mount.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unmount Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm *.mp4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video (*.mp4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Convert video for PSP™</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You decided to unmount:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rip CD-Audio to WAV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the first time you launch AcetoneISO software.
In the next dialog you can set your default file manager, set database and some other things.
Happy AcetoneISO usage from the team:)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO I love You!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> doesn&apos;t exist.
I&apos;ll remove it from database display.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The History display is already empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are about to clear the History display.
This won&apos;t delete the images from hard disk.
Clear History?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All images that don&apos;t exist have been removed from History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove non-existant images from History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear History Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About AcetoneISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mount Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do the action specified in the combobox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database set to:  (flag recursive:ON)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database set to:  (flag recursive:OFF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database set to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All images in History fisically exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> doesn&apos;t exist.
I&apos;ll remove it from history display.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
This will remove it from history and fisically delete it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(250, 248, 255);
selection-background-color: rgb(248, 146, 255);
selection-color: rgb(82, 1, 93);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(244, 251, 255);
selection-background-color: rgb(121, 123, 255);
selection-color: rgb(1, 10, 134);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(244, 251, 255);
selection-color: rgb(197, 24, 212);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(246, 255, 248);
selection-color: rgb(19, 89, 0);
selection-background-color: rgb(147, 255, 151);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>open image in file manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mount </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>delete </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>extract </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>open </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in file manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unmount </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Double click an image to open in file manager.
Right click for Context Menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in /usr/bin.
Please install it and be sure it&apos;s linked to /usr/bin folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process Progress:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hides the Process Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide Process display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This display shows you the current progress of the process in action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make a small donation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.cue)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg *.cue)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(255, 255, 238);
selection-background-color: rgb(85, 0, 255);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose if you want the audio to be in mp3 format or if
it should be the same of the dvd (for example dolby 5.1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burn CD/DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to find wodim in /usr/bin.
Please install wodim package.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Erase CD-RW</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to find dvd+rw-format in /usr/bin.
Please install dvd+rw-tools package.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video (*.avi *.mpg *.mpeg *.wmv *.flv *.mov *.asf *.rm *.mp4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calculate Md5-Sum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calculate Sha-Sum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sha1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sha256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.bin *.mdf *.nrg *.img)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sha384</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Erase CD-RW or DVD±RW :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select where to Save the Youtube Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Burn ISO image to DVD±R/RW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to find growisofs in /usr/bin.
Please install growisofs package.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Image appears to have an UDF filesystem.
To correctly mount this image, open a terminal as root user and type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to download youtube-dl.
Please try again and be sure your internet connection is alive.
If the problem persists please contact us at acetoneiso@gmail.com .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Burn Image ISO/CUE/TOC to CD-R/RW or DVD±R/RW :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please note this utility will generate a TOC/BIN image which could not be mounted or read in any way.
However You can burn it later with AcetoneISO burning tools!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burn ISO/TOC/CUE to CD-R/RW</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>burniso2cd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Traitement terminé !</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-R/RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a CD-R/RW disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-R/RW. Please insert a CD-R/RW disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You inserted a CD-RW disc, however your CD/DVD device is uncapable of writing to CD-RW discs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CD-R isn&apos;t empty. Please insert an empty CD-R/RW disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CD-RW isn&apos;t empty.
Please insert an empty CD-R/RW disc or blank the CD-RW with the appropriate AcetoneISO&apos;s blanking tool.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose writing speed. When putting high values, be sure to have a good optical medium quality.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to browse and choose what image to burn to your optical medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start burning your image.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Does a burning simulation. This means it will not do a real burn and write data on your CD-R/RW disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Image to Burn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estimated time to burn </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select ISO/CUE/TOC image to burn to CD-R/RW :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This display shows the progress of the burning process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO is burning your image to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You decided to burn the image on the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burn Image to CD-R/RW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Image you selected is too big to fit into a CD-R/RW.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files ISO/CUE/TOC (*.iso *.cue *.toc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Image you selected is unsupported from AcetoneISO.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Image you selected does not exist.
If trying to burn a CUE/TOC image, be sure the image file is in the exact folder where the CUE/TOC file is.
Be also sure they have same name except the CUE/TOC file ending with .toc extension.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program cue2toc not found in /usr/bin
Please install cue2toc package.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to generate toc file from the cue file you selected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>burniso2dvd</name>
    <message>
        <source>Progress:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to DVD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The disc isn&apos;t a DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert a DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You inserted a </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Traitement terminé !</translation>
    </message>
    <message>
        <source> that is not Empty. Please put an empty DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose writing speed. When putting high values, be sure to have a good optical medium quality.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to browse and choose what image to burn to your optical medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start burning your image.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the dvd DVD±R/RW capable devices found in your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Select ISO image to burn to DVD±R/RW :</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Burn ISO to DVD±R/RW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> disc, however your CD/DVD device is uncapable of writing to such discs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Image you selected does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estimated time to burn </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> that is not Empty. If you continue, AcetoneISO will overwrite your disc!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You decided to burn the image on the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.
The disc is NOT empty so if you continue,
AcetoneISO will overwrite all your data.
Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO is burning your image to the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select ISO Image to Burn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ISO Image Files (*.iso)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Image you selected is unsupported from AcetoneISO.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>erasecd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CD-RW is getting blanked...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a CD-RW disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-RW. Please insert a CD-RW disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CD-RW succesfully found in device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You decided to blank the CD-RW.
Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Traitement terminé !</translation>
    </message>
    <message>
        <source>Erase CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selecting this will completely blank your CD-RW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blank  the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This will not delete files but only PMA, TOC and the pregap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimally blank the entire disk (PMA, TOC, pregap)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>erasedvd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Traitement terminé !</translation>
    </message>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to DVD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert a DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The disc isn&apos;t a DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert a DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You inserted a DVD+RW disc, however your CD/DVD device is uncapable of writing to DVD+RW discs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the DVD±RW capable devices found in your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>is getting blanked...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You decided to blank the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Selecting this will completely blank your DVD±RW. This is not recommended and may damage your media on if used several times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blank  the entire disk (not recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick Blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>is already formatted.
There is no need to format it because you can simply overwrite the media.
If you really want to blank it, choose Blank the Entire disc in the below window but we highly discourage you from doing so.
Overwriting the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>is the simplest and safest thing to do.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>manual</name>
    <message>
        <source>AcetoneISO2::Manual</source>
        <translation type="obsolete">AcetoneISO2::Manuel</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Sortir</translation>
    </message>
    <message>
        <source>AcetoneISO::Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>options</name>
    <message>
        <source>AcetoneISO2::Options</source>
        <translation type="obsolete">AcetoneISO2::Options</translation>
    </message>
    <message>
        <source>Iso from folder</source>
        <translation>ISO à partir d&apos;un dossier</translation>
    </message>
    <message>
        <source>Standard Settings</source>
        <translation>Paramètres standards</translation>
    </message>
    <message>
        <source>will let you add an ID to the ISO</source>
        <translation>vous permettra d&apos;ajouter un ID au fichier ISO</translation>
    </message>
    <message>
        <source>User Settings</source>
        <translation>Paramètres utilisateur</translation>
    </message>
    <message>
        <source>Media player</source>
        <translation>Lecteur de média</translation>
    </message>
    <message>
        <source>Kaffeine</source>
        <translation>Kaffeine</translation>
    </message>
    <message>
        <source>Vlc</source>
        <translation>Vlc</translation>
    </message>
    <message>
        <source>SMPlayer</source>
        <translation>SMPlayer</translation>
    </message>
    <message>
        <source>File manager</source>
        <translation>Gestionnaire de fichier</translation>
    </message>
    <message>
        <source>it will use kde&apos;s default file manager</source>
        <translation>Utilisera de gestionnaire de fichier par défaut de KDE</translation>
    </message>
    <message>
        <source>Kde</source>
        <translation>KDE</translation>
    </message>
    <message>
        <source>it will use Nautilus file manager</source>
        <translation>Utilisera le gestionnaire de fichier Nautilus</translation>
    </message>
    <message>
        <source>Nautilus</source>
        <translation>Nautilus</translation>
    </message>
    <message>
        <source>ok</source>
        <translation type="obsolete">ok</translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset options to default values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thunar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t Open a file manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What is Database?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set database root folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scan Subdirectories (read below)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Tray Icon (requires application restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close in Tray Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically clean History display on restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tray Icon:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically remove non-existant images from History display on restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lxde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;If you activate Scan Subdirectories checkbox, avoid setting database root folder directly to your ~home folder or system folders.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>optionsDiag</name>
    <message>
        <source>AcetoneISO::Select Database Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database is a quick and easy feature for managing your images.
Place them all in a folder and set the Database path to it, you will see all the images in the database display.
You can quickly mount them by simply clicking on them or right click for more options.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>progress</name>
    <message>
        <source>AcetoneISO2::Progress</source>
        <translation type="obsolete">AcetoneISO2::Progression</translation>
    </message>
    <message>
        <source>Please wait... work in progress</source>
        <translation>Patientez, travail en cours...</translation>
    </message>
    <message>
        <source>AcetoneISO::Progress</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
