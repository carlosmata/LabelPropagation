<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it">
<context>
    <name>about</name>
    <message>
        <source>Authors</source>
        <translation type="unfinished">Autori</translation>
    </message>
    <message>
        <source>&lt;html&gt;
&lt;head&gt;
  &lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;
 http-equiv=&quot;content-type&quot;&gt;
  &lt;title&gt;&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;span style=&quot;font-weight: bold;&quot;&gt;AcetoneISO2&lt;/span&gt; &lt;br&gt;
The cd/dvd image manipulator for linux&lt;br&gt;
is created by:&lt;br&gt;
&lt;br style=&quot;font-style: italic;&quot;&gt;
&lt;span style=&quot;font-style: italic;&quot;&gt;Fabrizio Di Marco&lt;/span&gt;
&amp;amp; &lt;span style=&quot;font-style: italic;&quot;&gt;Marco Di
Antonio&lt;/span&gt;
&lt;/body&gt;
&lt;/html&gt;
</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;   &lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;  http-equiv=&quot;content-type&quot;&gt;   &lt;title&gt;&lt;/title&gt;&lt;/head&gt;&lt;body&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;AcetoneISO2&lt;/span&gt; &lt;br&gt;Il manipolatore delle immagini CD/DVD per Linux&lt;br&gt;è sviluppato da:&lt;br&gt;&lt;br style=&quot;font-style: italic;&quot;&gt;&lt;span style=&quot;font-style: italic;&quot;&gt;Fabrizio Di Marco&lt;/span&gt;&amp;amp; &lt;span style=&quot;font-style: italic;&quot;&gt;Marco DiAntonio&lt;/span&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation type="unfinished">Contatti</translation>
    </message>
    <message>
        <source>&lt;html&gt;
&lt;head&gt;
  &lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;
 http-equiv=&quot;content-type&quot;&gt;
  &lt;title&gt;&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
You have many ways to contact us:&lt;big&gt;&lt;br&gt;
&lt;br&gt;
&lt;/big&gt;email: &lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;acetoneiso@gmail.com&lt;/a&gt;&lt;br&gt;
website: &lt;a href=&quot;http://acetoneiso.netsons.org&quot;&gt;http://acetoneiso.netsons.org&lt;/a&gt;&lt;br&gt;
irc: #acetoneiso server azzurra
&lt;/body&gt;
&lt;/html&gt;
</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;   &lt;meta content=&quot;text/html; charset=ISO-8859-1&quot;  http-equiv=&quot;content-type&quot;&gt;   &lt;title&gt;&lt;/title&gt;&lt;/head&gt;&lt;body&gt;Ci sono diversi modi per contattarci:&lt;big&gt;&lt;br&gt;&lt;br&gt;&lt;/big&gt;email: &lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;acetoneiso@gmail.com&lt;/a&gt;&lt;br&gt;sito web: &lt;a href=&quot;http://acetoneiso.netsons.org&quot;&gt;http://acetoneiso.netsons.org&lt;/a&gt;&lt;br&gt;irc: #acetoneiso server azzurra&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>License</source>
        <translation type="unfinished">Licenza</translation>
    </message>
    <message>
        <source>About AcetoneISO</source>
        <translation type="unfinished">Informazioni su AcetoneISO</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans&apos;; font-size:10pt;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;You can contact us by email at:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;acetoneiso@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans&apos;; font-size:10pt;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Official Website:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.acetoneteam.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.acetoneteam.org/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans&apos;; font-size:10pt;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Puoi contattarci via email a::&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;acetoneiso@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans&apos;; font-size:10pt;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Sito Ufficiale:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.acetoneteam.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.acetoneteam.org/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;GNU GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Version 3, 29 June 2007 &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Copyright © 2007 Free Software Foundation, Inc. &amp;lt;http://fsf.org/&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;preamble&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;reamble &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The GNU General Public License is a free, copyleft license for software and other kinds of works. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program--to make sure it remains free software for all its users. We, the Free Software Foundation, use the GNU General Public License for most of our software; it applies also to any other work released this way by its authors. You can apply it to your programs, too. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Developers that use the GNU GPL protect your rights with two steps: (1) assert copyright on the software, and (2) offer you this License giving you legal permission to copy, distribute and/or modify it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;For the developers&apos; and authors&apos; protection, the GPL clearly explains that there is no warranty for this free software. For both users&apos; and authors&apos; sake, the GPL requires that modified versions be marked as changed, so that their problems will not be attributed erroneously to authors of previous versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Some devices are designed to deny users access to install or run modified versions of the software inside them, although the manufacturer can do so. This is fundamentally incompatible with the aim of protecting users&apos; freedom to change the software. The systematic pattern of such abuse occurs in the area of products for individuals to use, which is precisely where it is most unacceptable. Therefore, we have designed this version of the GPL to prohibit the practice for those products. If such problems arise substantially in other domains, we stand ready to extend this provision to those domains in future versions of the GPL, as needed to protect the freedom of users. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Finally, every program is threatened constantly by software patents. States should not allow patents to restrict development and use of software on general-purpose computers, but in those that do, we wish to avoid the special danger that patents applied to a free program could make it effectively proprietary. To prevent this, the GPL assures that patents cannot be used to render the program non-free. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;terms&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;ERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section0&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;0&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Definitions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;“This License” refers to version 3 of the GNU General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;“Copyright” also means copyright-like laws that apply to other kinds of works, such as semiconductor masks. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;“The Program” refers to any copyrightable work licensed under this License. Each licensee is addressed as “you”. “Licensees” and “recipients” may be individuals or organizations. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;To “modify” a work means to copy from or adapt all or part of the work in a fashion requiring copyright permission, other than the making of an exact copy. The resulting work is called a “modified version” of the earlier work or a work “based on” the earlier work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A “covered work” means either the unmodified Program or a work based on the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;To “propagate” a work means to do anything with it that, without permission, would make you directly or secondarily liable for infringement under applicable copyright law, except executing it on a computer or modifying a private copy. Propagation includes copying, distribution (with or without modification), making available to the public, and in some countries other activities as well. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;To “convey” a work means any kind of propagation that enables other parties to make or receive copies. Mere interaction with a user through a computer network, with no transfer of a copy, is not conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;An interactive user interface displays “Appropriate Legal Notices” to the extent that it includes a convenient and prominently visible feature that (1) displays an appropriate copyright notice, and (2) tells the user that there is no warranty for the work (except to the extent that warranties are provided), that licensees may convey the work under this License, and how to view a copy of this License. If the interface presents a list of user commands or options, such as a menu, a prominent item in the list meets this criterion. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Source Code. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The “source code” for a work means the preferred form of the work for making modifications to it. “Object code” means any non-source form of a work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A “Standard Interface” means an interface that either is an official standard defined by a recognized standards body, or, in the case of interfaces specified for a particular programming language, one that is widely used among developers working in that language. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The “System Libraries” of an executable work include anything, other than the work as a whole, that (a) is included in the normal form of packaging a Major Component, but which is not part of that Major Component, and (b) serves only to enable use of the work with that Major Component, or to implement a Standard Interface for which an implementation is available to the public in source code form. A “Major Component”, in this context, means a major essential component (kernel, window system, and so on) of the specific operating system (if any) on which the executable work runs, or a compiler used to produce the work, or an object code interpreter used to run it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The “Corresponding Source” for a work in object code form means all the source code needed to generate, install, and (for an executable work) run the object code and to modify the work, including scripts to control those activities. However, it does not include the work&apos;s System Libraries, or general-purpose tools or generally available free programs which are used unmodified in performing those activities but which are not part of the work. For example, Corresponding Source includes interface definition files associated with source files for the work, and the source code for shared libraries and dynamically linked subprograms that the work is specifically designed to require, such as by intimate data communication or control flow between those subprograms and other parts of the work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The Corresponding Source need not include anything that users can regenerate automatically from other parts of the Corresponding Source. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The Corresponding Source for a work in source code form is that same work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;2&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Basic Permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;All rights granted under this License are granted for the term of copyright on the Program, and are irrevocable provided the stated conditions are met. This License explicitly affirms your unlimited permission to run the unmodified Program. The output from running a covered work is covered by this License only if the output, given its content, constitutes a covered work. This License acknowledges your rights of fair use or other equivalent, as provided by copyright law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Conveying under any other circumstances is permitted solely under the conditions stated below. Sublicensing is not allowed; section 10 makes it unnecessary. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Protecting Users&apos; Legal Rights From Anti-Circumvention Law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;No covered work shall be deemed part of an effective technological measure under any applicable law fulfilling obligations under article 11 of the WIPO copyright treaty adopted on 20 December 1996, or similar laws prohibiting or restricting circumvention of such measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;When you convey a covered work, you waive any legal power to forbid circumvention of technological measures to the extent such circumvention is effected by exercising rights under this License with respect to the covered work, and you disclaim any intention to limit operation or modification of the work as a means of enforcing, against the work&apos;s users, your or third parties&apos; legal rights to forbid circumvention of technological measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;4&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Verbatim Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You may convey verbatim copies of the Program&apos;s source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice; keep intact all notices stating that this License and any non-permissive terms added in accord with section 7 apply to the code; keep intact all notices of the absence of any warranty; and give all recipients a copy of this License along with the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You may charge any price or no price for each copy that you convey, and you may offer support or warranty protection for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section5&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;5&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Modified Source Versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You may convey a work based on the Program, or the modifications to produce it from the Program, in the form of source code under the terms of section 4, provided that you also meet all of these conditions: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;-qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) The work must carry prominent notices stating that you modified it, and giving a relevant date. &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) The work must carry prominent notices stating that it is released under this License and any conditions added under section 7. This requirement modifies the requirement in section 4 to “keep intact all notices”. &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) You must license the entire work, as a whole, under this License to anyone who comes into possession of a copy. This License will therefore apply, along with any applicable section 7 additional terms, to the whole of the work, and all its parts, regardless of how they are packaged. This License gives no permission to license the work in any other way, but it does not invalidate such permission if you have separately received it. &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) If the work has interactive user interfaces, each must display Appropriate Legal Notices; however, if the Program has interactive interfaces that do not display Appropriate Legal Notices, your work need not make them do so. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A compilation of a covered work with other separate and independent works, which are not by their nature extensions of the covered work, and which are not combined with it such as to form a larger program, in or on a volume of a storage or distribution medium, is called an “aggregate” if the compilation and its resulting copyright are not used to limit the access or legal rights of the compilation&apos;s users beyond what the individual works permit. Inclusion of a covered work in an aggregate does not cause this License to apply to the other parts of the aggregate. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section6&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;6&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Non-Source Forms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You may convey a covered work in object code form under the terms of sections 4 and 5, provided that you also convey the machine-readable Corresponding Source under the terms of this License, in one of these ways: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;-qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by the Corresponding Source fixed on a durable physical medium customarily used for software interchange. &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by a written offer, valid for at least three years and valid for as long as you offer spare parts or customer support for that product model, to give anyone who possesses the object code either (1) a copy of the Corresponding Source for all the software in the product that is covered by this License, on a durable physical medium customarily used for software interchange, for a price no more than your reasonable cost of physically performing this conveying of source, or (2) access to copy the Corresponding Source from a network server at no charge. &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Convey individual copies of the object code with a copy of the written offer to provide the Corresponding Source. This alternative is allowed only occasionally and noncommercially, and only if you received the object code with such an offer, in accord with subsection 6b. &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Convey the object code by offering access from a designated place (gratis or for a charge), and offer equivalent access to the Corresponding Source in the same way through the same place at no further charge. You need not require recipients to copy the Corresponding Source along with the object code. If the place to copy the object code is a network server, the Corresponding Source may be on a different server (operated by you or a third party) that supports equivalent copying facilities, provided you maintain clear directions next to the object code saying where to find the Corresponding Source. Regardless of what server hosts the Corresponding Source, you remain obligated to ensure that it is available for as long as needed to satisfy these requirements. &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Convey the object code using peer-to-peer transmission, provided you inform other peers where the object code and Corresponding Source of the work are being offered to the general public at no charge under subsection 6d. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A separable portion of the object code, whose source code is excluded from the Corresponding Source as a System Library, need not be included in conveying the object code work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A “User Product” is either (1) a “consumer product”, which means any tangible personal property which is normally used for personal, family, or household purposes, or (2) anything designed or sold for incorporation into a dwelling. In determining whether a product is a consumer product, doubtful cases shall be resolved in favor of coverage. For a particular product received by a particular user, “normally used” refers to a typical or common use of that class of product, regardless of the status of the particular user or of the way in which the particular user actually uses, or expects or is expected to use, the product. A product is a consumer product regardless of whether the product has substantial commercial, industrial or non-consumer uses, unless such uses represent the only significant mode of use of the product. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;“Installation Information” for a User Product means any methods, procedures, authorization keys, or other information required to install and execute modified versions of a covered work in that User Product from a modified version of its Corresponding Source. The information must suffice to ensure that the continued functioning of the modified object code is in no case prevented or interfered with solely because modification has been made. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If you convey an object code work under this section in, or with, or specifically for use in, a User Product, and the conveying occurs as part of a transaction in which the right of possession and use of the User Product is transferred to the recipient in perpetuity or for a fixed term (regardless of how the transaction is characterized), the Corresponding Source conveyed under this section must be accompanied by the Installation Information. But this requirement does not apply if neither you nor any third party retains the ability to install modified object code on the User Product (for example, the work has been installed in ROM). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The requirement to provide Installation Information does not include a requirement to continue to provide support service, warranty, or updates for a work that has been modified or installed by the recipient, or for the User Product in which it has been modified or installed. Access to a network may be denied when the modification itself materially and adversely affects the operation of the network or violates the rules and protocols for communication across the network. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Corresponding Source conveyed, and Installation Information provided, in accord with this section must be in a format that is publicly documented (and with an implementation available to the public in source code form), and must require no special password or key for unpacking, reading or copying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section7&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;7&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Additional Terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;“Additional permissions” are terms that supplement the terms of this License by making exceptions from one or more of its conditions. Additional permissions that are applicable to the entire Program shall be treated as though they were included in this License, to the extent that they are valid under applicable law. If additional permissions apply only to part of the Program, that part may be used separately under those permissions, but the entire Program remains governed by this License without regard to the additional permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;When you convey a copy of a covered work, you may at your option remove any additional permissions from that copy, or from any part of it. (Additional permissions may be written to require their own removal in certain cases when you modify the work.) You may place additional permissions on material, added by you to a covered work, for which you have or can give appropriate copyright permission. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, for material you add to a covered work, you may (if authorized by the copyright holders of that material) supplement the terms of this License with terms: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;-qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Disclaiming warranty or limiting liability differently from the terms of sections 15 and 16 of this License; or &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Requiring preservation of specified reasonable legal notices or author attributions in that material or in the Appropriate Legal Notices displayed by works containing it; or &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Prohibiting misrepresentation of the origin of that material, or requiring that modified versions of such material be marked in reasonable ways as different from the original version; or &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Limiting the use for publicity purposes of names of licensors or authors of the material; or &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Declining to grant rights under trademark law for use of some trade names, trademarks, or service marks; or &lt;/li&gt;
&lt;li style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;f) Requiring indemnification of licensors and authors of that material by anyone who conveys the material (or modified versions of it) with contractual assumptions of liability to the recipient, for any liability that these contractual assumptions directly impose on those licensors and authors. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;All other non-permissive additional terms are considered “further restrictions” within the meaning of section 10. If the Program as you received it, or any part of it, contains a notice stating that it is governed by this License along with a term that is a further restriction, you may remove that term. If a license document contains a further restriction but permits relicensing or conveying under this License, you may add to a covered work material governed by the terms of that license document, provided that the further restriction does not survive such relicensing or conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If you add terms to a covered work in accord with this section, you must place, in the relevant source files, a statement of the additional terms that apply to those files, or a notice indicating where to find the applicable terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Additional terms, permissive or non-permissive, may be stated in the form of a separately written license, or stated as exceptions; the above requirements apply either way. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section8&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;8&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Termination. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You may not propagate or modify a covered work except as expressly provided under this License. Any attempt otherwise to propagate or modify it is void, and will automatically terminate your rights under this License (including any patent licenses granted under the third paragraph of section 11). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, you do not qualify to receive new licenses for the same material under section 10. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section9&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;9&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;. Acceptance Not Required for Having Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You are not required to accept this License in order to receive or run a copy of the Program. Ancillary propagation of a covered work occurring solely as a consequence of using peer-to-peer transmission to receive a copy likewise does not require acceptance. However, nothing other than this License grants you permission to propagate or modify any covered work. These actions infringe copyright if you do not accept this License. Therefore, by modifying or propagating a covered work, you indicate your acceptance of this License to do so. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section10&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;0. Automatic Licensing of Downstream Recipients. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Each time you convey a covered work, the recipient automatically receives a license from the original licensors, to run, modify and propagate that work, subject to this License. You are not responsible for enforcing compliance by third parties with this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;An “entity transaction” is a transaction transferring control of an organization, or substantially all assets of one, or subdividing an organization, or merging organizations. If propagation of a covered work results from an entity transaction, each party to that transaction who receives a copy of the work also receives whatever licenses to the work the party&apos;s predecessor in interest had or could give under the previous paragraph, plus a right to possession of the Corresponding Source of the work from the predecessor in interest, if the predecessor has it or can get it with reasonable efforts. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You may not impose any further restrictions on the exercise of the rights granted or affirmed under this License. For example, you may not impose a license fee, royalty, or other charge for exercise of rights granted under this License, and you may not initiate litigation (including a cross-claim or counterclaim in a lawsuit) alleging that any patent claim is infringed by making, using, selling, offering for sale, or importing the Program or any portion of it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section11&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1. Patents. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A “contributor” is a copyright holder who authorizes use under this License of the Program or a work on which the Program is based. The work thus licensed is called the contributor&apos;s “contributor version”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A contributor&apos;s “essential patent claims” are all patent claims owned or controlled by the contributor, whether already acquired or hereafter acquired, that would be infringed by some manner, permitted by this License, of making, using, or selling its contributor version, but do not include claims that would be infringed only as a consequence of further modification of the contributor version. For purposes of this definition, “control” includes the right to grant patent sublicenses in a manner consistent with the requirements of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Each contributor grants you a non-exclusive, worldwide, royalty-free patent license under the contributor&apos;s essential patent claims, to make, use, sell, offer for sale, import and otherwise run, modify and propagate the contents of its contributor version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;In the following three paragraphs, a “patent license” is any express agreement or commitment, however denominated, not to enforce a patent (such as an express permission to practice a patent or covenant not to sue for patent infringement). To “grant” such a patent license to a party means to make such an agreement or commitment not to enforce a patent against the party. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If you convey a covered work, knowingly relying on a patent license, and the Corresponding Source of the work is not available for anyone to copy, free of charge and under the terms of this License, through a publicly available network server or other readily accessible means, then you must either (1) cause the Corresponding Source to be so available, or (2) arrange to deprive yourself of the benefit of the patent license for this particular work, or (3) arrange, in a manner consistent with the requirements of this License, to extend the patent license to downstream recipients. “Knowingly relying” means you have actual knowledge that, but for the patent license, your conveying the covered work in a country, or your recipient&apos;s use of the covered work in a country, would infringe one or more identifiable patents in that country that you have reason to believe are valid. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If, pursuant to or in connection with a single transaction or arrangement, you convey, or propagate by procuring conveyance of, a covered work, and grant a patent license to some of the parties receiving the covered work authorizing them to use, propagate, modify or convey a specific copy of the covered work, then the patent license you grant is automatically extended to all recipients of the covered work and works based on it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;A patent license is “discriminatory” if it does not include within the scope of its coverage, prohibits the exercise of, or is conditioned on the non-exercise of one or more of the rights that are specifically granted under this License. You may not convey a covered work if you are a party to an arrangement with a third party that is in the business of distributing software, under which you make payment to the third party based on the extent of your activity of conveying the work, and under which the third party grants, to any of the parties who would receive the covered work from you, a discriminatory patent license (a) in connection with copies of the covered work conveyed by you (or copies made from those copies), or (b) primarily for and in connection with specific products or compilations that contain the covered work, unless you entered into that arrangement, or that patent license was granted, prior to 28 March 2007. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Nothing in this License shall be construed as excluding or limiting any implied license or other defenses to infringement that may otherwise be available to you under applicable patent law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section12&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;2. No Surrender of Others&apos; Freedom. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot convey a covered work so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not convey it at all. For example, if you agree to terms that obligate you to collect a royalty for further conveying from those to whom you convey the Program, the only way you could satisfy both those terms and this License would be to refrain entirely from conveying the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section13&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;3. Use with the GNU Affero General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, you have permission to link or combine any covered work with a work licensed under version 3 of the GNU Affero General Public License into a single combined work, and to convey the resulting work. The terms of this License will continue to apply to the part which is the covered work, but the special requirements of the GNU Affero General Public License, section 13, concerning interaction through a network will apply to the combination as such. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section14&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;4. Revised Versions of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The Free Software Foundation may publish revised and/or new versions of the GNU General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Each version is given a distinguishing version number. If the Program specifies that a certain numbered version of the GNU General Public License “or any later version” applies to it, you have the option of following the terms and conditions either of that numbered version or of any later version published by the Free Software Foundation. If the Program does not specify a version number of the GNU General Public License, you may choose any version ever published by the Free Software Foundation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If the Program specifies that a proxy can decide which future versions of the GNU General Public License can be used, that proxy&apos;s public statement of acceptance of a version permanently authorizes you to choose that version for the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Later license versions may give you additional or different permissions. However, no additional obligations are imposed on any author or copyright holder as a result of your choosing to follow a later version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section15&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;5. Disclaimer of Warranty. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section16&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;6. Limitation of Liability. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section17&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;7. Interpretation of Sections 15 and 16. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If the disclaimer of warranty and limitation of liability provided above cannot be given local legal effect according to their terms, reviewing courts shall apply local law that most closely approximates an absolute waiver of all civil liability in connection with the Program, unless a warranty or assumption of liability accompanies a copy of the Program in return for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;END OF TERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;howto&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:600;&quot;&gt;ow to Apply These Terms to Your New Programs &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If you develop a new program, and you want it to be of the greatest possible use to the public, the best way to achieve this is to make it free software which everyone can redistribute and change under these terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;To do so, attach the following notices to the program. It is safest to attach them to the start of each source file to most effectively state the exclusion of warranty; and each file should have at least the “copyright” line and a pointer to where the full notice is found. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;one line to give the program&apos;s name and a brief idea of what it does.&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is free software: you can redistribute it and/or modify&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    it under the terms of the GNU General Public License as published by&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    the Free Software Foundation, either version 3 of the License, or&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is distributed in the hope that it will be useful,&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    GNU General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    You should have received a copy of the GNU General Public License&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    along with this program.  If not, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Also add information on how to contact you by electronic and paper mail. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;If the program does terminal interaction, make it output a short notice like this when it starts in an interactive mode: &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;program&amp;gt;  Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This is free software, and you are welcome to redistribute it&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    under certain conditions; type `show c&apos; for details. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate parts of the General Public License. Of course, your program&apos;s commands might be different; for a GUI interface, you would use an “about box”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;You should also get your employer (if you work as a programmer) or school, if any, to sign a “copyright disclaimer” for the program, if necessary. For more information on this, and how to apply and follow the GNU GPL, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The GNU General Public License does not permit incorporating your program into proprietary programs. If your program is a subroutine library, you may consider it more useful to permit linking proprietary applications with the library. If this is what you want to do, use the GNU Lesser General Public License instead of this License. But first, please read &amp;lt;http://www.gnu.org/philosophy/why-not-lgpl.htm&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.01 Transitional//EN&quot;
        &quot;http://www.w3.org/TR/html4/loose.dtd&quot;&gt;
&lt;html&gt;
&lt;meta name=&quot;GENERATOR&quot; content=&quot;TtH 3.67&quot;&gt;
 &lt;style type=&quot;text/css&quot;&gt; div.p { margin-top: 7pt;}&lt;/style&gt;
 &lt;style type=&quot;text/css&quot;&gt;&lt;!--
 td div.comp { margin-top: -0.6ex; margin-bottom: -1ex;}
 td div.comb { margin-top: -0.6ex; margin-bottom: -.6ex;}
 td div.hrcomp { line-height: 0.9; margin-top: -0.8ex; margin-bottom: -1ex;}
 td div.norm {line-height:normal;}
 span.roman {font-family: serif; font-style: normal; font-weight: normal;} 
 span.overacc2 {position: relative;  left: .8em; top: -1.2ex;}
 span.overacc1 {position: relative;  left: .6em; top: -1.2ex;} --&gt;&lt;/style&gt;


&lt;title&gt; GNU GENERAL PUBLIC LICENSE&lt;/title&gt;
 
&lt;h1 align=&quot;center&quot;&gt;GNU GENERAL PUBLIC LICENSE &lt;/h1&gt;

&lt;h3 align=&quot;center&quot;&gt;Versione 3, 29 Giugno 2007 &lt;/h3&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;



&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;i&gt;Questa &amp;#232; una traduzione non ufficiale in italiano della GNU General
Public License. Questa traduzione non &amp;#232; stata pubblicata dalla Free
Software Foundation, e non stabilisce i termini legali di distribuzione
del software che usa la GNU GPL - Soltanto la versione originale in
inglese della GNU GPL fa ci&amp;#242;. Ciononostante, speriamo che questa
traduzione possa aiutare gli utenti di lingua italiana a comprendere un
po&apos; meglio la GNU GPL. &lt;/i&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;br /&gt;&lt;i&gt;This is an unofficial translation of the GNU General Public License into
Italian. It was not published by the Free Software Foundation, and does
not legally state the distribution terms for software that uses the GNU
GPL - only the original English text of the GNU GPL does that. However, we
hope that this translation will help italian speakers understand the
GNU GPL better.&lt;/i&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;center&gt;Copyright &amp;#169;&amp;nbsp;2007 Free Software Foundation, Inc. http://fsf.org/

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;br /&gt;&lt;br /&gt;A chiunque &amp;#232; permesso copiare e ridistribuire copie esatte di questo
documento di licenza, ma non &amp;#232; in alcun modo consentito apportarvi
modifiche.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/center&gt;
&lt;h2&gt; Preambolo&lt;/h2&gt;

La GNU General Public License &amp;#232; una licenza libera e basata su copyleft
per software e altri tipi di opere.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Le licenze della maggior parte del software e di altre opere materiali
sono pensate per togliere la libert&amp;#224; di condividere e modificare
tali opere. Al contrario, la GNU General Public License ha l&apos;obiettivo
di garantire la libert&amp;#224; di condividere e modificare tutte le versioni
di un programma e di fare in modo che esso rimanga software libero per
tutti gli utenti. Noi, Free Software Foundation, usiamo la GNU General
Public License per la maggior parte del nostro software; essa viene
applicata anche a qualunque altro software rilasciato dall&apos;autore sotto
questa licenza. Chiunque pu&amp;#242; utilizzare questa licenza per i suoi
programmi. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Quando parliamo di software libero (free software), ci riferiamo al
concetto di libert&amp;#224;, non al prezzo. Le nostre General Public License
sono progettate per garantire che chiunque abbia la libert&amp;#224; di
distribuire copie di software libero (anche dietro pagamento di un
prezzo, se lo desidera), che chiunque riceva o possa ricevere il codice
sorgente se lo vuole, che chiunque possa apportare modifiche al software
o utilizzarne delle porzioni in altri software liberi, e che chiunque
sappia che ha il diritto di fare tutte queste cose col software libero.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

Per proteggere i vostri diritti, abbiamo la necessit&amp;#224; di impedire che
altri vi neghino questi diritti o vi obblighino a rinunciarvi. Pertanto,
chiunque distribuisce o modifica software rilasciato con questa licenza
assume dei precisi doveri: il dovere di rispettare la libert&amp;#224; degli
altri.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Per esempio, chi distribuisce copie di un programma rilasciato sotto
questa licenza, sia gratis che dietro pagamento di un prezzo, e&apos;
obbligato a riconoscere a chi riceve il software esattamente gli stessi
diritti che ha ricevuto. Deve garantire che chi riceva il software abbia
o possa avere accesso al codice sorgente. E deve chiaramente far
conoscere ai destinatari del software queste condizioni, cos&amp;#236; che essi
conoscano quali sono i loro diritti. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Gli sviluppatori che usano la GNU GPL proteggono i vostri diritti in due
modi: (1) Rivendicando il copyright sul software, e (2) offrendovi
questa licenza che vi garantisce il diritto legale di copiarlo e/o di
modificarlo.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Al fine di proteggere gli sviluppatori e gli autori, la GPL spiega
chiaramente che non c&apos;&amp;#232; nessuna garanzia per questo software
libero. Nell&apos;interesse degli utenti e degli autori, la GPL impone che le
versioni modificate del software vengano esplicitamente marcate come
&quot;modificate&quot;, in maniera tale che eventuali problemi non vengano
erroneamente attribuiti agli autori delle versioni precedenti.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Alcuni dispositivi sono progettati per negare agli utenti
l&apos;installazione o l&apos;esecuzione di versioni modificate del software che
gira sugli stessi, anche se il costruttore si riserva la possibilit&amp;#224;

di farlo. Ci&amp;#242; &amp;#232; fondamentalmente incompatibile con l&apos;obiettivo di
garantire la libert&amp;#224; degli utenti di modificare il software. Una
ripetizione sistematica di tali abusi avviene nel campo dei dispositivi
per usi individuali, e ci&amp;#242; rende questi abusi ancora pi&amp;#249;
inaccettabili. Pertanto, abbiamo realizzato questa versione della GPL al
fine di proibire queste pratiche. Se problemi simili dovessero sorgere
in altri ambiti, saremo pronti ad estendere queste misure a questi nuovi
ambiti in versioni future della GPL, nella maniera che si render&amp;#224;
necessaria per difendere la libert&amp;#224; degli utenti.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
In conclusione, tutti i programmi sono costantemente minacciati dai
brevetti sul software. Gli Stati non dovrebbero permettere ai brevetti
sul software di limitare lo sviluppo e l&apos;utilizzo di software per
computer, ma nei Paesi in cui ci&amp;#242; avviene noi vogliamo evitare in
particolare il pericolo che i brevetti sul software applicati ad un
programma libero possano renderlo, a tutti gli effetti,
proprietario. Per impedire ci&amp;#242;, la GPL assicura che non &amp;#232; possibile
utilizzare i brevetti sul software per rendere un programma non libero.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
I termini e le condizioni esatte per la copia, la distribuzione e la
modifica del software sono riportate di seguito.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;center&gt;			 &lt;font size=&quot;+2&quot;&gt; Termini e Condizioni&lt;/font&gt;
&lt;/center&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;ol type=&quot;1&quot; start=0&gt;	
&lt;li&gt; Definizioni

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&quot;Questa Licenza&quot; si riferisce alla versione 3 della GNU General Public License.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&quot;Copyright&quot; indica anche leggi simili al copyright che riguardano
altri tipi di opere, come le maschere per la produzione di
semiconduttori. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&quot;Il Programma&quot; indica qualunque opera che sia soggetta a copyright e
che sia rilasciata sotto questa Licenza. I detentori della licenza sono
indicati come &quot;tu&quot; o &quot;voi&quot;. Licenziatari e destinatari possono
essere individui o organizzazioni.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&quot;Modificare&quot; un&apos;opera significa copiare o adattare tutta o parte
dell&apos;opera in una maniera che richieda un permesso di copyright, e non
indica la semplice azione di fare una esatta copia dell&apos;opera. L&apos;opera
risultante viene chiamata &quot;versione modificata&quot; dell&apos;opera precedente,
oppure viene detta opera &quot;basata sulla&quot; opera precedente.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Un&apos; &quot;opera coperta da questa licenza&quot; indica il Programma originale
non modificato oppure un&apos;opera basata sul Programma. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&quot;Propagare&quot; un&apos;opera significa fare qualunque cosa con essa che, in
mancanza di un esplicito permesso, ti renda direttamente o
indirettamente perseguibile per violazione secondo le vigenti normative
sul copyright, ad eccezione della semplice esecuzione del Programma su
un computer o della modifica di una copia privata. La Propagazione
include la copia, la distribuzione (con o senza modifiche), la messa a
disposizione al pubblico e, in alcuni stati, altre attivit&amp;#224; simili e
connesse.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&quot;Distribuire&quot; un&apos;opera indica qualunque forma di propagazione che
permetta a terze parti di effettuare o ricevere delle copie. La mera
interazione con un utente attraverso una rete di computer, senza che ci
sia alcun trasferimento di una copia, non &amp;#232; considerata
&quot;Distribuzione&quot;.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

Una interfaccia utente interattiva fornisce delle &quot;Adeguate
Informazioni Legali&quot; soltanto nel caso in cui include una apposita
funzionalit&amp;#224;, resa adeguatamente visibile, che (1) visualizzi
un&apos;adeguata informazione di copyright, e (2) informi l&apos;utente che non
c&apos;&amp;#232; alcuna garanzia sull&apos;opera (eccetto nel caso in cui delle garanzie
sono espressamente fornite), dica che il licenziatario pu&amp;#242; distribuire
l&apos;opera utilizzando questa Licenza, indichi come &amp;#232; possibile prendere
visione di una copia di questa Licenza. Se l&apos;interfaccia presenta una
lista di comandi o di opzioni, come ad esempio un men&amp;#249;, una delle
opzioni fornite nella lista deve rispettare questa condizione.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Codice Sorgente.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Il &quot;codice sorgente&quot; di un&apos;opera indica la forma pi&amp;#249; indicata
dell&apos;opera per effettuare modifiche su di essa. Il &quot;codice oggetto&quot;
indica qualunque forma dell&apos;opera che non sia codice sorgente. 


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Una &quot;Interfaccia Standard&quot; &amp;#232; una interfaccia che risponde ad uno
standard ufficiale definito da un ente di standardizzazione riconosciuto
o, nel caso di interfacce specifiche per un particolare linguaggio di
programmazione, una interfaccia che &amp;#232; largamente utilizzata dagli
sviluppatori per sviluppare in tale linguaggio. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Le &quot;Librerie di Sistema&quot; di un eseguibile includono qualsiasi cosa,
eccetto l&apos;opera nel suo insieme, che (a) sia inclusa nella normale forma
di pacchettizzazione di un &quot;Componente Principale&quot;, ma che non &amp;#232;
parte di quel Componente Principale, e (b) che serva solo a consentire
l&apos;uso dell&apos;opera con quel Componente Principale, o per implementare una
Interfaccia Standard per la quale esista una implementazione disponibile
al pubblico in forma sorgente. Un &quot;Componente Principale&quot;, in questo
contesto, &amp;#232; un componente essenziale (kernel, gestore di finestre
eccetera) dello specifico sistema operativo (ammesso che ce ne sia uno)
sul quale l&apos;eseguibile esegue, o un compilatore utilizzato per produrre
il programma, o un interprete di codice oggetto utilizzato per eseguire
il programma.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Il &quot;Sorgente Corrispondente&quot; per un&apos;opera in forma di codice oggetto
&amp;#232; il codice sorgente necessario per generare, installare e (per un
programma eseguibile) eseguire il codice oggetto e per modificare
l&apos;opera, inclusi gli script per controllare le suddette attivit&amp;#224; di
generazione, installazione ed esecuzione. Non sono incluse le Librerie
di Sistema usate dal programma, o gli strumenti di utilit&amp;#224; generica o i
programmi liberamente accessibili che sono utilizzati, senza modifiche,
per portare a termine le suddette attivit&amp;#224; ma che non fanno parte
dell&apos;opera. Per esempio, il sorgente corrispondente include i file con
le definizioni delle interfacce associati ai file sorgente dell&apos;opera, e
il codice sorgente delle librerie condivise e sottoprogrammi collegati
dinamicamente specificatamente necessari per il programma, ad esempio a
causa di stretta comunicazione dati o di controllo di flusso tra questi
sottoprogrammi e altre parti del programma.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Il Sorgente Corrispondente non include qualunque cosa che l&apos;utente possa
rigenerare automaticamente da altre parti del Sorgente Corrispondente
stesso.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Il Sorgente Corrispondente di un&apos;opera in forma di codice sorgente &amp;#232;
l&apos;opera stessa.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Principali Diritti 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Tutti i diritti garantiti da questa Licenza sono garantiti per la durata
del copyright sul Programma, e sono irrevocabili ammesso che le suddette
condizioni siano rispettate. Questa Licenza afferma esplicitamente il
tuo permesso illimitato di eseguire il Programma non modificato. Il
risultato dell&apos;esecuzione di un programma coperto da questa Licenza &amp;#232;
a sua volta coperto da questa Licenza solo se il risultato stesso, a
causa del suo contenuto, &amp;#232; un&apos;opera coperta da questa Licenza. Questa
Licenza riconosce il tuo diritto all&apos;uso legittimo o altri diritti
equivalenti, come stabilito dalla legislazione sul copyright. 


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Puoi creare, eseguire e propagare programmi coperti da questa Licenza
che tu non distribuisci, senza alcuna condizione fino a quando la tua
Licenza rimane valida. Puoi distribuire opere coperte da questa Licenza
ad altri al solo scopo di ottenere che essi facciano delle modifiche al
programma esclusivamente per te, o che ti forniscano dei servizi per
l&apos;esecuzione di queste opere, ammesso che tu rispetti i termini di
questa Licenza nel distribuire tutto il materiale per il quale non
detieni il copyright. Coloro i quali creano o eseguono per conto tuo un
programma coperto da questa Licenza lo fanno esclusivamente in tua vece,
sotto la tua direzione e il tuo controllo, in maniera tale che sia
proibito a costoro effettuare copie di materiale di cui detieni il
copyright al di fuori della relazione che intrattengono nei tuoi
confronti.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Distribuire opere coperte da licenza in qualunque altra circostanza &amp;#232;
consentito soltanto alle condizioni espresse in seguito. Non &amp;#232;
consentito sottolicenziare le opere: la sezione 10 lo rende non
necessario.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Protezione dei diritti legali degli utenti dalle leggi
	anti-elusione.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Nessun programma protetto da questa Licenza pu&amp;#242; essere considerato
parte di una misura tecnologica di restrizione che sottosta ad alcuna
delle leggi che soddisfano l&apos;articolo 11 del &quot;WIPO copyright treaty&quot;
adottato il 20 Dicembre 1996, o a simili leggi che proibiscono o
limitano l&apos;elusione di tali misure tecnologiche di restrizione.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Quando distribuisci un programma coperto da questa Licenza, rifiuti
tutti i poteri legali atti a proibire l&apos;elusione di misure tecnologiche
di restrizione ammesso che tale elusione sia effettuata nell&apos;esercizio
dei diritti garantiti da questa Licenza riguardo al programma coperto da
questa Licenza, e rinunci all&apos;intenzione di limitare l&apos;operativit&amp;#224; o
la modifica del programma per far valere, contro i diritti degli utenti
del programma, diritti legali tuoi o di terze parti che impediscano
l&apos;elusione di misure tecnologiche di restrizione.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Distribuzione di Copie Esatte.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Ti &amp;#232; permesso distribuire copie esatte del codice sorgente del
Programma come lo hai ricevuto, con qualunque mezzo, ammesso che tu
aggiunga in maniera appropriata su ciascuna copia una appropriata nota
di copyright; che tu lasci intatti tutti gli avvisi che affermano che
questa Licenza e tutte le clausole non-permissive aggiunte in accordo
con la sezione 7 sono valide per il codice che distribuisci; che tu
lasci intatti tutti gli avvisi circa l&apos;assenza di garanzia; che tu
fornisca a tutti i destinatari una copia di questa Licenza assieme al
Programma.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Puoi richiedere il pagamento di un prezzo o di nessun prezzo per
ciascuna copia che distribuisci, e puoi offrire supporto o garanzia
a pagamento.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Distribuzione di Versioni modificate del sorgente.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Puoi distribuire un&apos;opera basata sul Programma, o le modifiche per
produrla a partire dal Programma, nella forma di codice sorgente secondo
i termini della sezione 4, ammesso che tu rispetti anche tutte le
seguenti condizioni:

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;ol type=&quot;a&quot;&gt;
&lt;li&gt; L&apos;opera deve recare con s&amp;#232; delle informazioni adeguate che
	affermino che tu l&apos;hai modificata, indicando la data di modifica.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	L&apos;opera deve recare informazioni adeguate che affermino che essa &amp;#232;

	rilasciata sotto questa Licenza e sotto le condizioni aggiuntive
	secondo quanto indicato dalla Sezione 7. Questa condizione modifica la
	condizione espressa alla sezione 4 di &quot;lasciare intatti tutti gli
	avvisi&quot;.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Devi rilasciare l&apos;intera opera, nel suo complesso, sotto questa
	Licenza a chiunque venga in possesso di una copia di essa. Questa
	Licenza sar&amp;#224; pertanto applicata, assieme ad eventuali clausole
	aggiunte in osservanza della Sezione 7, all&apos;opera nel suo complesso, a
	tutte le sue parti, indipendentemente da come esse siano
	pacchettizzate. Questa Licenza nega il permesso di licenziare l&apos;opera
	in qualunque altro modo, ma non rende nullo un tale permesso ammesso
	che tu lo abbia ricevuto separatamente.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Se l&apos;opera ha delle interfacce utente interattive, ciascuna deve
	mostrare delle Adeguate Informazioni Legali; altrimenti, se il
	Programma ha delle interfacce interattive che non visualizzano delle
	Adeguate Informazioni Legali, il tuo programma non &amp;#232; obbligato a
	visualizzarle.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;
&lt;/ol&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
La giustapposizione di un&apos;opera coperta da questa Licenza assieme ad
altre opere separate e indipendenti, che non sono per loro natura
estensioni del Programma, e che non sono combinate con esso a formare un
altro programma pi&amp;#249; grande, dentro o in uno stesso supporto di
memorizzazione a lungo termine o di distribuzione, &amp;#232; semplicemente
detto &quot;aggregato&quot; se la raccolta e il suo copyright non sono
utilizzati per limitare l&apos;accesso o i diritti legali degli utenti della
raccolta stessa oltre ci&amp;#242; che ciascun singolo programma
consente. L&apos;inclusione di un programma coperto da questa Licenza in un
aggregato non comporta l&apos;applicazione di questa Licenza alle altre parti
dell&apos;aggregato.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Distribuzione in formato non-sorgente


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
	Puoi distribuire un programma coperto da questa Licenza in formato di
	codice oggetto secondo i termini delle sezioni 4 e 5, ammesso che tu
	fornisca anche il  Sorgente Corrispondente in formato comprensibile
	da un computer sotto i termini di questa stessa Licenza, in uno dei
	seguenti modi:
	
&lt;ol type=&quot;a&quot;&gt;
&lt;li&gt; 		Distribuendo il codice oggetto in, o contenuto in, un prodotto
		fisico (inclusi i mezzi fisici di distribuzione), accompagnato dal
		Sorgente Corrispondente su un supporto fisico duraturo comunemente
		utilizzato per lo scambio di software.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Distribuendo il codice oggetto in, o contenuto in, un prodotto fisico
	(inclusi i mezzi fisici di distribuzione), accompagnato da un&apos;offerta
	scritta, valida per almeno tre anni e valida per tutto il tempo
	durante il quale tu offri ricambi o supporto per quel modello di
	prodotto, di fornire a chiunque possieda il codice oggetto (1) una
	copia del Sorgente Corrispondente di tutto il software contenuto nel
	prodotto che &amp;#232; coperto da questa Licenza, su un supporto fisico
	duraturo comunemente utilizzato per lo scambio di software, ad un
	prezzo non superiore al costo ragionevole per effettuare fisicamente
	tale distribuzione del sorgente, oppure (2) accesso alla copia del
	Sorgente Corrispondente attraverso un server di rete senza alcun costo
	aggiuntivo.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Distribuendo copie singole del codice oggetto assieme ad una copia
	dell&apos;offerta scritta di fornire il Sorgente Corrispondente. Questa
	possibilit&amp;#224; &amp;#232; permessa soltanto occasionalmente e per fini non
	commerciali, e solo se tu hai ricevuto il codice oggetto assieme ad
	una tale offerta, in accordo alla sezione 6b.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Distribuendo il codice oggetto mediante accesso da un luogo designato
	(gratis o dietro pagamento di un prezzo), e offrendo un accesso
	equivalente al Sorgente Corrispondente alla stessa maniera a partire
	dallo stesso luogo senza costi aggiuntivi. Non devi obbligare i
	destinatari a copiare il Sorgente Corrispondente assieme al codice
	oggetto. Se il luogo dal quale copiare il codice oggetto &amp;#232; un server
	di rete, il Sorgente Corrispondente pu&amp;#242; trovarsi su un server
	differente (gestito da te o da terze parti) che fornisca
	funzionalit&amp;#224; equivalenti per la copia, a patto che tu fornisca delle
	indicazioni chiare accanto al codice oggetto che indichino dove
	trovare il Sorgente Corrispondente. Indipendentemente da quale server
	ospiti il Sorgente Corrispondente, tu rimani obbligato ad assicurare
	che esso rimanga disponibile per tutto il tempo necessario a
	soddisfare queste condizioni.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Distribuendo il codice oggetto mediante trasmissione peer-to-peer, a
	patto che tu informi gli altri peer circa il luogo in cui il codice
	oggetto e il Sorgente Corrispondente sono gratuitamente offerti al
	pubblico secondo i termini della sezione 6d.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;
&lt;/ol&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
	Una porzione separabile del codice oggetto, il cui sorgente &amp;#232;
	escluso dal Sorgente Corrispondente e trattato come Libreria di
	Sistema, non deve essere obbligatoriamente inclusa nella distribuzione
	del codice oggetto del programma.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

Un &quot;Prodotto Utente&quot; &amp;#232; un (1) &quot;prodotto consumer&quot;, cio&amp;#232;
qualunque propriet&amp;#224; personale tangibile che &amp;#232; normalmente utilizzata
per scopi personali, familiari o domestici, oppure (2) qualunque cosa
progettata o venduta per essere utilizzata in ambiente domestico. Nella
classificazione di un prodotto come &quot;prodotto consumer&quot;, i casi dubbi
andranno risolti in favore dell&apos;ambito di applicazione. Per un dato
prodotto ricevuto da un dato utente, &quot;normalmente utilizzato&quot; si
riferisce ad un uso tipico o comune di quella classe di prodotti,
indipendentemente dallo stato dell&apos;utente specifico o dal modo in cui
l&apos;utente specifico utilizza, o si aspetta o ci si aspetta che utilizzi,
il prodotto. Un prodotto &amp;#232; un &quot;prodotto consumer&quot; indipendentemente
dal fatto che abbia usi commerciali, industriali o diversi da quelli
&quot;consumer&quot;, a meno che questi usi non rappresentino il solo modo utile
di utilizzare il prodotto in questione.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Le &quot;Informazioni di Installazione&quot; per un Prodotto Utente sono i
metodi, le procedure, le chiavi di autorizzazioni o altre informazioni
necessarie per installare ed eseguire versioni modificate di un
programma coperto da questa Licenza all&apos;interno di un Prodotto Utente, a
partire da versioni modificate dei suoi Sorgenti Corrispondenti. Tali
informazioni devono essere sufficienti ad assicurare che il
funzionamento del codice oggetto modificato non sia in nessun caso
proibito o ostacolato per il solo fatto che sono state apportate delle
modifiche.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se distribuisci un codice oggetto secondo le condizioni di questa
sezione in, o assieme, o specificatamente per l&apos;uso in o con un Prodotto
Utente, e la distribuzione avviene come parte di una transazione nella
quale il diritto di possesso e di uso del Prodotto Utente viene
trasferito al destinatario per sempre o per un periodo prefissato
(indipendentemente da come la transazione sia caratterizzata), il
Sorgente Corrispondente distribuito secondo le condizioni di questa
sezione deve essere accompagnato dalle Informazioni di
Installazione. Questa condizione non &amp;#232; richiesta se n&amp;#232; tu n&amp;#232; una
terza parte ha la possibilit&amp;#224; di installare versioni modificate del
codice oggetto sul Prodotto Utente (ad esempio, se il programma &amp;#232;

installato su una ROM)

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
La condizione che richiede di fornire delle Informazioni di Installazione
non implica che venga fornito supporto, garanzia o aggiornamenti per un
programma che &amp;#232; stato modificato o installato dal destinatario, o per
il Prodotto Utente in cui esso &amp;#232; stato modificato o installato.
L&apos;accesso ad una rete pu&amp;#242; essere negato se le modifiche apportate
impattano materialmente sull&apos;operativit&amp;#224; della rete o se violano le
regole e i protocolli di comunicazione attraverso la rete. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Il Sorgente Corrispondente distribuito, e le Informazioni di
Installazione fornite, in accordo con questa sezione, devono essere in
un formato che sia pubblicamente documentato (e con una implementazione
pubblicamente disponibile in formato di codice sorgente), e non devono
richiedere speciali password o chiavi per essere spacchettate, lette o
copiate.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Condizioni Aggiuntive.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Le &quot;Condizioni Aggiuntive&quot; sono condizioni che completano le
condizioni di questa Licenza permettendo delle eccezioni a una o pi&amp;#249;
delle condizioni sopra elencate. Le condizioni aggiuntive che sono
applicabili all&apos;intero Programma devono essere considerate come se
fossero incluse in questa Licenza, a patto che esse siano valide secondo
le normative vigenti. Se alcune condizioni aggiuntive fanno riferimento
soltanto ad alcune parti del Programma, quelle parti possono essere
utilizzate separatamente sotto le stesse condizioni, ma l&apos;intero
Programma rimane sottoposto a questa Licenza senza riferimento ad alcuna
condizione aggiuntiva.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Quando distribuisci una copia di un programma coperto da questa Licenza,
puoi, a tua discrezione, eliminare qualunque condizione aggiuntiva dalla
copia, o da parte di essa. (Le Condizioni Aggiuntive possono essere
scritte in maniera tale da richiedere la loro rimozione in certi casi di
modifica del Programma). Puoi aggiungere Condizioni Aggiuntive su
materiale, aggiunto da te ad un&apos;opera coperta da questa Licenza, per il
quale hai o puoi garantire un&apos;adeguata licenza di copyright.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Indipendentemente da qualunque altra condizione di questa Licenza, e per
il materiale che aggiungi ad un&apos;opera coperta da questa Licenza, puoi
(se autorizzato dai legittimi detentori del copyright per il suddetto
materiale) aggiungere alle condizioni di questa Licenza delle condizioni
che:

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;ol type=&quot;a&quot;&gt;
&lt;li&gt;	Negano la garanzia o limitano la responsabilit&amp;#224; del Programma in
	maniera differente da quanto riportato nelle sezioni 15 e 16 di questa
	Licenza; oppure
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Richiedono il mantenimento di specifiche e circostanziate informative
	legali o di note di attribuzione ad autori nel materiale o assieme
	alle Adeguate Informazioni Legali mostrate dal Programma che lo
	contiene; oppure
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Proibiscono di fornire informazioni errate o ingannevoli sull&apos;origine
	e la provenienza del materiale in oggetto, o richiedono che versioni
	modificate di tale materiale siano appositamente marcate in maniera
	differente rispetto alla versione originale; oppure
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Limitano l&apos;utilizzo per scopi pubblicitari del nome dei detentori del
	copyright o degli autori del materiale; oppure
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;/li&gt;

&lt;li&gt;
	Rifiutano di garantire diritti secondo le leggi sulla propriet&amp;#224;
	intellettuale circa l&apos;uso di nomi, marchi di fabbrica o similari;
	oppure
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt;
	Richiedono l&apos;indennizzo dei detentori del copyright o degli autori del
	materiale in oggetto da parte di chi distribuisce il materiale (o
	versioni modificate dello stesso) con impegni contrattuali circa la
	responsabilit&amp;#224; nei confronti del destinatario, per qualunque
	responsabilit&amp;#224; che questi impegni contrattuali dovessero imporre
	direttamente ai suddetti detentori del copyright e autori.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;
&lt;/ol&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Tutte le altre condizioni addizionali non-permissive sono considerate
&quot;ulteriori restrizioni&quot;, secondo il significato specificato alla
sezione 10. Se il Programma o parti di esso contengono, all&apos;atto della
ricezione dello stesso, informative che specificano che esso &amp;#232;
soggetto a questa Licenza assieme ad una condizione che &amp;#232; una
&quot;ulteriore restrizione&quot;, puoi rimuovere quest&apos;ultima condizione. Se un
documento di licenza contiene ulteriori restrizioni ma permette di
rilicenziare o distribuire il Programma con questa Licenza, puoi
aggiungere al Programma del materiale coperto dalle condizioni di quel
documento di licenza, a patto che le ulteriori restrizioni non compaiano
nelle versioni rilicenziate o ridistribuite. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se aggiungi ad un Programma coperto da questa Licenza delle condizioni
aggiuntive in accordo con questa sezione, devi aggiungere anche, nei
file sorgenti corrispondenti, un avviso che riassuma le condizioni
aggiuntive applicate a quei file, ovvero un avviso che specifichi dove
&amp;#232; possibile trovare copia delle condizioni aggiunte.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Tutte le Condizioni aggiuntive, permissive o non-permissive, devono
essere espresse nella forma di una licenza scritta e separata, o
espresse esplicitamente come eccezioni; in entrambi i casi valgono le
condizioni succitate.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;/li&gt;

&lt;li&gt; Cessazione di Licenza

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Non puoi propagare o modificare un programma coperto da questa Licenza
in maniera diversa da quanto espressamente consentito da questa
Licenza. Qualunque tentativo di propagare o modificare altrimenti il
Programma &amp;#232; nullo, e provoca l&apos;immediata cessazione dei diritti
garantiti da questa Licenza (compresi tutte le eventuali licenze di
brevetto garantite ai sensi del terzo paragrafo della sezione 11). 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
In ogni caso, se cessano tutte le violazioni di questa Licenza, allora
la tua licenza da parte di un dato detentore del copyright viene
ripristinata (a) in via cautelativa, a meno che e fino a quando il
detentore del copyright non cessa esplicitamente e definitivamente la
tua licenza, e (b) in via permanente se il detentore del copyright non
ti notifica in alcun modo la violazione entro 60 giorni dalla cessazione
della licenza.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Inoltre, la tua licenza da parte di un dato detentore del copyright
viene ripristinata in maniera permanente se il detentore del copyright ti
notifica la violazione in maniera adeguata, se questa &amp;#232; la prima volta
che ricevi una notifica di violazione di questa Licenza (per qualunque
Programma) dallo stesso detentore di copyright, e se rimedi alla
violazione entro 30 giorni dalla data di ricezione della notifica di
violazione.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
La cessazione dei tuoi diritti come specificato in questa sezione non
provoca la cessazione delle licenze di terze parti che abbiano ricevuto
copie o diritti da te secondo questa Licenza. Se i tuoi diritti cessano
e non sono ristabiliti in via permanente, non hai diritto di ricevere
nuove licenze per lo stesso materiale, secondo quanto stabilito nella
sezione 10.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;/li&gt;

&lt;li&gt; L&apos;ottenimento di copie non richiede l&apos;accettazione della Licenza

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Non sei obbligato ad accettare i termini di questa Licenza al solo fine
di ottenere o eseguire una copia del Programma. Similmente, propagazioni
collaterali di un Programma coperto da questa Licenza che occorrono come
semplice conseguenza dell&apos;utilizzo di trasmissioni peer-to-peer per la
ricezione di una copia non richiedono l&apos;accettazione della Licenza. In
ogni caso, solo e soltanto questa Licenza ti garantiscono il permesso di
propagare e modificare qualunque programma coperto da questa
Licenza. Queste azioni violano le leggi sul copyright nel caso in cui tu
non accetti questa Licenza. Pertanto, modificando o propagando un
programma coperto da questa Licenza, indichi implicitamente la tua
accettazione della Licenza.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Licenza Automatica per i successivi destinatari

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Ogni qual volta distribuisci un programma coperto da questa Licenza, il
destinatario riceve automaticamente una licenza, dal detentore
originario del copyright, di eseguire, modificare e propagare il
programma, nel rispetto di questa Licenza. Non sei ritenuto responsabile
del rispetto di questa Licenza da parte di terze parti.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Una &quot;transazione d&apos; entit&amp;#224;&quot; &amp;#232; una transazione che trasferisce il
controllo di una organizzazione, o sostanzialmente di tutti i suoi beni,
che suddivide una organizzazione o che fonde pi&amp;#249; organizzazioni. Se la
propagazione di un programma coperto da questa Licenza &amp;#232; conseguente
ad una transazione di entit&amp;#224;, ciascuna parte che ha ruolo nella
transazione e che riceve una copia del programma riceve allo stesso tempo
qualsiasi licenza sul programma che i predecessori della parte
possedevano o potevano rilasciare nel rispetto del paragrafo precedente,
e in pi&amp;#249; il diritto di possesso del Sorgente Corrispondente del
programma dal predecessore in interesse, se il predecessore lo possiede
o se pu&amp;#242; ottenerlo senza troppe difficolt&amp;#224;.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Non puoi imporre nessuna ulteriore restrizione sull&apos;esercizio dei
diritti garantiti o affermati da questa Licenza. Per esempio, non puoi
imporre un prezzo di licenza, una royalty, o altri costi per
l&apos;esercizio dei diritti garantiti da questa Licenza, a non puoi dar
corso ad una controversia (ivi incluse le controversie incrociate o la
difesa in cause legali) affermando che siano stati violati dei
brevetti a causa della produzione, dell&apos;uso, della vendita, della
messa in vendita o dell&apos;importazione del Programma o di sue parti.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Brevetti.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Un &quot;contribuente&quot; &amp;#232; un detentore di copyright che autorizza l&apos;uso
secondo questa Licenza di un Programma o di un&apos;opera basata sul
Programma. L&apos;opera cos&amp;#236; licenziata viene chiamata &quot;versione del
contribuente&quot;. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
I &quot;diritti essenziali di brevetto&quot; da parte di un contribuente sono
tutti i diritti di brevetto che appartengono o che sono controllati dal
contribuente, che siano gi&amp;#224; acquisiti o che saranno acquisiti in
futuro, che possano essere violati in qualche maniera, consentita da
questa Licenza, generando, modificando o vendendo la versione del
contribuente, ma non includono i diritti che possano essere violati
soltanto come conseguenza di ulteriori modifiche alla versione del
contribuente. In relazione a questa definizione, il termine
&quot;controllo&quot; include il diritto di garantire sottolicenze di brevetto
in maniera consistente con le condizioni di questa Licenza.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Ciascun contribuente ti garantisce la licenza di brevetto sui diritti
essenziali di brevetto del contribuente stesso non-esclusiva, valida in
tutto il mondo, esente da royalty, di creare, usare, vendere, offrire in
vendita, importare e altrimenti eseguire, modificare e propagare i
contenuti della versione del contribuente.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Nei tre paragrafi successivi, con &quot;licenza di brevetto&quot; si intende
qualunque accordo o contratto, comunque denominato, di non
rivendicazione di un brevetto (come ad esempio un permesso esplicito di
utilizzare un brevetto o un accordo di rinuncia alla persecuzione per
violazione di brevetto). &quot;Garantire&quot; una tale licenza di brevetto ad
una parte significa portare a termine un tale accordo o contratto di non
rivendicazione di brevetto contro la parte.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se distribuisci un programma coperto da questa Licenza, confidando
consapevolmente su una licenza di brevetto, e il Sorgente Corrispondente
per il programma non &amp;#232; reso disponibile per la copia, senza alcun
onere aggiuntivo e comunque nel rispetto delle condizioni di questa
Licenza, attraverso un server di rete pubblicamente accessibile o
tramite altri mezzi facilmente accessibili, allora devi (1) fare in modo
che il Sorgente Corrispondente sia reso disponibile come sopra, oppure
(2) fare in modo di rinunciare ai benefici della licenza di brevetto per
quel particolare programma, oppure (3) adoperarti, in maniera
consistente con le condizioni di questa Licenza, per estendere la
licenza di brevetto a tutti i destinatari successivi. &quot;Confidare
consapevolmente&quot; significa che tu sei attualmente cosciente che,
eccettuata la licenza di brevetto, la distribuzione da parte tua di un
programma protetto da questa Licenza in un paese, o l&apos;utilizzo in un
paese del programma coperto da questa Licenza da parte di un
destinatario, pu&amp;#242; violare uno o pi&amp;#249; brevetti in quel paese che tu
hai ragione di ritenere validi.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se, come conseguenza o in connessione con una singola transazione o
con un dato accordo, distribuisci, o fai in modo di distribuire, un
programma coperto da questa Licenza, e garantisci una licenza di
brevetto per alcune delle parti che ricevono il Programma
autorizzandole ad utilizzare, propagare, modificare o distribuire una
specifica copia del Programma, allora la licenza di brevetto che
fornisci &amp;#232; automaticamente estesa a tutti i destinatari del
Programma coperto da questa Licenza e delle opere basate sul
Programma.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

Una licenza di brevetto &amp;#232; &quot;discriminatoria&quot; se non include
nell&apos;ambito della sua copertura, proibisce l&apos;esercizio, o &amp;#232; vincolata
al non-esercizio di uno o pi&amp;#249; dei diritti che sono specificatamente
garantiti da questa Licenza. Non puoi distribuire un Programma coperto
da questa Licenza se sei parte di un accordo con una terza parte la cui
attivit&amp;#224; comprende la distribuzione di software, secondo il quale tu
sei costretto ad un pagamento alla parte terza in funzione della tua
attivit&amp;#224; di distribuzione del Programma, e in conseguenza del quale la
parte terza garantisce, a qualunque delle parti che riceveranno il
Programma da te, una licenza di brevetto discriminatoria (a) assieme a
copie del Programma coperto da questa Licenza distribuite da te (o ad
altre copie fatte da codeste copie), oppure (b) principalmente per e in
connessione con specifici prodotti o raccolte di prodotti che contengono
il Programma, a meno che l&apos;accordo non sia stato stipulato, o le licenze
di brevetto non siano state rilasciate, prima del 28 Marzo 2007.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Nessuna parte di questa Licenza pu&amp;#242; essere interpretata come atta ad
escludere o limitare gli effetti di qualunque altra licenza o altri
meccanismi di difesa dalla violazione che possano altrimenti essere resi
disponibili dalla normativa vigente in materia di brevetti.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Nessuna resa di libert&amp;#224; altrui

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se ti vengono imposte delle condizioni (da un ordine giudiziario, da
un accordo o da qualunque altra eventualit&amp;#224;) che contraddicono le
condizioni di questa Licenza, non sei in nessun modo esonerato dal
rispetto delle condizioni di questa Licenza. Se non puoi distribuire
un Programma coperto da questa Licenza per sottostare simultaneamente
agli obblighi derivanti da questa Licenza e ad altri obblighi
pertinenti, allora non puoi distribuire il Programma per nessun
motivo. Per esempio, se accetti delle condizioni che ti obbligano a
richiedere il pagamento di una royalty per le distribuzioni
successivamente effettuate da coloro ai quali hai distribuito il
Programma, l&apos;unico modo per soddisfare sia queste condizioni che
questa Licenza &amp;#232; evitare del tutto la distribuzione del Programma.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Utilizzo con la GNU Affero General Public License

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Indipendentemente da qualunque altra condizione espressa da questa
Licenza, hai il permesso di collegare o combinare qualunque Programma
coperto da questa Licenza con un&apos;opera rilasciata sotto la versione 3
della licenza GNU Affero General Public License, ottenendo un singolo
Programma derivato, e di distribuire il Programma risultante. Le
condizioni di questa Licenza continuano a valere per le parti
riguardanti il Programma che sono coperte da questa Licenza, mentre le
condizioni speciali della GNU Affero General Public License, sezione 13,
riguardanti l&apos;interazione mediante rete, saranno applicate al Programma
cos&amp;#236; risultante.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Versioni rivedute di questa Licenza

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
La Free Software Foundation pu&amp;#242; pubblicare delle versioni rivedute
e/o delle nuove versioni della GNU General Public License di tanto in
tanto. Tali versioni saranno simili, nello spirito, alla presente
versione, ma potranno differire nei dettagli al fine di affrontare
nuovi problemi e nuove situazioni. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
A ciascuna versione viene assegnato un numero identificativo di
versione. Se il Programma specifica che si applica a s&amp;#232; stesso una
certa versione della GNU General Public License, &quot;o qualunque altra
versione successiva&quot;, hai la possibilit&amp;#224; di sottostare alle
condizioni di quella specifica versione o di qualunque altra versione
successiva pubblicata dalla Free Software Foundation. Se il Programma
non specifica un numero di versione della GNU General Public License,
puoi scegliere qualunque versione della GNU General Public License
pubblicata dalla Free Software Foundation. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se il Programma specifica che un sostituto o un procuratore pu&amp;#242;

decidere quali versioni future della GNU General Public License posso
essere utilizzate, allora tale scelta di accettazione di una data
versione ti autorizza, in maniera permanente, ad utilizzare quella
versione della Licenza per il Programma. 

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Versioni successive della Licenza possono garantire diritti aggiuntivi o
leggermente differenti. Ad ogni modo, nessun obbligo aggiuntivo viene
imposto agli autori o ai detentori di copyright come conseguenza della
tua scelta di adottare una versione successiva della Licenza.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Rinuncia alla Garanzia

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
NON C&apos;E&apos; NESSUNA GARANZIA PER IL PROGRAMMA, PER QUANTO CONSENTITO DALLE
VIGENTI NORMATIVE. ECCETTO QUANDO ALTRIMENTI STABILITO PER ISCRITTO, I
DETENTORI DEL COPYRIGHT E/O LE ALTRE PARTI FORNISCONO IL PROGRAMMA
&quot;COSI&apos; COME &amp;#200;&quot; SENZA GARANZIA DI ALCUN TIPO, NE&apos; ESPRESSA NE&apos;
IMPLICITA, INCLUSE, MA NON LIMITATE A, LE GARANZIE DI COMMERCIABILITA&apos; O
DI UTILIZZABILITA&apos; PER UN PARTICOLARE SCOPO. L&apos;INTERO RISCHIO
CONCERNENTE LA QUALITA&apos; E LE PRESTAZIONI DEL PROGRAMMA E&apos; DEL
LICENZIATARIO. SE IL PROGRAMMA DOVESSE RISULTARE DIFETTOSO, IL
LICENZIATARIO SI ASSUME I COSTI DI MANUTENZIONE, RIPARAZIONE O
CORREZIONE.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Limitazione di Responsabilit&amp;#224;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
  IN NESSUN CASO, A MENO CHE NON SIA RICHIESTO DALLA NORMATIVA VIGENTE
  O CONCORDATO PER ISCRITTO, I DETENTORI DEL COPYRIGHT, O QUALUNQUE
  ALTRA PARTE CHE MODIICA E/O DISTRIBUISCE IL PROGRAMMA SECONDO LE
  CONDIZIONI PRECEDENTI, POSSONO ESSERE RITENUTI RESPONSABILI NEI
  CONFRONTI DEL LICENZIATARIO PER DANNI, INCLUSO QUALUNQUE
  DANNEGGIAMENTO GENERICO, SPECIALE, INCIDENTALE O CONSEQUENZIALE
  DOVUTO ALL&apos;USO O ALL&apos;IMPOSSIBILITA&apos; D&apos;USO DEL PROGRAMMA (INCLUSI, MA
  NON LIMITATI A, LE PERDITE DI DATI, LA CORRUZIONE DI DATI, LE
  PERDITE SOSTENUTE DAL LICENZIATARIO O DA TERZE PARTI O
  L&apos;IMPOSSIBILITA&apos; DEL PROGRAMMA A FUNZIONARE ASSIEME AD ALTRI
  PROGRAMMI), ANCHE NEL CASO IN CUI IL DETENTORE O LE ALTRE PARTI
  SIANO STATI AVVISATI CIRCA LA POSSIBILITA&apos; DI TALI DANNEGGIAMENTI.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;

&lt;li&gt; Interpretazione delle Sezioni 15 e 16.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se la dichiarazione di garanzia e la limitazione di responsabilit&amp;#224;
fornite precedentemente non hanno effetto legale in un paese a causa
delle loro condizioni, le corti di giustizia devono applicare la norma
locale che pi&amp;#249; si avvicini al rifiuto assoluto di qualsivoglia
responsabilit&amp;#224; civile relativa al Programma, a meno che una garanzia o
una assunzione di responsabilit&amp;#224; scritta non accompagni una copia del
programma ottenuta dietro pagamento.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;center&gt;  &lt;font size=&quot;+2&quot;&gt; Fine dei Termini e delle Condizioni&lt;/font&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
  Come applicare questre condizioni di Licenza ai vostri programmi

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/center&gt;Se sviluppi un nuovo programma, e vuoi che esso sia della massima
utilit&amp;#224;, il modo migliore &amp;#232; renderlo software libero in modo che
chiunque possa ridistribuirlo e modificarlo secondo i termini di questa
Licenza.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Per fare ci&amp;#242;, allega le seguenti note informative al programma. Il
modo migliore &amp;#232; inserirle all&apos;inizio di ciascun file sorgente, al fine
di rimarcare adeguatamente la mancanza di garanzia; ciascun file
dovrebbe inoltre contenere la dichiarazione di copyright e un
riferimento al posto in cui &amp;#232; possibile ottenere la versione completa
delle note informative.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;blockquote&gt;  &amp;lt;one line to give the program&apos;s name and a brief idea of what it does.&amp;#62;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
  Copyright (C) &amp;lt;year&amp;#62;  &amp;lt;name of author&amp;#62;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see
  http://www.gnu.org/licenses/.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/blockquote&gt;Inoltre, aggiungi le informazioni necessarie a contattarti via posta
ordinaria o via posta elettronica.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Se il programma interagisce mediante terminale, fai in modo che
visualizzi, quando viene avviato in modalit&amp;#224; interattiva, un breve
messaggio come quello che segue:

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;blockquote&gt;  &amp;lt;program&amp;#62;  Copyright (C) &amp;lt;year&amp;#62;  &amp;lt;name of author&amp;#62;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
  This program comes with ABSOLUTELY NO WARRANTY; for details type
&lt;tt&gt;show w&lt;/tt&gt;.
  This is free software, and you are welcome to redistribute it
  under certain conditions; type &lt;tt&gt;show c&lt;/tt&gt; for details.
&lt;/blockquote&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Gli ipotetici comandi &lt;tt&gt;show w&lt;/tt&gt; e &lt;tt&gt;show c&lt;/tt&gt; devono visualizzare le
parti corrispondenti della GNU General Public License. Naturalmente i
comandi del tuo programma potrebbero essere differenti; per una
interfaccia di tipo GUI, dovresti usare un bottone &quot;About&quot; o
&quot;Info&quot;. 


&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
Devi inoltre fare in modo che il tuo datore di lavoro (se lavori come
programmatore presso terzi) o la tua scuola, eventualmente, firmino una
&quot;rinuncia al copyright&quot; sul programma, se necessario. Per maggiori
informazioni su questo punto, e su come applicare e rispettare la GNU
GPL, consultare la pagina http://www.gnu.org/licenses/.

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
La GNU General Public License non consente di incorporare il programma
all&apos;interno di software proprietario. Se il tuo programma &amp;#232; una
libreria di funzioni, potresti ritenere pi&amp;#249; opportuno consentire il
collegamento tra software proprietario e la tua libreria. Se &amp;#232; questo
ci&amp;#242; che vuoi, allora utilizza la GNU Lesser General Public License
anzich&amp;#233; questa Licenza, ma prima leggi
http://www.gnu.org/philosophy/why-not-lgpl.html.
&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;
&lt;/li&gt;
&lt;/ol&gt;

&lt;div class=&quot;p&quot;&gt;&lt;!----&gt;&lt;/div&gt;

&lt;br /&gt;&lt;br /&gt;&lt;hr /&gt;&lt;small&gt;File translated from
T&lt;sub&gt;&lt;font size=&quot;-1&quot;&gt;E&lt;/font&gt;&lt;/sub&gt;X
by &lt;a href=&quot;http://hutchinson.belmont.ma.us/tth/&quot;&gt;
T&lt;sub&gt;&lt;font size=&quot;-1&quot;&gt;T&lt;/font&gt;&lt;/sub&gt;H&lt;/a&gt;,
version 3.67.&lt;br /&gt;On 15 Jul 2007, 11:58.&lt;/small&gt;
&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;The cd/dvd image manipulator for linux&lt;br /&gt;is created by:&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-style:italic;&quot;&gt;&lt;br /&gt;Fabrizio Di Marco&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt;Il manipolatore cd/dvd per Linux&lt;br /&gt;è sviluppato da:&lt;br /&gt;&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-style:italic;&quot;&gt;&lt;br /&gt;Fabrizio Di Marco&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Honor &amp;&amp; Glory</source>
        <translation type="unfinished">Onore &amp;&amp; Gloria</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;You can contact us by email at:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0000ff;&quot;&gt;acetoneiso@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Official Website:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.acetoneteam.org/&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.acetoneteam.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Contattaci via email a:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;mailto:acetoneiso@gmail.com&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0000ff;&quot;&gt;acetoneiso@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:9pt;&quot;&gt;Sito Ufficiale:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.acetoneteam.org/&quot;&gt;&lt;span style=&quot; font-size:9pt; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.acetoneteam.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;GNU GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Version 3, 29 June 2007 &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Copyright © 2007 Free Software Foundation, Inc. &amp;lt;http://fsf.org/&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;preamble&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;reamble &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The GNU General Public License is a free, copyleft license for software and other kinds of works. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program--to make sure it remains free software for all its users. We, the Free Software Foundation, use the GNU General Public License for most of our software; it applies also to any other work released this way by its authors. You can apply it to your programs, too. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Developers that use the GNU GPL protect your rights with two steps: (1) assert copyright on the software, and (2) offer you this License giving you legal permission to copy, distribute and/or modify it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For the developers&apos; and authors&apos; protection, the GPL clearly explains that there is no warranty for this free software. For both users&apos; and authors&apos; sake, the GPL requires that modified versions be marked as changed, so that their problems will not be attributed erroneously to authors of previous versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Some devices are designed to deny users access to install or run modified versions of the software inside them, although the manufacturer can do so. This is fundamentally incompatible with the aim of protecting users&apos; freedom to change the software. The systematic pattern of such abuse occurs in the area of products for individuals to use, which is precisely where it is most unacceptable. Therefore, we have designed this version of the GPL to prohibit the practice for those products. If such problems arise substantially in other domains, we stand ready to extend this provision to those domains in future versions of the GPL, as needed to protect the freedom of users. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Finally, every program is threatened constantly by software patents. States should not allow patents to restrict development and use of software on general-purpose computers, but in those that do, we wish to avoid the special danger that patents applied to a free program could make it effectively proprietary. To prevent this, the GPL assures that patents cannot be used to render the program non-free. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;terms&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;ERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section0&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;0&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Definitions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“This License” refers to version 3 of the GNU General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Copyright” also means copyright-like laws that apply to other kinds of works, such as semiconductor masks. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“The Program” refers to any copyrightable work licensed under this License. Each licensee is addressed as “you”. “Licensees” and “recipients” may be individuals or organizations. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “modify” a work means to copy from or adapt all or part of the work in a fashion requiring copyright permission, other than the making of an exact copy. The resulting work is called a “modified version” of the earlier work or a work “based on” the earlier work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “covered work” means either the unmodified Program or a work based on the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “propagate” a work means to do anything with it that, without permission, would make you directly or secondarily liable for infringement under applicable copyright law, except executing it on a computer or modifying a private copy. Propagation includes copying, distribution (with or without modification), making available to the public, and in some countries other activities as well. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To “convey” a work means any kind of propagation that enables other parties to make or receive copies. Mere interaction with a user through a computer network, with no transfer of a copy, is not conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;An interactive user interface displays “Appropriate Legal Notices” to the extent that it includes a convenient and prominently visible feature that (1) displays an appropriate copyright notice, and (2) tells the user that there is no warranty for the work (except to the extent that warranties are provided), that licensees may convey the work under this License, and how to view a copy of this License. If the interface presents a list of user commands or options, such as a menu, a prominent item in the list meets this criterion. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Source Code. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “source code” for a work means the preferred form of the work for making modifications to it. “Object code” means any non-source form of a work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “Standard Interface” means an interface that either is an official standard defined by a recognized standards body, or, in the case of interfaces specified for a particular programming language, one that is widely used among developers working in that language. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “System Libraries” of an executable work include anything, other than the work as a whole, that (a) is included in the normal form of packaging a Major Component, but which is not part of that Major Component, and (b) serves only to enable use of the work with that Major Component, or to implement a Standard Interface for which an implementation is available to the public in source code form. A “Major Component”, in this context, means a major essential component (kernel, window system, and so on) of the specific operating system (if any) on which the executable work runs, or a compiler used to produce the work, or an object code interpreter used to run it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The “Corresponding Source” for a work in object code form means all the source code needed to generate, install, and (for an executable work) run the object code and to modify the work, including scripts to control those activities. However, it does not include the work&apos;s System Libraries, or general-purpose tools or generally available free programs which are used unmodified in performing those activities but which are not part of the work. For example, Corresponding Source includes interface definition files associated with source files for the work, and the source code for shared libraries and dynamically linked subprograms that the work is specifically designed to require, such as by intimate data communication or control flow between those subprograms and other parts of the work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Corresponding Source need not include anything that users can regenerate automatically from other parts of the Corresponding Source. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Corresponding Source for a work in source code form is that same work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;2&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Basic Permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;All rights granted under this License are granted for the term of copyright on the Program, and are irrevocable provided the stated conditions are met. This License explicitly affirms your unlimited permission to run the unmodified Program. The output from running a covered work is covered by this License only if the output, given its content, constitutes a covered work. This License acknowledges your rights of fair use or other equivalent, as provided by copyright law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Conveying under any other circumstances is permitted solely under the conditions stated below. Sublicensing is not allowed; section 10 makes it unnecessary. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Protecting Users&apos; Legal Rights From Anti-Circumvention Law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No covered work shall be deemed part of an effective technological measure under any applicable law fulfilling obligations under article 11 of the WIPO copyright treaty adopted on 20 December 1996, or similar laws prohibiting or restricting circumvention of such measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When you convey a covered work, you waive any legal power to forbid circumvention of technological measures to the extent such circumvention is effected by exercising rights under this License with respect to the covered work, and you disclaim any intention to limit operation or modification of the work as a means of enforcing, against the work&apos;s users, your or third parties&apos; legal rights to forbid circumvention of technological measures. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;4&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Verbatim Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey verbatim copies of the Program&apos;s source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice; keep intact all notices stating that this License and any non-permissive terms added in accord with section 7 apply to the code; keep intact all notices of the absence of any warranty; and give all recipients a copy of this License along with the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may charge any price or no price for each copy that you convey, and you may offer support or warranty protection for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section5&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;5&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Modified Source Versions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey a work based on the Program, or the modifications to produce it from the Program, in the form of source code under the terms of section 4, provided that you also meet all of these conditions: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) The work must carry prominent notices stating that you modified it, and giving a relevant date. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) The work must carry prominent notices stating that it is released under this License and any conditions added under section 7. This requirement modifies the requirement in section 4 to “keep intact all notices”. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) You must license the entire work, as a whole, under this License to anyone who comes into possession of a copy. This License will therefore apply, along with any applicable section 7 additional terms, to the whole of the work, and all its parts, regardless of how they are packaged. This License gives no permission to license the work in any other way, but it does not invalidate such permission if you have separately received it. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) If the work has interactive user interfaces, each must display Appropriate Legal Notices; however, if the Program has interactive interfaces that do not display Appropriate Legal Notices, your work need not make them do so. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A compilation of a covered work with other separate and independent works, which are not by their nature extensions of the covered work, and which are not combined with it such as to form a larger program, in or on a volume of a storage or distribution medium, is called an “aggregate” if the compilation and its resulting copyright are not used to limit the access or legal rights of the compilation&apos;s users beyond what the individual works permit. Inclusion of a covered work in an aggregate does not cause this License to apply to the other parts of the aggregate. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section6&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;6&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Conveying Non-Source Forms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may convey a covered work in object code form under the terms of sections 4 and 5, provided that you also convey the machine-readable Corresponding Source under the terms of this License, in one of these ways: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by the Corresponding Source fixed on a durable physical medium customarily used for software interchange. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by a written offer, valid for at least three years and valid for as long as you offer spare parts or customer support for that product model, to give anyone who possesses the object code either (1) a copy of the Corresponding Source for all the software in the product that is covered by this License, on a durable physical medium customarily used for software interchange, for a price no more than your reasonable cost of physically performing this conveying of source, or (2) access to copy the Corresponding Source from a network server at no charge. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Convey individual copies of the object code with a copy of the written offer to provide the Corresponding Source. This alternative is allowed only occasionally and noncommercially, and only if you received the object code with such an offer, in accord with subsection 6b. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Convey the object code by offering access from a designated place (gratis or for a charge), and offer equivalent access to the Corresponding Source in the same way through the same place at no further charge. You need not require recipients to copy the Corresponding Source along with the object code. If the place to copy the object code is a network server, the Corresponding Source may be on a different server (operated by you or a third party) that supports equivalent copying facilities, provided you maintain clear directions next to the object code saying where to find the Corresponding Source. Regardless of what server hosts the Corresponding Source, you remain obligated to ensure that it is available for as long as needed to satisfy these requirements. &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Convey the object code using peer-to-peer transmission, provided you inform other peers where the object code and Corresponding Source of the work are being offered to the general public at no charge under subsection 6d. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A separable portion of the object code, whose source code is excluded from the Corresponding Source as a System Library, need not be included in conveying the object code work. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “User Product” is either (1) a “consumer product”, which means any tangible personal property which is normally used for personal, family, or household purposes, or (2) anything designed or sold for incorporation into a dwelling. In determining whether a product is a consumer product, doubtful cases shall be resolved in favor of coverage. For a particular product received by a particular user, “normally used” refers to a typical or common use of that class of product, regardless of the status of the particular user or of the way in which the particular user actually uses, or expects or is expected to use, the product. A product is a consumer product regardless of whether the product has substantial commercial, industrial or non-consumer uses, unless such uses represent the only significant mode of use of the product. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Installation Information” for a User Product means any methods, procedures, authorization keys, or other information required to install and execute modified versions of a covered work in that User Product from a modified version of its Corresponding Source. The information must suffice to ensure that the continued functioning of the modified object code is in no case prevented or interfered with solely because modification has been made. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you convey an object code work under this section in, or with, or specifically for use in, a User Product, and the conveying occurs as part of a transaction in which the right of possession and use of the User Product is transferred to the recipient in perpetuity or for a fixed term (regardless of how the transaction is characterized), the Corresponding Source conveyed under this section must be accompanied by the Installation Information. But this requirement does not apply if neither you nor any third party retains the ability to install modified object code on the User Product (for example, the work has been installed in ROM). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The requirement to provide Installation Information does not include a requirement to continue to provide support service, warranty, or updates for a work that has been modified or installed by the recipient, or for the User Product in which it has been modified or installed. Access to a network may be denied when the modification itself materially and adversely affects the operation of the network or violates the rules and protocols for communication across the network. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Corresponding Source conveyed, and Installation Information provided, in accord with this section must be in a format that is publicly documented (and with an implementation available to the public in source code form), and must require no special password or key for unpacking, reading or copying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section7&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;7&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Additional Terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;“Additional permissions” are terms that supplement the terms of this License by making exceptions from one or more of its conditions. Additional permissions that are applicable to the entire Program shall be treated as though they were included in this License, to the extent that they are valid under applicable law. If additional permissions apply only to part of the Program, that part may be used separately under those permissions, but the entire Program remains governed by this License without regard to the additional permissions. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;When you convey a copy of a covered work, you may at your option remove any additional permissions from that copy, or from any part of it. (Additional permissions may be written to require their own removal in certain cases when you modify the work.) You may place additional permissions on material, added by you to a covered work, for which you have or can give appropriate copyright permission. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, for material you add to a covered work, you may (if authorized by the copyright holders of that material) supplement the terms of this License with terms: &lt;/span&gt;&lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Disclaiming warranty or limiting liability differently from the terms of sections 15 and 16 of this License; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Requiring preservation of specified reasonable legal notices or author attributions in that material or in the Appropriate Legal Notices displayed by works containing it; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Prohibiting misrepresentation of the origin of that material, or requiring that modified versions of such material be marked in reasonable ways as different from the original version; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Limiting the use for publicity purposes of names of licensors or authors of the material; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Declining to grant rights under trademark law for use of some trade names, trademarks, or service marks; or &lt;/li&gt;
&lt;li style=&quot; font-size:10pt;&quot; style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;f) Requiring indemnification of licensors and authors of that material by anyone who conveys the material (or modified versions of it) with contractual assumptions of liability to the recipient, for any liability that these contractual assumptions directly impose on those licensors and authors. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;All other non-permissive additional terms are considered “further restrictions” within the meaning of section 10. If the Program as you received it, or any part of it, contains a notice stating that it is governed by this License along with a term that is a further restriction, you may remove that term. If a license document contains a further restriction but permits relicensing or conveying under this License, you may add to a covered work material governed by the terms of that license document, provided that the further restriction does not survive such relicensing or conveying. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you add terms to a covered work in accord with this section, you must place, in the relevant source files, a statement of the additional terms that apply to those files, or a notice indicating where to find the applicable terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Additional terms, permissive or non-permissive, may be stated in the form of a separately written license, or stated as exceptions; the above requirements apply either way. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section8&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;8&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Termination. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may not propagate or modify a covered work except as expressly provided under this License. Any attempt otherwise to propagate or modify it is void, and will automatically terminate your rights under this License (including any patent licenses granted under the third paragraph of section 11). &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, you do not qualify to receive new licenses for the same material under section 10. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section9&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;9&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;. Acceptance Not Required for Having Copies. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You are not required to accept this License in order to receive or run a copy of the Program. Ancillary propagation of a covered work occurring solely as a consequence of using peer-to-peer transmission to receive a copy likewise does not require acceptance. However, nothing other than this License grants you permission to propagate or modify any covered work. These actions infringe copyright if you do not accept this License. Therefore, by modifying or propagating a covered work, you indicate your acceptance of this License to do so. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section10&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;0. Automatic Licensing of Downstream Recipients. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each time you convey a covered work, the recipient automatically receives a license from the original licensors, to run, modify and propagate that work, subject to this License. You are not responsible for enforcing compliance by third parties with this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;An “entity transaction” is a transaction transferring control of an organization, or substantially all assets of one, or subdividing an organization, or merging organizations. If propagation of a covered work results from an entity transaction, each party to that transaction who receives a copy of the work also receives whatever licenses to the work the party&apos;s predecessor in interest had or could give under the previous paragraph, plus a right to possession of the Corresponding Source of the work from the predecessor in interest, if the predecessor has it or can get it with reasonable efforts. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You may not impose any further restrictions on the exercise of the rights granted or affirmed under this License. For example, you may not impose a license fee, royalty, or other charge for exercise of rights granted under this License, and you may not initiate litigation (including a cross-claim or counterclaim in a lawsuit) alleging that any patent claim is infringed by making, using, selling, offering for sale, or importing the Program or any portion of it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section11&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1. Patents. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A “contributor” is a copyright holder who authorizes use under this License of the Program or a work on which the Program is based. The work thus licensed is called the contributor&apos;s “contributor version”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A contributor&apos;s “essential patent claims” are all patent claims owned or controlled by the contributor, whether already acquired or hereafter acquired, that would be infringed by some manner, permitted by this License, of making, using, or selling its contributor version, but do not include claims that would be infringed only as a consequence of further modification of the contributor version. For purposes of this definition, “control” includes the right to grant patent sublicenses in a manner consistent with the requirements of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each contributor grants you a non-exclusive, worldwide, royalty-free patent license under the contributor&apos;s essential patent claims, to make, use, sell, offer for sale, import and otherwise run, modify and propagate the contents of its contributor version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;In the following three paragraphs, a “patent license” is any express agreement or commitment, however denominated, not to enforce a patent (such as an express permission to practice a patent or covenant not to sue for patent infringement). To “grant” such a patent license to a party means to make such an agreement or commitment not to enforce a patent against the party. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you convey a covered work, knowingly relying on a patent license, and the Corresponding Source of the work is not available for anyone to copy, free of charge and under the terms of this License, through a publicly available network server or other readily accessible means, then you must either (1) cause the Corresponding Source to be so available, or (2) arrange to deprive yourself of the benefit of the patent license for this particular work, or (3) arrange, in a manner consistent with the requirements of this License, to extend the patent license to downstream recipients. “Knowingly relying” means you have actual knowledge that, but for the patent license, your conveying the covered work in a country, or your recipient&apos;s use of the covered work in a country, would infringe one or more identifiable patents in that country that you have reason to believe are valid. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If, pursuant to or in connection with a single transaction or arrangement, you convey, or propagate by procuring conveyance of, a covered work, and grant a patent license to some of the parties receiving the covered work authorizing them to use, propagate, modify or convey a specific copy of the covered work, then the patent license you grant is automatically extended to all recipients of the covered work and works based on it. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;A patent license is “discriminatory” if it does not include within the scope of its coverage, prohibits the exercise of, or is conditioned on the non-exercise of one or more of the rights that are specifically granted under this License. You may not convey a covered work if you are a party to an arrangement with a third party that is in the business of distributing software, under which you make payment to the third party based on the extent of your activity of conveying the work, and under which the third party grants, to any of the parties who would receive the covered work from you, a discriminatory patent license (a) in connection with copies of the covered work conveyed by you (or copies made from those copies), or (b) primarily for and in connection with specific products or compilations that contain the covered work, unless you entered into that arrangement, or that patent license was granted, prior to 28 March 2007. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Nothing in this License shall be construed as excluding or limiting any implied license or other defenses to infringement that may otherwise be available to you under applicable patent law. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section12&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;2. No Surrender of Others&apos; Freedom. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot convey a covered work so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not convey it at all. For example, if you agree to terms that obligate you to collect a royalty for further conveying from those to whom you convey the Program, the only way you could satisfy both those terms and this License would be to refrain entirely from conveying the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section13&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;3. Use with the GNU Affero General Public License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Notwithstanding any other provision of this License, you have permission to link or combine any covered work with a work licensed under version 3 of the GNU Affero General Public License into a single combined work, and to convey the resulting work. The terms of this License will continue to apply to the part which is the covered work, but the special requirements of the GNU Affero General Public License, section 13, concerning interaction through a network will apply to the combination as such. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section14&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;4. Revised Versions of this License. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The Free Software Foundation may publish revised and/or new versions of the GNU General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Each version is given a distinguishing version number. If the Program specifies that a certain numbered version of the GNU General Public License “or any later version” applies to it, you have the option of following the terms and conditions either of that numbered version or of any later version published by the Free Software Foundation. If the Program does not specify a version number of the GNU General Public License, you may choose any version ever published by the Free Software Foundation. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the Program specifies that a proxy can decide which future versions of the GNU General Public License can be used, that proxy&apos;s public statement of acceptance of a version permanently authorizes you to choose that version for the Program. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Later license versions may give you additional or different permissions. However, no additional obligations are imposed on any author or copyright holder as a result of your choosing to follow a later version. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section15&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;5. Disclaimer of Warranty. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section16&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;6. Limitation of Liability. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section17&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;7. Interpretation of Sections 15 and 16. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the disclaimer of warranty and limitation of liability provided above cannot be given local legal effect according to their terms, reviewing courts shall apply local law that most closely approximates an absolute waiver of all civil liability in connection with the Program, unless a warranty or assumption of liability accompanies a copy of the Program in return for a fee. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;END OF TERMS AND CONDITIONS &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;howto&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;ow to Apply These Terms to Your New Programs &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If you develop a new program, and you want it to be of the greatest possible use to the public, the best way to achieve this is to make it free software which everyone can redistribute and change under these terms. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To do so, attach the following notices to the program. It is safest to attach them to the start of each source file to most effectively state the exclusion of warranty; and each file should have at least the “copyright” line and a pointer to where the full notice is found. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;one line to give the program&apos;s name and a brief idea of what it does.&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is free software: you can redistribute it and/or modify&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    it under the terms of the GNU General Public License as published by&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    the Free Software Foundation, either version 3 of the License, or&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program is distributed in the hope that it will be useful,&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    GNU General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    You should have received a copy of the GNU General Public License&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    along with this program.  If not, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Also add information on how to contact you by electronic and paper mail. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;If the program does terminal interaction, make it output a short notice like this when it starts in an interactive mode: &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    &amp;lt;program&amp;gt;  Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    This is free software, and you are welcome to redistribute it&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-size:10pt;&quot;&gt;    under certain conditions; type `show c&apos; for details. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate parts of the General Public License. Of course, your program&apos;s commands might be different; for a GUI interface, you would use an “about box”. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You should also get your employer (if you work as a programmer) or school, if any, to sign a “copyright disclaimer” for the program, if necessary. For more information on this, and how to apply and follow the GNU GPL, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The GNU General Public License does not permit incorporating your program into proprietary programs. If your program is a subroutine library, you may consider it more useful to permit linking proprietary applications with the library. If this is what you want to do, use the GNU Lesser General Public License instead of this License. But first, please read &amp;lt;http://www.gnu.org/philosophy/why-not-lgpl.htm&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The cd/dvd image manipulator for linux&lt;br /&gt;is created by:&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Current: &lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-style:italic;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Previous 2006-2009:&lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;&lt;br /&gt;Fabrizio Di Marco&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;Marco Di Antonio&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;AcetoneISO Subversion&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;xx/11/2010&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;Translators:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Italian: Original Authors&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Czech: Hanz&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Russian: Arseniy Muravyev&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Polish: Jarek&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Romanian: Aparaschivei Florin&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Hungarian: Sandor Lisovszki&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;German: Johannes Obermayr&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;Special Thanks goes to:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All the people that made a donation!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All package mantainers.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All people that submitted bug-reports, patches and suggestions.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Irc #qt channel on irc.freenode.net for all their help on C++ and Qt4&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Trolltech for releasing such a wonderful framework, Qt4!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;All the open source tools AcetoneISO uses, this includes: fuseiso, mencoder, mplayer, mencoder, dd, cdrdao, wodim, growisofs, youtube-dl, 7z, ffmpeg, gnupg, dvd+r-format and more!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;And finally... a big thanks goes to You for using our software!&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt;&quot;&gt;Thanks to all of You,&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:600;&quot;&gt;The AcetoneISO Team&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>acetoneiso</name>
    <message>
        <source>mount</source>
        <translation type="unfinished">monta</translation>
    </message>
    <message>
        <source>Double click an image to browse</source>
        <translation type="obsolete">doppio click su un&apos;immagine per aprirla nel file manager</translation>
    </message>
    <message>
        <source>Click to mount an ISO MDF NRG BIN IMG image</source>
        <translation type="obsolete">Clicca per montare una ISO MDF NRG BIM IMG</translation>
    </message>
    <message>
        <source>Click a mounted iso on the Display and then unmount</source>
        <translation type="obsolete">Clicca un&apos;immagine montata sul display e dopo smonta</translation>
    </message>
    <message>
        <source>unmount</source>
        <translation type="unfinished">smonta</translation>
    </message>
    <message>
        <source>please make a small donation for development!</source>
        <translation type="obsolete">fai una piccola donazione per lo sviluppo!</translation>
    </message>
    <message>
        <source>Double click to mount image</source>
        <translation type="obsolete">Doppio click per montare un&apos;immagine</translation>
    </message>
    <message>
        <source>set database</source>
        <translation type="obsolete">imposta database</translation>
    </message>
    <message>
        <source>Click an image on the DB and then &quot;delete image&quot;</source>
        <translation type="obsolete">Clicca un&apos;immagine sul Database e poi &quot;cancella immagine&quot;</translation>
    </message>
    <message>
        <source>delete image</source>
        <translation type="obsolete">cancella immagine</translation>
    </message>
    <message>
        <source>Click here to update  your Database</source>
        <translation type="obsolete">Clicca qui per aggiornare il tuo Database</translation>
    </message>
    <message>
        <source>update DB</source>
        <translation type="obsolete">aggiorna database</translation>
    </message>
    <message>
        <source>play</source>
        <translation type="obsolete">riproduci</translation>
    </message>
    <message>
        <source>Click to save the dvd cover</source>
        <translation type="obsolete">Clicca per salvare la copertina del dvd</translation>
    </message>
    <message>
        <source>play your DVD image of a film</source>
        <translation type="obsolete">riproduci l&apos;immagine del tuo film DVD</translation>
    </message>
    <message>
        <source>Play DVD-Movie ISO</source>
        <translation type="obsolete">riproduci DVD-Film ISO</translation>
    </message>
    <message>
        <source>umount DVD-Movie</source>
        <translation type="obsolete">smonta DVD-Film</translation>
    </message>
    <message>
        <source>Utilities</source>
        <translation type="obsolete">Utilità</translation>
    </message>
    <message>
        <source>Split Image</source>
        <translation type="obsolete">Dividi immagine in più parti</translation>
    </message>
    <message>
        <source>Encrypt Image</source>
        <translation type="unfinished">Critta Immagine</translation>
    </message>
    <message>
        <source>Mount in a specified folder</source>
        <translation type="unfinished">Monta in una cartella specifica</translation>
    </message>
    <message>
        <source>Compress Image</source>
        <translation type="unfinished">Comprimi Immagine</translation>
    </message>
    <message>
        <source>help</source>
        <translation type="obsolete">Aiuto</translation>
    </message>
    <message>
        <source>El Torito</source>
        <translation type="obsolete">El Torito</translation>
    </message>
    <message>
        <source>Conversion</source>
        <translation type="obsolete">Conversioni</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Esci</translation>
    </message>
    <message>
        <source>Set Database</source>
        <translation type="unfinished">imposta Database</translation>
    </message>
    <message>
        <source>Manual Umount</source>
        <translation type="unfinished">Smontaggio Manuale</translation>
    </message>
    <message>
        <source>Image Info</source>
        <translation type="unfinished">Informazione Immagine</translation>
    </message>
    <message>
        <source>Extract Boot Image</source>
        <translation type="unfinished">Estrai Boot file dall&apos;immagine</translation>
    </message>
    <message>
        <source>Generate to file</source>
        <translation type="unfinished">Genera in un file</translation>
    </message>
    <message>
        <source>Check</source>
        <translation type="unfinished">Visualizza</translation>
    </message>
    <message>
        <source>DOS Boot</source>
        <translation type="unfinished">DOS Boot</translation>
    </message>
    <message>
        <source>Generic Floppy-Emulation</source>
        <translation type="unfinished">Emulazione-Floppy Generica</translation>
    </message>
    <message>
        <source>Generic No-Emulation</source>
        <translation type="unfinished">Nessuna-Emulazione Generica</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="unfinished">Manuale</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished">Informazioni su AcetoneISO</translation>
    </message>
    <message>
        <source>umount</source>
        <translation type="unfinished">smonta</translation>
    </message>
    <message>
        <source>To CD</source>
        <translation type="unfinished">su CD</translation>
    </message>
    <message>
        <source>To DvD</source>
        <translation type="unfinished">su DVD</translation>
    </message>
    <message>
        <source>Convert MacOs Image</source>
        <translation type="unfinished">Converti immagine MacOS</translation>
    </message>
    <message>
        <source>MS-DOS Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert Image to ISO</source>
        <translation type="unfinished">Converti immagine a ISO</translation>
    </message>
    <message>
        <source>Generate ISO from CD/DVD</source>
        <translation type="obsolete">Genera un&apos;ISO da CD/DVD</translation>
    </message>
    <message>
        <source>Generate ISO from folder</source>
        <translation type="unfinished">Genera l&apos;ISO di una cartella</translation>
    </message>
    <message>
        <source>Rip a PSX1 game for epsxe/psx emulators</source>
        <translation type="unfinished">Converti un gioco PSX1 per emulatori epsxe/psx</translation>
    </message>
    <message>
        <source>Split</source>
        <translation type="unfinished">Dividi</translation>
    </message>
    <message>
        <source>Merge Splitted Image</source>
        <translation type="unfinished">Unisci immagine divisa</translation>
    </message>
    <message>
        <source>Encrypt</source>
        <translation type="unfinished">Critta</translation>
    </message>
    <message>
        <source>Decrypt</source>
        <translation type="unfinished">Decritta</translation>
    </message>
    <message>
        <source>Mount</source>
        <translation type="unfinished">Monta</translation>
    </message>
    <message>
        <source>Unmount</source>
        <translation type="unfinished">Smonta</translation>
    </message>
    <message>
        <source>Extract Image Content to a folder</source>
        <translation type="unfinished">Estrai il contenuto di un&apos;immagine dentro una cartella</translation>
    </message>
    <message>
        <source>Backup CD-Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compress</source>
        <translation type="unfinished">Comprimi</translation>
    </message>
    <message>
        <source>Uncompress</source>
        <translation type="unfinished">Decomprimi</translation>
    </message>
    <message>
        <source>Generate Cue for BIN/IMG images</source>
        <translation type="unfinished">Genera CUE per immagini BIN/IMG</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Opzioni</translation>
    </message>
    <message>
        <source>Please note this utility will generate a BIN image which could not be mounted or read in any way . 
However You can burn it later with AcetoneISO2 using Burn TOC utility(to be implemented in a future release) .</source>
        <translation type="obsolete">Sappiate che questa utilità genererà un&apos;immagine BIN che non potrà essere montato o letto in nessun modo. 
Tuttavia, potrai masterizzarlo AcetoneISO2 quando verrà implementato.
Al momento potrai masterizzarlo da terminale cn il comando cdrdao .</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save BIN Audio file</source>
        <translation type="obsolete">AcetoneISO2:: Salva BIN Audio file</translation>
    </message>
    <message>
        <source>Images (*.bin)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no cdrdao found in /usr/bin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to compress</source>
        <translation type="obsolete">AcetoneISO2::Selezione l&apos;immagine da comprimere</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Compressed Image</source>
        <translation type="obsolete">AcetoneiSO2:Salva immagine compressa</translation>
    </message>
    <message>
        <source>Images (*.7z)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do You want to compress in Ultra High mode? (very slow)</source>
        <translation type="unfinished">Vuoi comprimere in modalità Ultra?</translation>
    </message>
    <message>
        <source>no 7z found in /usr/bin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation type="unfinished">Apri immagine</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save ISO file</source>
        <translation type="obsolete">AcetoneISO2::Salva file ISO</translation>
    </message>
    <message>
        <source>Images (*.iso)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Database Folder</source>
        <translation type="obsolete">AcetoneISO2::Seleziona la cartella del Database</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to decrypt</source>
        <translation type="obsolete">AcetoneISO2::Seleziona l&apos;immagine da decrittare</translation>
    </message>
    <message>
        <source>Encrypted Image ( *.gpg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to donate go here: http://www.acetoneiso.netsons.org/viewpage.php?page_id=10</source>
        <translation type="obsolete">per donare andate qui :  http://www.acetoneiso.netsons.org/viewpage.php?page_id=10</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder to transform in a bootable ISO</source>
        <translation type="obsolete">AcetoneISO2::Selezione la cartella che verrà trasformata in una ISO Avviabile(boot)</translation>
    </message>
    <message>
        <source>Select Boot File</source>
        <translation type="obsolete">Seleziona file di Boot</translation>
    </message>
    <message>
        <source>Select Boot File Type:</source>
        <translation type="obsolete">Seleziona il tipo di Boot:</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image to encrypt</source>
        <translation type="obsolete">AcetoneISO2::Seleziona immagine da crittare</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO2::Select where to extract image</source>
        <translation type="obsolete">AcetoneISO2::Seleziona dove estrarre l&apos;immagine</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder to be Converted</source>
        <translation type="obsolete">AcetoneISO2::Seleziona la cartella da convertire</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save ISO</source>
        <translation type="obsolete">AcetoneISO2::Salva ISO</translation>
    </message>
    <message>
        <source>ISO ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert an ID for the ISO</source>
        <translation type="unfinished">Inserisci un ID per l&apos;ISO</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select *bin or *img</source>
        <translation type="obsolete">AcetoneISO2::Seleziona BIN o IMG</translation>
    </message>
    <message>
        <source>Image Files (*.bin *.img)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select from where to extract Boot Image:</source>
        <translation type="unfinished">Seleziona da dove estrarre l&apos;immagine di Boot</translation>
    </message>
    <message>
        <source>ISO File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CD/DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO2::Save boot image</source>
        <translation type="unfinished">AcetoneISO2::Salva l&apos;immagine boot</translation>
    </message>
    <message>
        <source>The folder </source>
        <translation type="unfinished">La cartella</translation>
    </message>
    <message>
        <source> can&apos;t be mounted</source>
        <translation type="unfinished">non può essere montata</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select folder to unmount</source>
        <translation type="obsolete">AcetoneISO2::Seleziona la cartella da smontare</translation>
    </message>
    <message>
        <source> is not mounted!</source>
        <translation type="unfinished"> non è montata!</translation>
    </message>
    <message>
        <source>Please note that this tool only works for normal DATA CD/DVD.
 It won&apos;t work with Audio CD and Game CopyProtected cd&apos;s</source>
        <translation type="obsolete">Questa utilità funziona solo con data CD/DVD.
Non funziona con cd Audio e Videogiochi protetti.</translation>
    </message>
    <message>
        <source>Image Files (*.dmg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>for the manual go here: http://www.acetoneiso.netsons.org/viewpage.php?page_id=4</source>
        <translation type="obsolete">per il manuale andate qui:  http://www.acetoneiso.netsons.org/viewpage.php?page_id=4</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Image</source>
        <translation type="obsolete">AcetoneISO2::Selezione l&apos;immagine</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Md5 text file</source>
        <translation type="obsolete">AcetoneISO2::Salva il file di testo MD5</translation>
    </message>
    <message>
        <source>Md5 (*.md5)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Virtual Drives are busy,
Unmount some Virtual Drive first!</source>
        <translation type="unfinished">Tutte le periferiche virtuali sono occupate.
Smonta almeno una periferica!</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Parts</source>
        <translation type="obsolete">AcetoneISO2::Seleziona le parti</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save merged image</source>
        <translation type="obsolete">AcetoneISO2::Salva l&apos;immagine divisa</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Processo terminato con successo!</translation>
    </message>
    <message>
        <source>Operation succesfully finished!</source>
        <translation type="unfinished">Processo terminato con successo!</translation>
    </message>
    <message>
        <source>Error, could not mount image.

Solution:
a) did you activate fuse? go here and read part c  http://www.acetoneiso.netsons.org/viewpage.php?page_id=4
b) maybe the image is a multisector image. Try converting it under Convert tab of the main gui.</source>
        <translation type="obsolete">Errore, non è stato possibile montare l&apos;immagine.

Soluzioni:
a) assicurati di aver attivato fuse. apri il manuale sotto la voce &quot;Aiuto&quot; per capire come fare
b)probabilmente l&apos;immagine è di tipo multisettore. Anzichè montarlo, prova a convertirlo sotto la voce &quot;Conversioni&quot;</translation>
    </message>
    <message>
        <source>Operation succesfully finished!
To mount the converted file, open a terminal and run as root:
modprobe hfsplus
mount -t hfsplus -o loop &lt;converted-image.img&gt; /folder_you_want</source>
        <translation type="unfinished">Processo terminato con successo!
Per montare l&apos;immagine convertita, apri un terminale, loggati come utente root e scrivi:
modprobe hfsplus
mount -t hfsplus -o loop &lt;imamgine_convertita.img&gt; /la_cartell_che_vuoi</translation>
    </message>
    <message>
        <source>Image succesfully merged</source>
        <translation type="unfinished">L&apos;immagine è stata riunita con successo</translation>
    </message>
    <message>
        <source>Select DVD-Movie to Play</source>
        <translation type="unfinished">Seleziona il DVD-Film da riprodurre</translation>
    </message>
    <message>
        <source>DVD-Movie Image (*.iso *.bin *.img *.mdf *.nrg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> mounted</source>
        <translation type="obsolete">montato</translation>
    </message>
    <message>
        <source>Do you want to download Poweriso?
If you click yes you accept PowerISO&apos;s Freeware Licence.
Remember: this tool won&apos;t run on 64-bit Operating System. Download IAT software for such systems.</source>
        <translation type="obsolete">Vuoi scaricare Poweriso?
Cliccando su Yes accetti la licenza Freeware di Poweriso.
Ricorda: poweriso non funziona con sistemi operativi 64-bit. leggi il &quot;Manuale&quot; sotto la voce Aiuto per maggiori dettagli</translation>
    </message>
    <message>
        <source>Without Poweriso some functions will be unavailable!</source>
        <translation type="obsolete">Senza Poweriso non potrai convertire le immagini e/o estrarle ad una cartella</translation>
    </message>
    <message>
        <source>Poweriso downloaded and extracted!</source>
        <translation type="unfinished">Poweriso è stato scaricato e installato!</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save BIN file</source>
        <translation type="obsolete">AcetoneISO2::Salva BIN file</translation>
    </message>
    <message>
        <source>select an image to delete</source>
        <translation type="unfinished">seleziona un&apos;immagine da cancellare</translation>
    </message>
    <message>
        <source>Open Image to be splitted</source>
        <translation type="unfinished">Apri immmagine che deve essere divisa</translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder where the image will be splitted</source>
        <translation type="obsolete">AcetoneISO2::Seleziona la cartella dove l&apos;immagine divisa verrà salvata</translation>
    </message>
    <message>
        <source>Please insert the split number in MegaByte:</source>
        <translation type="obsolete">Inserisci il numero in MegaByte:</translation>
    </message>
    <message>
        <source>DVD-Movie </source>
        <translation type="obsolete">DVD-Film</translation>
    </message>
    <message>
        <source>select an image to unmount from the virtual-drives display</source>
        <translation type="unfinished">selezione un&apos;immagine da smontare nel display</translation>
    </message>
    <message>
        <source>Open Compressed Image</source>
        <translation type="unfinished">Apri immagine compressa</translation>
    </message>
    <message>
        <source>Image Files (*.7z)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO2::Select Folder where the uncompressed Image will be saved</source>
        <translation type="obsolete">AcetoneISO2::Seleziona la cartella dove l&apos;immagine decompressa verrà salvata</translation>
    </message>
    <message>
        <source>no 7z found in /usr/bin, please install p7zip-full package</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading GUI...</source>
        <translation type="obsolete">Caricamento GUI...</translation>
    </message>
    <message>
        <source>Loading Options...</source>
        <translation type="obsolete">Caricamento Opzioni...</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save DVD Cover</source>
        <translation type="obsolete">AcetoneISO2::Salva copertina DVD</translation>
    </message>
    <message>
        <source>Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please note this utility will generate a BIN image which could not be mounted or read in any way . 
However You can burn it later with cdrdao command from terminal.</source>
        <translation type="obsolete">Questa utilità genererà un&apos;immagine BIN che non potrà essere montato o letto in alcun modo.
Puoi tuttavia masterizzarlo da terminale con il comando cdrdao.</translation>
    </message>
    <message>
        <source>NOTE: If you want to mount an image in a root folder like /media/cdrom, please launch AcetoneISO2 as root user. </source>
        <translation type="obsolete">NOTA se vuoi montare un&apos;immagine in una cartella di sistema come /media/cdrom, per favore avvia AcetoneISO2 da utente root.</translation>
    </message>
    <message>
        <source>Error, could not mount image.

Solution:
http://acetoneiso2.svn.sourceforge.net/viewvc/*checkout*/acetoneiso2/src/manual/manual.html</source>
        <translation type="obsolete">Errore, non è stato possibile montare l&apos;immagine.
Per una rapida soluzione, consultare qui:
http://acetoneiso2.svn.sourceforge.net/viewvc/*checkout*/acetoneiso2/src/manual/manual.html</translation>
    </message>
    <message>
        <source>Do you want to download Poweriso?
If you click yes you accept PowerISO&apos;s Freeware Licence.
Remember: if you are running a 64-bit OS, you need libc6-i386 package and maybe others installed.</source>
        <translation type="obsolete">Vuoi scaricare Poweriso?
Cliccando su Yes accetti la licenza Freeware di Poweriso.
Ricorda: se stai su un sistema operativo 64-bit, avrai bisogno del pacchetto libc6-i386 installato.
E&apos; possisibile che siano necessari altri pacchetti.</translation>
    </message>
    <message>
        <source>Please Unmount the movie first</source>
        <translation type="unfinished">Per favore è necessario smontare prima il film. </translation>
    </message>
    <message>
        <source>Choose a method to play the movie.
Method 1 generally works, if it doesn&apos;t try Method 2.</source>
        <translation type="unfinished">Seleziona un metodo per visualizzare il film.
Il Metodo 1 generalmente funziona, in caso negativo provare il Metodo 2.</translation>
    </message>
    <message>
        <source>Method 1</source>
        <translation type="unfinished">Metodo 1</translation>
    </message>
    <message>
        <source>Method 2</source>
        <translation type="unfinished">Metodo 2</translation>
    </message>
    <message>
        <source>
This is error is mostly because the image you are trying to convert is already ISO-9660.
To check, open a terminal and type: file nameimage.xxx
If it is already ISO-9660, there is no need to convert it. Simply Extract it or Mount with AcetoneISO2.</source>
        <translation type="obsolete">Questo errore è quasi sicuramente dovuto al fatto che l&apos;immagine che stai montando è gia in formato ISO-9660.
Per verificarlo, apri un terminale e scrivi: file nomeimmagine.xxx
Se è gia ISO-9660, non c&apos;è alcun bisogno di convertirlo. Semplicemente Estrailo o Montalo con AcetoneISO2.</translation>
    </message>
    <message>
        <source>Mount UDF ISO</source>
        <translation type="unfinished">Monta UDF ISO</translation>
    </message>
    <message>
        <source>UDF ISO are particular images that hold files bigger than 2GB.
This utility will load the udf module and mount the ISO.
Please note that administrator password is required.</source>
        <translation type="obsolete">UDF ISO sono immagini particolari che contengono file piu grandi di 2GB.
Questa utilità caricherà il modulo udf e monterà l&apos;ISO.
Nota bene che sarà necessario conoscere la password di amministratore.</translation>
    </message>
    <message>
        <source>Rip DVD 2 Xvid</source>
        <translation type="obsolete">Crea Xvid da DVD</translation>
    </message>
    <message>
        <source>Convert generic video 2 AVI</source>
        <translation type="obsolete">Converti video generico ad AVI</translation>
    </message>
    <message>
        <source>Convert FLV 2 AVI</source>
        <translation type="unfinished">Converti FLV ad AVI</translation>
    </message>
    <message>
        <source>Please be sure the DVD disc is inserted in device and then press OK.</source>
        <translation type="unfinished">Assicurati che il disco DVD sia inserito nella periferica e dopo clicca OK.</translation>
    </message>
    <message>
        <source>Encoding Pass 1 has succesfully finished.
Pass 2 will be done now. Please choose the bitrate in the next dialog and then choose where to save the video.</source>
        <translation type="unfinished">Il Pass 1 dell&apos;encoding è terminato.
Il Pass 2 verrà ora eseguito. Scegli il bitrate nel prossimo dialogo e dopo scegli dove salvare il video.</translation>
    </message>
    <message>
        <source>Please insert Bitrate. Higher bitrate means more quality but will generate a bigger file.</source>
        <translation type="unfinished">Inserisci il Bitrate. Più grande è il bitrate maggiore sarà la qualità, tuttavia è direttamente proporzionale alla grandezza del file generato.</translation>
    </message>
    <message>
        <source>AcetoneISO2::Save Video file</source>
        <translation type="obsolete">AcetoneISO2::Salva il file video</translation>
    </message>
    <message>
        <source>Video (*.avi)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Video</source>
        <translation type="unfinished">Seleziona il Video</translation>
    </message>
    <message>
        <source>Please insert the Fixed Quant number.
Lowering the number will result in a higher quality video.</source>
        <translation type="unfinished">Inserisci il numero Quant.
Più basso è il numero e più alta sarà la qualità del video.</translation>
    </message>
    <message>
        <source>Convert generic video 2 Xvid AVI</source>
        <translation type="unfinished">Converti video generico ad Xvid AVI</translation>
    </message>
    <message>
        <source>Rip DVD 2 Xvid AVI</source>
        <translation type="unfinished">Converti DVD ad Xvid AVI</translation>
    </message>
    <message>
        <source>Select FLV Video</source>
        <translation type="unfinished">Seleziona FLV Video</translation>
    </message>
    <message>
        <source>Video Files (*.flv )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error has occured.
Please try converting the FLV video with Convert generic video to Xvid AVI feature</source>
        <translation type="unfinished">Si è verificato un errore.
Prova a convertire il video FLV con l&apos;utilità Converti video generic ad Xvid AVI.</translation>
    </message>
    <message>
        <source>YouTube Download Video</source>
        <translation type="unfinished">YouTube Scarica Video</translation>
    </message>
    <message>
        <source>Insert YouTube&apos;s URL:
Note: YouTube&apos;s server is often very slow, big files can require a lot of time to download!</source>
        <translation type="unfinished">Inserisci l&apos;URL video di YouTube:
Nota: I server Youtube sono spesso molto lenti, grandi video possono richiedere molto tempo per lo scaricamento!</translation>
    </message>
    <message>
        <source>Video (*.flv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred while unmounting.
The image has been unmounted but you must close and reopen AcetoneISO2 to mount a new image.</source>
        <translation type="obsolete">Si è verificato un errore durante lo smontaggio dell&apos;immagine.
L&apos;immagine è stata comunque smontata, ma è necessario che riavvi AcetoneISO2 per montare di nuovo.</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Utilities</source>
        <translation type="unfinished">&amp;Utilità</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Aiuto</translation>
    </message>
    <message>
        <source>Generate ISO from CD/DVD and it is:</source>
        <translation type="unfinished">Crea l&apos;ISO di un supporto CD/DVD di tipo:</translation>
    </message>
    <message>
        <source>Play DVD image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O&amp;ptions</source>
        <translation type="unfinished">Opzioni</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Donate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Anonymous Login</source>
        <translation type="unfinished">Accesso anonimo</translation>
    </message>
    <message>
        <source>User Account Login</source>
        <translation type="unfinished">Accesso utente registrato</translation>
    </message>
    <message>
        <source>Burn CUE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burn TOC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a normal CD/DVD data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a CD Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a protected PC Game CD/DVD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a standard data CD/DVD</source>
        <translation type="unfinished">un normale CD/DVD dati</translation>
    </message>
    <message>
        <source>a CD Audio</source>
        <translation type="unfinished">un CD Audio</translation>
    </message>
    <message>
        <source>a Playstation 1 Game</source>
        <translation type="unfinished">un gioco Playstation 1</translation>
    </message>
    <message>
        <source>a protected PC Game CD/DVD</source>
        <translation type="unfinished">un videogioco PC/DVD protetto</translation>
    </message>
    <message>
        <source>a DVD Video</source>
        <translation type="unfinished">un DVD video</translation>
    </message>
    <message>
        <source>Copy a DVD Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy a Playstation 1 Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please specify your CD/DVD devide. If you aren&apos;t sure just leave default.
Typical devices are:
/dev/cdrom or /dev/cdrom0 or /dev/cdrom1 or /dev/dvd and follow this symbolism.</source>
        <translation type="obsolete">Per favore specifica la tua periferica CD/DVD. Se non sei sicuro lascia settaggio predefinito.
Generalmente le periferiche sono:
/dev/cdrom or /dev/cdrom0 or /dev/cdrom1 or /dev/dvd e via dicendo.</translation>
    </message>
    <message>
        <source>
Did you insert correct CD/DVD device?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Without Poweriso you won&apos;t be able to convert and extract images to ISO or folders!</source>
        <translation type="unfinished">Senza poweriso non potrai convertire le immagini e/o estrarne i contenuti.</translation>
    </message>
    <message>
        <source>
Please see the log file in   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are about to delete </source>
        <translation type="unfinished">Stai per cancellare </translation>
    </message>
    <message>
        <source>
Are You sure?</source>
        <translation type="unfinished">Sei sicuro?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Si</translation>
    </message>
    <message>
        <source>No way!</source>
        <translation type="unfinished">No!</translation>
    </message>
    <message>
        <source>no genisoimage found in /usr/bin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The image </source>
        <translation type="unfinished">L&apos;immagine </translation>
    </message>
    <message>
        <source> can&apos;t be mounted. You must convert it to ISO or extract content to a folder.
Please choose what to do:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Convert to ISO </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Extract image to a folder </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the Byte Size.
Leaving default is the best solution!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert your YouTube&apos;s username</source>
        <translation type="unfinished">Inserisci il tuo username di Youtube</translation>
    </message>
    <message>
        <source>your username</source>
        <translation type="unfinished">il tuo username</translation>
    </message>
    <message>
        <source>Please insert your YouTube&apos;s password</source>
        <translation type="unfinished">Inserisci la password del tuo account Youtube</translation>
    </message>
    <message>
        <source>Select a format type:
Fast method is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the erasing speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to unmount the CD/DVD device.
Be sure there is no process that is locking the device.
Please click on Cancel button in the next dialog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This utility will not do a 1:1 copy of your game! It will simply skip copyprotection errors.
You will need a no-cd fix cd/dvd to make the game work also known as crack.
Note: if the game is very old and uses a mixed data/audio file system, this utility won&apos;t work. Sorry :(</source>
        <translation type="unfinished">Questa utilità non farà una copia 1:1 del gioco! Semplicemente si limiterà a saltare gli errori (i file di protezione).
Ti servirà un no-cd fix per far funzionare il gioco successivamente, a volte conosciuto come crack.
Nota: se il gioco è piuttusto datato e usa un file system di tipo dati/audio, questa utilità non funzionerà :(</translation>
    </message>
    <message>
        <source>Please specify your CD/DVD mount point. If you aren&apos;t sure just leave default.
Typical mount points are:
/media/cdrom or /media/cdrom0 or /media/cdrom1 and follow this symbolism.</source>
        <translation type="unfinished">Specifica il punto di montaggio del tuo CD/DVD. Lascia default in caso di incertezza.
Punti di montaggio tipici sono:/media/cdrom or /media/cdrom0 or /media/cdrom1 e via dicendo.</translation>
    </message>
    <message>
        <source>AcetoneISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Real time updates from the net</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>http://www.acetoneteam.org/clients.html</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Double click an image to open in file manager</source>
        <translation type="obsolete">Doppio click su un&apos;immagine per aprirla nel file manager.</translation>
    </message>
    <message>
        <source>Click to mount an image</source>
        <translation type="unfinished">Clicca per montare un&apos;immagine</translation>
    </message>
    <message>
        <source>Click a mounted image on the display to unmount it</source>
        <translation type="unfinished">Clicca un immagine montata dal displayer per smontarla</translation>
    </message>
    <message>
        <source>&amp;Image Conversion</source>
        <translation type="unfinished">&amp;Conversione Immagini</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Archive Manager</source>
        <translation type="obsolete">Manager Archivi</translation>
    </message>
    <message>
        <source>Split Image in Volumes</source>
        <translation type="unfinished">Dividi l&apos;immagine in più parti</translation>
    </message>
    <message>
        <source>database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>search:</source>
        <translation type="unfinished">cerca:</translation>
    </message>
    <message>
        <source>type a letter/s to filter the search</source>
        <translation type="unfinished">Inserisci una o più lettere per filtrare la ricerca</translation>
    </message>
    <message>
        <source>Double click to mount. Right click for context menu</source>
        <translation type="unfinished">Doppio click per montare. Click destro per maggiori funzionalità</translation>
    </message>
    <message>
        <source>select an image on display to delete</source>
        <translation type="unfinished">Seleziona una immagine nel display del database per cancellarla</translation>
    </message>
    <message>
        <source>Click to update  database&apos;s display</source>
        <translation type="unfinished">Clicca per aggiornare il display del database</translation>
    </message>
    <message>
        <source>PornoTube Download Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaCafe Download Video</source>
        <translation type="unfinished">MetaCafe Scarica Video</translation>
    </message>
    <message>
        <source>Rip CD Audio 2 MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert WMA 2 MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Convert WAV 2 MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract</source>
        <translation type="unfinished">Estrai</translation>
    </message>
    <message>
        <source>Extract a RAR password protected</source>
        <translation type="unfinished">Estrai un RAR protetto da password</translation>
    </message>
    <message>
        <source>ISO 2 CSO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CSO 2 ISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract Audio from a Video file</source>
        <translation type="unfinished">Estrai l&apos;audio da un file Video</translation>
    </message>
    <message>
        <source>AcetoneISO::Insert cd/dvd device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save BIN Audio file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to compress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.gpg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save Compressed Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder where the uncompressed Image will be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open RAR password protected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RAR File (*.rar *.rev *.r00)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Insert password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the password of the RAR archive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder where the uncompressed RAR will be extracted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>no unrar-nonfree found in /usr/bin. Please install unrar-nonfree package.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note:
ISO-9660 filesystem does not support multisector images, this means you will loose all sectors above first sector.</source>
        <translation type="obsolete">ISO-9660 filesystem non supporta dati scritti in multitraccia, questo significa che perderai ogni settore successivo al primo.
Generalmente il primo settore contiene i dati veri e propri. In caso di giochi protetti in formato MDF/BIN/IMG, quasi sicuramente perderai informazioni quali protezioni.</translation>
    </message>
    <message>
        <source>AcetoneISO::Save ISO file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It is highly recommended to use &quot;Extract to folder&quot; feature.
This is because the converted ISO image is not a true ISO-9660 filesystem and requires to be mounted from terminal. A loaded hfsplus module is also needed.
Extracting the image contents to a folder is way easier and faster, and if you need you can always convert the folder to ISO in a second moment with AcetoneISO!
Choose what to do:  </source>
        <translation type="unfinished">È altamente consigliato di usare la funzione &quot;Estrai immagine in una cartella&quot;.
Se lo converti ad ISO sarai costretto a montarlo successivamente da terminale con il modulo hfsplus caricato in quanto l&apos;immagine generato non è un vero e proprio ISO-9660.
Ti suggeriamo pertanto di estrarlo in una cartella in quanto è il metodo più veloce e funzionale. Se successivamente vuoi averlo come ISO puoi semplicemente convertire la cartella in ISO sempre con AcetoneISO!
Seleziona la tua scelta:</translation>
    </message>
    <message>
        <source> Extract to folder (best solution) </source>
        <translation type="unfinished">Estrai in una cartella (scelta consigliata)</translation>
    </message>
    <message>
        <source> Convert to ISO (worst solution) </source>
        <translation type="unfinished">Converti ad ISO (altamente sconsigliato)</translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to extract image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to download Poweriso?
If you click yes you accept PowerISO&apos;s Freeware(proprietary but gratis) License.
Remember: if you are running a 64-bit OS, you need ia32-libs package installed and maybe others.</source>
        <translation type="unfinished">Vuoi scaricare Poweriso?
Se clicchi su sì, stai accettando la licenza Freeware(proprietaria ma gratuita) di Poweriso.
Ricorda: se sei in un OS a 64bit, dovrai avere installato il pacchetto ia32-libs affinchè Poweriso funzioni.</translation>
    </message>
    <message>
        <source>to donate go here: http://www.acetoneteam.org/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image to decrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Folder to be Converted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save ISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This tool doesn&apos;t do anything special.
It will only create a file with the following lines referred to the BIN/IMG you select:
FILE  + $image_file + BINARY
TRACK 01 MODE1/2352
INDEX 01 00:00:00
note: it doesn&apos;t make sense to use this feature with multisector images.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select *bin or *img</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NOTE: If you want to mount an image in a root folder like /media/cdrom, please launch AcetoneISO as root user. </source>
        <translation type="unfinished">NOTA: Se vuoi montare un&apos;immagine in una cartella root come /media/cdrom, per favore avvia AcetoneISO da utente root.</translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to mount image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select folder to unmount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Inser cd/dvd device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Byte Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save Md5 text file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Operation succesfully finished!
Find the file in </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occurred while unmounting.
The image has been unmounted but it is highly recommended to close and reopen AcetoneISO to mount a new image.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error, could not mount image.

Solution:
Try converting the image to ISO or extract the content to a folder from the upper menu &quot;Image Conversion.&quot;
NOTE: it is NOT possible to mount multi-sector images.
For more information, please visit official website: http://www.acetoneteam.org</source>
        <translation type="unfinished">Errore, impossibile montare l&apos;immagine.Soluzione:Prova a convertire l&apos;immagine ad ISO oppure ad estrarre il contenuto in una cartella dal menu superiore &quot;Conversione Immagini&quot;. NOTA: non è possibile montare immagini multisettore. Per maggiori informazioni, visita il sito: http://www.acetoneteam.org</translation>
    </message>
    <message>
        <source>AcetoneISO::Save BIN file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg *.gpg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Insert volume name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Split number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please insert the volume number in MegaByte:</source>
        <translation type="unfinished">Inserisci in MegaByte la dimensione dei volumi:</translation>
    </message>
    <message>
        <source>Select first volume part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7Z 001 (*.001)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to be done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save Video file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Fixed Quant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::MetaCafe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert MetaCafe&apos;s URL:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>We highly recommend to NOT erase a DVD.
AcetoneISO can simply overwrite existing data so there is no need to erase it.
Also remember that erasing a lot of times a dvd will damage the media.
Do You want to continue anyways?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Erase Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select WMA Audio File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio WMA (*.wma)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save MP3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio MP3 (*.mp3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select where to Save ripped CD-Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Video File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Save WAV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio WAV (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Select Wav File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WAV (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AcetoneISO::Insert cd/dvd mount point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>delete</source>
        <translation type="unfinished">elimina</translation>
    </message>
    <message>
        <source>extract</source>
        <translation type="unfinished">estrai</translation>
    </message>
    <message>
        <source>Please note this utility will generate a BIN image which could not be mounted or read in any way.
However You can burn it later with cdrdao command, generally &quot;cdrdao $namefile.toc&quot; should work.</source>
        <translation type="obsolete">Nota bene che questa utilità genererà un&apos;immagine BIN che non potrà essere montata o letta in alcun modo.
E&apos; possibile tuttavia masterizzarlo in un secondo momento con il comando cdrdao da terminale. In genere &quot;cdrdao $nome_file.toc&quot; dovrebbe funzionare.</translation>
    </message>
    <message>
        <source>Please specify your CD/DVD device. If you aren&apos;t sure just leave default.
Typical devices are:
/dev/cdrom or /dev/cdrom0 or /dev/cdrom1 or /dev/dvd and follow this symbolism.</source>
        <translation type="unfinished">Per favore specifica la tua periferica CD/DVD. Se non sei sicuro lascia  settaggio predefinito.
Periferiche tipiche sono:
/dev/cdrom or /dev/cdrom0 or /dev/cdrom1 or /dev/dvd e via dicendo.</translation>
    </message>
    <message>
        <source>Note:
ISO-9660 filesystem does not support multisector images, this means you will loose all sectors above first sector. Generally speaking, the first sector holds data file.
If it&apos;s a video game image in MDF/IMG/CCD format, you will probably loose sectors that hold copyprotection files.</source>
        <translation type="unfinished">Nota:
il filesystem ISO-9660 non supporta piu di una traccia, questo significa che perderai tutti i settori successivi al primo.
Generalmente, il primo settore contiene i dati.
In caso si tratti di un&apos;immagine di un videogioco in formato MDF/IMG/CCD, quasi sicuramente perderai delle informazioni essenziali al suo funzionamento, quali file di protezioni, boot file e quant&apos;altro.</translation>
    </message>
    <message>
        <source>&amp;Archive Manager</source>
        <translation type="unfinished">&amp;Strumenti per Archiviare</translation>
    </message>
    <message>
        <source>Mount Images</source>
        <translation type="unfinished">Monta Immagini</translation>
    </message>
    <message>
        <source>News &amp;&amp; Updates</source>
        <translation type="obsolete">Novità e Aggiornamenti</translation>
    </message>
    <message>
        <source>Reached maximum allowed drives to mount.</source>
        <translation type="unfinished">Hai raggiunto il limite di immagini montabili</translation>
    </message>
    <message>
        <source>Unmount Image</source>
        <translation type="unfinished">Smonta Immagine</translation>
    </message>
    <message>
        <source>Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm *.mp4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video (*.mp4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Convert video for PSP™</source>
        <translation type="unfinished">Converti video per PSP™</translation>
    </message>
    <message>
        <source>You decided to unmount:
</source>
        <translation type="unfinished">Hai deciso di smontare:
</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished">
Sei sicuro?</translation>
    </message>
    <message>
        <source>Virtual Drive   Image Name   Size</source>
        <translation type="obsolete">Virtual Drive  Nome Immagine  Dimensione</translation>
    </message>
    <message>
        <source>Delete Image</source>
        <translation type="obsolete">Cancella Immagine</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation type="unfinished">Aggiorna</translation>
    </message>
    <message>
        <source>Rip CD-Audio to WAV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the first time you launch AcetoneISO software.
In the next dialog you can set your default file manager, set database and some other things.
Happy AcetoneISO usage from the team:)</source>
        <translation type="unfinished">Questa è la prima volta che avvi AcetoneISO.
Nella prossima finestra potrai impostare delle opzioni come il file manager predefinito, database e altro.
Speriamo AcetoneISO sia di tuo gradimento :)</translation>
    </message>
    <message>
        <source>AcetoneISO I love You!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> doesn&apos;t exist.
I&apos;ll remove it from database display.</source>
        <translation type="unfinished"> non esiste.
Lo rimuovo dal display del database.</translation>
    </message>
    <message>
        <source>The History display is already empty!</source>
        <translation type="unfinished">Il display Cronologia è già vuota!</translation>
    </message>
    <message>
        <source>You are about to clear the History display.
This won&apos;t delete the images from hard disk.
Clear History?</source>
        <translation type="unfinished">Stai per svuotare il display Cronologia.
Questo non cancellerà fisicamente i file dall&apos;hard disk.
Svuotare Cronologia?</translation>
    </message>
    <message>
        <source>All images that don&apos;t exist have been removed from History</source>
        <translation type="unfinished">Tutte le immagini che non esistono fisicamente sono state rimosse dalla Cronologia.</translation>
    </message>
    <message>
        <source>History:</source>
        <translation type="unfinished">Cronologia:</translation>
    </message>
    <message>
        <source>Clear History</source>
        <translation type="obsolete">Svuota Display Cronologia</translation>
    </message>
    <message>
        <source>Remove non-existant images from History</source>
        <translation type="unfinished">Rimuovi immagini fisicamente inesistenti dalla Cronologia</translation>
    </message>
    <message>
        <source>Clear History Display</source>
        <translation type="unfinished">Svuota Display Cronologia</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation type="unfinished">Ripristina</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">Esci</translation>
    </message>
    <message>
        <source>About AcetoneISO</source>
        <translation type="unfinished">Informazioni su AcetoneISO</translation>
    </message>
    <message>
        <source>Mount Image</source>
        <translation type="unfinished">Monta Immagine</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished">Esci</translation>
    </message>
    <message>
        <source>Do the action specified in the combobox</source>
        <translation type="unfinished">Esegui l&apos;azione specificata nella combobox</translation>
    </message>
    <message>
        <source>Database set to:  (flag recursive:ON)</source>
        <translation type="unfinished">Database impostato a:  (flag ricorsivo:ON)</translation>
    </message>
    <message>
        <source>Database set to:  (flag recursive:OFF)</source>
        <translation type="unfinished">Database impostato a:  (flag ricorsivo:OFF)</translation>
    </message>
    <message>
        <source>Database set to:</source>
        <translatorcomment>Database impostato a:</translatorcomment>
        <translation type="unfinished">Database impostato a:</translation>
    </message>
    <message>
        <source>All images in History fisically exist!</source>
        <translation type="unfinished">Le immagini della cronologia esistono tutte fisicamente!</translation>
    </message>
    <message>
        <source> doesn&apos;t exist.
I&apos;ll remove it from history display.</source>
        <translation type="unfinished"> non esiste.
Lo rimuovo dal display Cronologia.</translation>
    </message>
    <message>
        <source>
This will remove it from history and fisically delete it.</source>
        <translation type="unfinished">Quest&apos;azione lo rimuoverà dalla cronologia e lo cancellerà fisicamente.</translation>
    </message>
    <message>
        <source>background-color: rgb(250, 248, 255);
selection-background-color: rgb(248, 146, 255);
selection-color: rgb(82, 1, 93);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(244, 251, 255);
selection-background-color: rgb(121, 123, 255);
selection-color: rgb(1, 10, 134);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(244, 251, 255);
selection-color: rgb(197, 24, 212);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(246, 255, 248);
selection-color: rgb(19, 89, 0);
selection-background-color: rgb(147, 255, 151);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Even though the image is mounted, in the options you specified to not open a file manager.
If you want to change this behaviour, please open Options and set file manager there.</source>
        <translation type="obsolete">Anche se l&apos;immagine è montata, nelle opzioni hai impostato il file manager a nessuno.
Se vuoi cambiare questa impostazione, apri le Opzioni e configura lì il file manager.</translation>
    </message>
    <message>
        <source>open image in file manager</source>
        <translation type="unfinished">apri l&apos;immagine nel file manager</translation>
    </message>
    <message>
        <source>mount </source>
        <translation type="unfinished">monta </translation>
    </message>
    <message>
        <source>delete </source>
        <translation type="unfinished">elimina </translation>
    </message>
    <message>
        <source>extract </source>
        <translation type="unfinished">estrai </translation>
    </message>
    <message>
        <source>open </source>
        <translation type="unfinished">apri </translation>
    </message>
    <message>
        <source> in file manager</source>
        <translation type="unfinished"> nel file manager</translation>
    </message>
    <message>
        <source>unmount </source>
        <translation type="unfinished">smonta </translation>
    </message>
    <message>
        <source>Double click an image to open in file manager.
Right click for Context Menu.</source>
        <translation type="unfinished">Fai doppio click su un&apos;immagine per aprirla nel file manager.
Click destro per Context Menu.</translation>
    </message>
    <message>
        <source>Unable to find</source>
        <translation type="unfinished">Impossibile trovare</translation>
    </message>
    <message>
        <source>in /usr/bin.
Please install it and be sure it&apos;s linked to /usr/bin folder.</source>
        <translation type="unfinished">in /usr/bin.
Per favore installalo e assicurati che è linkato alla cartella /usr/bin .</translation>
    </message>
    <message>
        <source>Process Progress:</source>
        <translation type="unfinished">Progresso del processo:</translation>
    </message>
    <message>
        <source>Hides the Process Display</source>
        <translation type="unfinished">Nasconde il display del processo</translation>
    </message>
    <message>
        <source>Hide Process display</source>
        <translation type="unfinished">Nascondi display Processo</translation>
    </message>
    <message>
        <source>This display shows you the current progress of the process in action</source>
        <translation type="unfinished">Questo display ti mostra il progresso del processo attualmente in esecuzione</translation>
    </message>
    <message>
        <source>Make a small donation</source>
        <translation type="unfinished">Fai una piccola donazione</translation>
    </message>
    <message>
        <source>Image Files (*.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.cue)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg *.cue)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background-color: rgb(255, 255, 238);
selection-background-color: rgb(85, 0, 255);</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose if you want the audio to be in mp3 format or if
it should be the same of the dvd (for example dolby 5.1)</source>
        <translation type="unfinished">Seleziona se vuoi che l&apos;audio sia convertito in mp3 oppure
se vuoi mantenere l&apos;audio originale del DVD (per esempio dolby 5.1)</translation>
    </message>
    <message>
        <source>Mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original Audio</source>
        <translation type="unfinished">Audio Originale</translation>
    </message>
    <message>
        <source>Burn CD/DVD</source>
        <translation type="unfinished">Masterizza CD/DVD</translation>
    </message>
    <message>
        <source>Updates</source>
        <translation type="unfinished">Aggiornamenti</translation>
    </message>
    <message>
        <source>Unable to find wodim in /usr/bin.
Please install wodim package.</source>
        <translation type="unfinished">Impossibile trovare wodim in /usr/bin.
Install il pacchetto wodim.</translation>
    </message>
    <message>
        <source>Erase CD-RW</source>
        <translation type="unfinished">Cancella CD-RW</translation>
    </message>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation type="unfinished">Cancella DVD±RW</translation>
    </message>
    <message>
        <source>Unable to find dvd+rw-format in /usr/bin.
Please install dvd+rw-tools package.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video (*.avi *.mpg *.mpeg *.wmv *.flv *.mov *.asf *.rm *.mp4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calculate Md5-Sum</source>
        <translation type="unfinished">Calcola Md5-Sum</translation>
    </message>
    <message>
        <source>Calculate Sha-Sum</source>
        <translation type="unfinished">Calcola Sha-Sum</translation>
    </message>
    <message>
        <source>Sha1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sha256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.iso *.bin *.mdf *.nrg *.img)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sha384</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <source>Erase CD-RW or DVD±RW :</source>
        <translation type="unfinished">Cancella CD-RW o DVD±RW :</translation>
    </message>
    <message utf8="true">
        <source>Burn ISO Image to CD-R/RW or DVD±R/RW :</source>
        <translation type="obsolete">Masterizza ISO su CD-R/RW o DVD±R/RW :</translation>
    </message>
    <message>
        <source>Select where to Save the Youtube Video</source>
        <translation type="unfinished">Seleziona dove salvare il video di Youtube</translation>
    </message>
    <message>
        <source>Burn ISO image to CD-R/RW</source>
        <translation type="obsolete">Masterizza ISO su CD-R/RW</translation>
    </message>
    <message utf8="true">
        <source>Burn ISO image to DVD±R/RW</source>
        <translation type="unfinished">Masterizza ISO su DVD±R/RW</translation>
    </message>
    <message>
        <source>Unable to find growisofs in /usr/bin.
Please install growisofs package.</source>
        <translation type="unfinished">Impossibile trovare growisfs in /usr/bin
Installa il pacchetto growisofs.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Image appears to have an UDF filesystem.
To correctly mount this image, open a terminal as root user and type:</source>
        <translation type="unfinished">Questa immagine sembra avere un filesystem di tipo UDF.
Per montarla correttamente, aprire un terminale come utente root e scrivere:</translation>
    </message>
    <message>
        <source>Unable to download youtube-dl.
Please try again and be sure your internet connection is alive.
If the problem persists please contact us at acetoneiso@gmail.com .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Elimina</translation>
    </message>
    <message>
        <source>Burn Image to CD-R/RW</source>
        <translation type="obsolete">Masterizza immagine su CD-R/RW</translation>
    </message>
    <message utf8="true">
        <source>Burn Image ISO/CUE/TOC to CD-R/RW or DVD±R/RW :</source>
        <translation type="unfinished">Masterizza immagine ISO/CUE/TOC su CD-R/RW o DVD±R/RW :</translation>
    </message>
    <message>
        <source>Please note this utility will generate a TOC/BIN image which could not be mounted or read in any way.
However You can burn it later with AcetoneISO burning tools!</source>
        <translation type="unfinished">Questo strumento genererà un&apos;immagine TOC/BIN che non potrà essere montata o letta in nessun modo.
Potrai tuttavia masterizzarla in un secondo momento con le funzionalità di masterizzazione di AcetoneISO!</translation>
    </message>
    <message>
        <source>Burn ISO/TOC/CUE to CD-R/RW</source>
        <translation type="unfinished">Masterizza ISO/TOC/CUE su CD-R/RW</translation>
    </message>
</context>
<context>
    <name>burniso2cd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stato trovato alcuna periferica CD/DVD.
Se pensi che questo sia un bug ti preghiamo di informarcelo.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished">Nessuna periferica CD/DVD trovata</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="obsolete">Non è stata trovata una periferica in grado di scrivere su dischi CD-RW.
Se pensi che questo sia un bug ti preghiamo di rendercelo noto.</translation>
    </message>
    <message>
        <source>The CD-RW is getting blanked...</source>
        <translation type="obsolete">Il CD-RW si sta formattando...</translation>
    </message>
    <message>
        <source>Insert a CD-RW disc.</source>
        <translation type="obsolete">Inserisci un disco CD-RW.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-RW. Please insert a CD-RW disc.</source>
        <translation type="obsolete">Il disco non è CD-RW. Inserisci un disco CD-RW.</translation>
    </message>
    <message>
        <source>CD-RW succesfully found in device.</source>
        <translation type="obsolete">CD-RW trovato con successo.</translation>
    </message>
    <message>
        <source>You decided to blank the CD-RW.
Are you sure?</source>
        <translation type="obsolete">Hai deciso di formattare il CD-RW.
Sei sicuro?</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Processo terminato con successo!</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished">Periferica:</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation type="unfinished">Questa combobox contiene tutte le periferiche abilitate al supporto cdrom CD-RW</translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation type="unfinished">Velocità:</translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation type="obsolete">Avvia la formattazione del disco</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished">Avvia</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="unfinished">Questo espellerà il disco una volta che il processo di formattazione è terminato</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="unfinished">Espelli il disco al termine</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished">Suona notifica al termine</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished">Progresso:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="obsolete">Questo display visualizza il progresso del processo di formattazione</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-R/RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stata trovata una periferica in grado di scrivere su supporti CD/DVD.
Contattaci se pensi che questo sia un bug.</translation>
    </message>
    <message>
        <source>Insert a CD-R/RW disc.</source>
        <translation type="unfinished">Inserisci un disco CD-R/RW</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-R/RW. Please insert a CD-R/RW disc.</source>
        <translation type="unfinished">Il disco non è un CD-R/RW. Inserisci un disco CD-R/RW.</translation>
    </message>
    <message>
        <source>You inserted a CD-RW disc, however your CD/DVD device is uncapable of writing to CD-RW discs.</source>
        <translation type="unfinished">Hai inserito un disco CD-RW, tuttavia la tua periferica CD/DVD non è in grado di masterizzare dischi CD-RW.</translation>
    </message>
    <message>
        <source>The CD-R isn&apos;t empty. Please insert an empty CD-R/RW disc.</source>
        <translation type="unfinished">Il CD-R non è vuoto. Inserisci un disco CD-R/RW vuoto.</translation>
    </message>
    <message>
        <source>The CD-RW isn&apos;t empty.
Please insert an empty CD-R/RW disc or blank the CD-RW with the appropriate AcetoneISO&apos;s blanking tool.</source>
        <translation type="unfinished">Il CD-RW non è vuoto.
Inserisci un disco CD-R/RW vuoto oppure formatta il disco con l&apos;apposita funzione &quot;Formatta&quot; di AcetoneISO.</translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation type="unfinished">trovato con successo nella periferica.</translation>
    </message>
    <message>
        <source>You decided to burn the</source>
        <translation type="obsolete">Hai deciso di masterizzare il</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished">
Sei sicuro?</translation>
    </message>
    <message>
        <source>Choose writing speed. When putting high values, be sure to have a good optical medium quality.</source>
        <translation type="unfinished">Imposta la velocità di scrittura. Quando inserisci valori alti, assicurati di aver inserito un disco ottico di buona qualità.</translation>
    </message>
    <message>
        <source>Click here to browse and choose what image to burn to your optical medium</source>
        <translation type="unfinished">Clicca qui per navigare e selezionare l&apos;immagine che vuoi masterizzare.</translation>
    </message>
    <message>
        <source>Start burning your image.</source>
        <translation type="unfinished">Inizia a masterizzare la tua immagine.</translation>
    </message>
    <message>
        <source>Does a burning simulation. This means it will not do a real burn and write data on your CD-R/RW disc.</source>
        <translation type="unfinished">Esegue una scrittura di simulazione. Questo significa che nessuno dato verrà effettivamente scritto sul tuo disco CD-R/RW.</translation>
    </message>
    <message>
        <source>Simulation</source>
        <translation type="unfinished">Simulazione</translation>
    </message>
    <message>
        <source>Select Image to Burn</source>
        <translation type="unfinished">Seleziona l&apos;immagine da masterizzare</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.bin *.img)</source>
        <translation type="obsolete">File Immagini (*.iso *.bin *.img)</translation>
    </message>
    <message>
        <source>The Image you selected does not exist.</source>
        <translation type="obsolete">L&apos;immagine che hai selezionato non esiste.</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation type="unfinished"> secondi</translation>
    </message>
    <message>
        <source> minutes</source>
        <translation type="unfinished"> minuti</translation>
    </message>
    <message>
        <source>Estimated time to burn </source>
        <translation type="unfinished">Tempo stimato per masterizzare </translation>
    </message>
    <message>
        <source>Select ISO/CUE/TOC image to burn to CD-R/RW :</source>
        <translation type="unfinished">Seleziona l&apos;immagine ISO/CUE/TOC che vuoi masterizzare su CD-R/RW:</translation>
    </message>
    <message>
        <source>This display shows the progress of the burning process.</source>
        <translation type="unfinished">Questo display mostra il progresso del processo di scrittura in corso.</translation>
    </message>
    <message>
        <source>AcetoneISO is burning your image to the</source>
        <translation type="unfinished">AcetoneISO sta masterizzando la tua immagine sul</translation>
    </message>
    <message>
        <source>You decided to burn the image on the</source>
        <translation type="unfinished">Hai deciso di masterizzare la tua immagine sul</translation>
    </message>
    <message>
        <source>Burn Image to CD-R/RW</source>
        <translation type="unfinished">Masterizza immagine su CD-R/RW</translation>
    </message>
    <message>
        <source>The Image you selected is too big to fit into a CD-R/RW.</source>
        <translation type="unfinished">L&apos;immagine che hai selezionato è troppo grande per entrare in un CD-R/RW.</translation>
    </message>
    <message>
        <source>Image Files ISO/CUE/TOC (*.iso *.cue *.toc)</source>
        <translation type="unfinished">File Immagini ISO/CUE/TOC (*.iso *.cue *.toc)</translation>
    </message>
    <message>
        <source>The Image you selected is unsupported from AcetoneISO.</source>
        <translation type="unfinished">L&apos;immagine selezionata non è supportata da AcetoneISO.</translation>
    </message>
    <message>
        <source>The Image you selected does not exist.
If trying to burn a CUE/TOC image, be sure the image file is in the exact folder where the CUE/TOC file is.
Be also sure they have same name except the CUE/TOC file ending with .toc extension.</source>
        <translation type="unfinished">L&apos;immagine selezionata non esiste.
Se stai provando a masterizzare un&apos;immagine CUE/TOC, assicurati che il file immagine è situata nella stessa cartella del file CUE/TOC.
Assicurati inoltre che hanno lo stesso nome eccetto che il CUE/TOC finisca con estensione .toc .</translation>
    </message>
    <message>
        <source>Program cue2toc not found in /usr/bin
Please install cue2toc package.</source>
        <translation type="unfinished">Impossibile trovare il programma cue2toc in /usr/bin
Installa il programma cue2toc.</translation>
    </message>
    <message>
        <source>Unable to generate toc file from the cue file you selected.</source>
        <translation type="unfinished">Impossibile generare il file toc dal file cue che hai selezionato.</translation>
    </message>
</context>
<context>
    <name>burniso2dvd</name>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation type="obsolete">Cancella DVD±RW</translation>
    </message>
    <message utf8="true">
        <source>Selecting this will completely blank your DVD±RW. This is not recommended and may damage your media on if used several times</source>
        <translation type="obsolete">Questo cancellerà completamente i file sul tuo DVD±RW.
É altamente sconsigliato di usare questa funzionalità perchè a lungo andare potrebbe danneggiare il supporto.</translation>
    </message>
    <message>
        <source>Blank  the entire disk (not recommended)</source>
        <translation type="obsolete">Cancella l&apos;intero disco (non raccomandato)</translation>
    </message>
    <message>
        <source>Quick Blank</source>
        <translation type="obsolete">Cancellazione Rapida</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="obsolete">Questo espellerà il disco una volta che il processo di formattazione è terminato</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="obsolete">Espelli il disco al termine</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished">Progresso:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="unfinished">Questo display visualizza il progresso del processo di formattazione</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished">Suona notifica al termine</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished">Periferica:</translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the DVD±RW capable devices found in your system</source>
        <translation type="obsolete">Questa combobox contiene tutte le periferiche abilitate al supporto DVD±RW</translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation type="obsolete">Avvia la formattazione del disco</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished">Avvia</translation>
    </message>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stato trovato alcuna periferica CD/DVD.
Se pensi che questo sia un bug ti preghiamo di informarcelo.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished">Nessuna periferica CD/DVD trovata</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to DVD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stata trovata una periferica in grado di scrivere su dischi DVD±RW.
Se pensi che questo sia un bug ti preghiamo di rendercelo noto.</translation>
    </message>
    <message>
        <source>The</source>
        <translation type="obsolete">Il</translation>
    </message>
    <message>
        <source>is getting blanked...</source>
        <translation type="obsolete">si sta cancellando...</translation>
    </message>
    <message>
        <source>Insert a DVD</source>
        <translation type="unfinished">Inserisci un DVD</translation>
    </message>
    <message>
        <source>disc.</source>
        <translation type="unfinished">disco.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a DVD</source>
        <translation type="unfinished">Il disco non è un DVD</translation>
    </message>
    <message>
        <source>Please insert a DVD</source>
        <translation type="unfinished">Per favore inserisci un DVD</translation>
    </message>
    <message>
        <source>You inserted a </source>
        <translation type="unfinished">Hai inserito un </translation>
    </message>
    <message>
        <source>You inserted a DVD+RW disc, however your CD/DVD device is uncapable of writing to DVD+RW discs.</source>
        <translation type="obsolete">Sebbene tu abbia inserito un disco DVD+RW, la tua periferica CD/DVD non è in grado di scrivere su dischi DVD+RW.</translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation type="unfinished">trovato con successo nella periferica.</translation>
    </message>
    <message>
        <source>You decided to blank the</source>
        <translation type="obsolete">Hai deciso di formattare il</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished">
Sei sicuro?</translation>
    </message>
    <message>
        <source>is already formatted.
There is no need to format it because you can simply overwrite the media.
If you really want to blank it, choose Blank the Entire disc in the below window but we highly discourage you from doing so.
Overwriting the</source>
        <translation type="obsolete">è gia formattato.
Non c&apos;è alcun bisogno di formattarlo perchè puoi semplicemente sovrascrivere il supporto.
Se per qualche motivo sei deciso a formattarlo, seleziona Cancella l&apos;intero Disco nella finestra sottostante ma te lo sconsigliamo vivamente.
Sovrascrivere il</translation>
    </message>
    <message>
        <source>is the simplest and safest thing to do.</source>
        <translation type="obsolete">è la cosa più semplice e sicura da fare.</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Processo terminato con successo!</translation>
    </message>
    <message>
        <source> that is not Empty. Please put an empty DVD</source>
        <translation type="unfinished"> che non è vuoto. Inserisci un vuoto DVD</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation type="obsolete">Questa combobox contiene tutte le periferiche abilitate al supporto cdrom CD-RW</translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation type="unfinished">Velocità:</translation>
    </message>
    <message>
        <source>Choose writing speed. When putting high values, be sure to have a good optical medium quality.</source>
        <translation type="unfinished">Imposta la velocità di scrittura. Quando inserisci valori alti, assicurati di aver inserito un disco ottico di buona qualità.</translation>
    </message>
    <message>
        <source>Click here to browse and choose what image to burn to your optical medium</source>
        <translation type="unfinished">Clicca qui per navigare e selezionare l&apos;immagine che vuoi masterizzare.</translation>
    </message>
    <message>
        <source>Select ISO/CUE/TOC image to burn to CD-R/RW :</source>
        <translation type="obsolete">Seleziona l&apos;immagine ISO/CUE/TOC che vuoi masterizzare su CD-R/RW:</translation>
    </message>
    <message>
        <source>Start burning your image.</source>
        <translation type="unfinished">Inizia a masterizzare la tua immagine.</translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the dvd DVD±R/RW capable devices found in your system</source>
        <translation type="unfinished">Questa combobox mostra tutte le periferiche dvd con supporto DVD±R/RW trovate sul tuo sistema</translation>
    </message>
    <message utf8="true">
        <source>Select ISO image to burn to DVD±R/RW :</source>
        <translation type="unfinished">Seleziona l&apos;immagine ISO da masterizzare sul DVD±R/RW :</translation>
    </message>
    <message utf8="true">
        <source>Burn ISO to DVD±R/RW</source>
        <translation type="unfinished">Masterizza ISO su DVD±R/RW</translation>
    </message>
    <message>
        <source> disc, however your CD/DVD device is uncapable of writing to such discs.</source>
        <translation type="unfinished"> disco, ma la tua periferica CD/DVD non è in grado di scriverci sopra.</translation>
    </message>
    <message>
        <source>Select Image to Burn</source>
        <translation type="obsolete">Seleziona l&apos;immagine da masterizzare</translation>
    </message>
    <message>
        <source>Image Files (*.iso *.bin *.img)</source>
        <translation type="obsolete">File Immagini (*.iso *.bin *.img)</translation>
    </message>
    <message>
        <source>The Image you selected does not exist.</source>
        <translation type="unfinished">L&apos;immagine che hai selezionato non esiste.</translation>
    </message>
    <message>
        <source> seconds</source>
        <translation type="unfinished"> secondi</translation>
    </message>
    <message>
        <source> minutes</source>
        <translation type="unfinished"> minuti</translation>
    </message>
    <message>
        <source>Estimated time to burn </source>
        <translation type="unfinished">Tempo stimato per masterizzare </translation>
    </message>
    <message>
        <source> that is not Empty. If you continue, AcetoneISO will overwrite your disc!</source>
        <translation type="unfinished"> che non è vuoto. Se continui, AcetoneISO sovrascriverà il disco!</translation>
    </message>
    <message>
        <source>You decided to burn the image on the</source>
        <translation type="unfinished">Hai deciso di masterizzare la tua immagine sul</translation>
    </message>
    <message>
        <source>.
The disc is NOT empty so if you continue,
AcetoneISO will overwrite all your data.
Are you sure?</source>
        <translation type="unfinished">.
Il disco NON è vuoto per cui se continui,
AcetoneISO sovrascriverà tutti i tuoi dati.
Sei sicuro di voler continuare?</translation>
    </message>
    <message>
        <source>AcetoneISO is burning your image to the</source>
        <translation type="unfinished">AcetoneISO sta masterizzando la tua immagine sul</translation>
    </message>
    <message>
        <source>Select ISO Image to Burn</source>
        <translation type="unfinished">Seleziona l&apos;immagine ISO da masterizzare</translation>
    </message>
    <message>
        <source>ISO Image Files (*.iso)</source>
        <translation type="unfinished">File immagini ISO (*.iso)</translation>
    </message>
    <message>
        <source>The Image you selected is unsupported from AcetoneISO.</source>
        <translation type="unfinished">L&apos;immagine selezionata non è supportata da AcetoneISO.</translation>
    </message>
</context>
<context>
    <name>erasecd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stato trovato alcuna periferica CD/DVD.
Se pensi che questo sia un bug ti preghiamo di informarcelo.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished">Nessuna periferica CD/DVD trovata</translation>
    </message>
    <message>
        <source>The CD-RW is getting blanked...</source>
        <translation type="unfinished">Il CD-RW si sta formattando...</translation>
    </message>
    <message>
        <source>Insert a CD-RW disc.</source>
        <translation type="unfinished">Inserisci un disco CD-RW.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-RW. Please insert a CD-RW disc.</source>
        <translation type="unfinished">Il disco non è CD-RW. Inserisci un disco CD-RW.</translation>
    </message>
    <message>
        <source>CD-RW succesfully found in device.</source>
        <translation type="unfinished">CD-RW trovato con successo.</translation>
    </message>
    <message>
        <source>You decided to blank the CD-RW.
Are you sure?</source>
        <translation type="unfinished">Hai deciso di formattare il CD-RW.
Sei sicuro?</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Processo terminato con successo!</translation>
    </message>
    <message>
        <source>Erase CD</source>
        <translation type="unfinished">Formatta CD-RW</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished">Periferica:</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom capable devices found in your system</source>
        <translation type="obsolete">Questa combobox contiene tutte le periferiche abilitate al supporto cdrom</translation>
    </message>
    <message>
        <source>Selecting this will completely blank your CD-RW</source>
        <translation type="unfinished">Selezionando questo comporterà una cancellazione completa del disco CD-RW</translation>
    </message>
    <message>
        <source>Blank  the entire disk</source>
        <translation type="unfinished">Cancella l&apos;intero disco</translation>
    </message>
    <message>
        <source>This will not delete files but only PMA, TOC and the pregap</source>
        <translation type="unfinished">Questo non cancellerà tutti i file ma solo il PMA, TOC ed il pregap</translation>
    </message>
    <message>
        <source>Minimally blank the entire disk (PMA, TOC, pregap)</source>
        <translation type="unfinished">Cancellazione rapida (PMA, TOC, pregap)</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="unfinished">Questo espellerà il disco una volta che il processo di formattazione è terminato</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="unfinished">Espelli il disco al termine</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished">Progresso:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="unfinished">Questo display visualizza il progresso del processo di formattazione</translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation type="unfinished">Avvia la formattazione del disco</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished">Avvia</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stata trovata una periferica in grado di scrivere su dischi CD-RW.
Se pensi che questo sia un bug ti preghiamo di rendercelo noto.</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished">Suona notifica al termine</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom CD-RW capable devices found in your system</source>
        <translation type="unfinished">Questa combobox contiene tutte le periferiche abilitate al supporto cdrom CD-RW</translation>
    </message>
</context>
<context>
    <name>erasedvd</name>
    <message>
        <source>No CD/DVD device found.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stato trovato alcuna periferica CD/DVD.
Se pensi che questo sia un bug ti preghiamo di informarcelo.</translation>
    </message>
    <message>
        <source>No CD/DVD device found</source>
        <translation type="unfinished">Nessuna periferica CD/DVD trovata</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to CD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="obsolete">Non è stata trovata una periferica in grado di scrivere su dischi CD-RW.
Se pensi che questo sia un bug ti preghiamo di rendercelo noto.</translation>
    </message>
    <message>
        <source>The CD-RW is getting blanked...</source>
        <translation type="obsolete">Il CD-RW si sta formattando...</translation>
    </message>
    <message>
        <source>Insert a CD-RW disc.</source>
        <translation type="obsolete">Inserisci un disco CD-RW.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a CD-RW. Please insert a CD-RW disc.</source>
        <translation type="obsolete">Il disco non è CD-RW. Inserisci un disco CD-RW.</translation>
    </message>
    <message>
        <source>CD-RW succesfully found in device.</source>
        <translation type="obsolete">CD-RW trovato con successo.</translation>
    </message>
    <message>
        <source>You decided to blank the CD-RW.
Are you sure?</source>
        <translation type="obsolete">Hai deciso di formattare il CD-RW.
Sei sicuro?</translation>
    </message>
    <message>
        <source>Process Succesfully Finished!</source>
        <translation type="unfinished">Processo terminato con successo!</translation>
    </message>
    <message utf8="true">
        <source>Erase DVD±RW</source>
        <translation type="unfinished">Cancella DVD±RW</translation>
    </message>
    <message>
        <source>Device:</source>
        <translation type="unfinished">Periferica:</translation>
    </message>
    <message>
        <source>This combobox shows all the cdrom capable devices found in your system</source>
        <translation type="obsolete">Questa combobox contiene tutte le periferiche abilitate al supporto cdrom</translation>
    </message>
    <message>
        <source>Selecting this will completely blank your CD-RW</source>
        <translation type="obsolete">Selezionando questo comporterà una cancellazione completa del disco CD-RW</translation>
    </message>
    <message>
        <source>Blank  the entire disk</source>
        <translation type="obsolete">Cancella l&apos;intero disco</translation>
    </message>
    <message>
        <source>This will not delete files but only PMA, TOC and the pregap</source>
        <translation type="obsolete">Questo non cancellerà tutti i file ma solo il PMA, TOC ed il pregap</translation>
    </message>
    <message>
        <source>Minimally blank the entire disk (PMA, TOC, pregap)</source>
        <translation type="obsolete">Cancellazione rapida (PMA, TOC, pregap)</translation>
    </message>
    <message>
        <source>This will eject your disc when the blank process ends</source>
        <translation type="unfinished">Questo espellerà il disco una volta che il processo di formattazione è terminato</translation>
    </message>
    <message>
        <source>Eject the disk after doing the work</source>
        <translation type="unfinished">Espelli il disco al termine</translation>
    </message>
    <message>
        <source>Progress:</source>
        <translation type="unfinished">Progresso:</translation>
    </message>
    <message>
        <source>This display shows the progress of the blanking process</source>
        <translation type="unfinished">Questo display visualizza il progresso del processo di formattazione</translation>
    </message>
    <message>
        <source>Start blanking your disc</source>
        <translation type="unfinished">Avvia la formattazione del disco</translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished">Avvia</translation>
    </message>
    <message>
        <source>Play sound notice at end</source>
        <translation type="unfinished">Suona notifica al termine</translation>
    </message>
    <message>
        <source>No CD/DVD device found capable of writing to DVD-RW discs.
If you think this is a bug please report it.</source>
        <translation type="unfinished">Non è stata trovata una periferica in grado di scrivere su dischi DVD±RW.
Se pensi che questo sia un bug ti preghiamo di rendercelo noto.</translation>
    </message>
    <message>
        <source>Insert a DVD</source>
        <translation type="unfinished">Inserisci un DVD</translation>
    </message>
    <message>
        <source>disc.</source>
        <translation type="unfinished">disco.</translation>
    </message>
    <message>
        <source>The disc isn&apos;t a DVD</source>
        <translation type="unfinished">Il disco non è un DVD</translation>
    </message>
    <message>
        <source>Please insert a DVD</source>
        <translation type="unfinished">Per favore inserisci un DVD</translation>
    </message>
    <message>
        <source>You inserted a DVD+RW disc, however your CD/DVD device is uncapable of writing to DVD+RW discs.</source>
        <translation type="unfinished">Sebbene tu abbia inserito un disco DVD+RW, la tua periferica CD/DVD non è in grado di scrivere su dischi DVD+RW.</translation>
    </message>
    <message>
        <source>succesfully found in device.</source>
        <translation type="unfinished">trovato con successo nella periferica.</translation>
    </message>
    <message utf8="true">
        <source>This combobox shows all the DVD±RW capable devices found in your system</source>
        <translation type="unfinished">Questa combobox contiene tutte le periferiche abilitate al supporto DVD±RW</translation>
    </message>
    <message>
        <source>The</source>
        <translation type="unfinished">Il</translation>
    </message>
    <message>
        <source>is getting blanked...</source>
        <translation type="unfinished">si sta cancellando...</translation>
    </message>
    <message>
        <source>You decided to blank the</source>
        <translation type="unfinished">Hai deciso di formattare il</translation>
    </message>
    <message>
        <source>
Are you sure?</source>
        <translation type="unfinished">
Sei sicuro?</translation>
    </message>
    <message utf8="true">
        <source>Selecting this will completely blank your DVD±RW. This is not recommended and may damage your media on if used several times</source>
        <translation type="unfinished">Questo cancellerà completamente i file sul tuo DVD±RW.
É altamente sconsigliato di usare questa funzionalità perchè a lungo andare potrebbe danneggiare il supporto.</translation>
    </message>
    <message>
        <source>Blank  the entire disk (not recommended)</source>
        <translation type="unfinished">Cancella l&apos;intero disco (non raccomandato)</translation>
    </message>
    <message>
        <source>Quick Blank</source>
        <translation type="unfinished">Cancellazione Rapida</translation>
    </message>
    <message>
        <source>is already formatted.
There is no need to format it because you can simply overwrite the media.
If you really want to blank it, choose Blank the Entire disc in the below window but we highly discourage you from doing so.
Overwriting the</source>
        <translation type="unfinished">è gia formattato.
Non c&apos;è alcun bisogno di formattarlo perchè puoi semplicemente sovrascrivere il supporto.
Se per qualche motivo sei deciso a formattarlo, seleziona Cancella l&apos;intero Disco nella finestra sottostante ma te lo sconsigliamo vivamente.
Sovrascrivere il</translation>
    </message>
    <message>
        <source>is the simplest and safest thing to do.</source>
        <translation type="unfinished">è la cosa più semplice e sicura da fare.</translation>
    </message>
</context>
<context>
    <name>manual</name>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Chiudi</translation>
    </message>
    <message>
        <source>AcetoneISO::Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>options</name>
    <message>
        <source>Iso from folder</source>
        <translation type="unfinished">Iso da cartella</translation>
    </message>
    <message>
        <source>Standard Settings</source>
        <translation type="unfinished">Settaggi Standard</translation>
    </message>
    <message>
        <source>will let you add an ID to the ISO</source>
        <translation type="unfinished">permette di aggiungere un ID all&apos;ISO</translation>
    </message>
    <message>
        <source>User Settings</source>
        <translation type="unfinished">Settaggi Avanzati</translation>
    </message>
    <message>
        <source>Media player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kaffeine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vlc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>it will use kde&apos;s default file manager</source>
        <translation type="unfinished">userà il file manager predefinito di KDE</translation>
    </message>
    <message>
        <source>Kde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>it will use Nautilus file manager</source>
        <translation type="unfinished">userà Nautilus come file manager</translation>
    </message>
    <message>
        <source>Nautilus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set database root folder</source>
        <translation type="obsolete">Imposta la cartella radice del database</translation>
    </message>
    <message>
        <source>Reset options to default values.</source>
        <translation type="unfinished">Ripristina valori predefiniti.</translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation type="unfinished">Predefiniti</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished">Applica</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thunar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t Open a file manager</source>
        <translation type="unfinished">Non aprire un file manager</translation>
    </message>
    <message>
        <source>What is Database?</source>
        <translation type="unfinished">Cos&apos;è il Database?</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you activate Scan Subdirectories checkbox, avoid setting database root folder directly to your ~home folder or system folders.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Se attivi la casella Ricerca nelle sotto directory, evita di impostare la cartella radice del database alla tua ~home o cartelle di sistema.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Set database root folder:</source>
        <translation type="unfinished">Imposta cartella radice del database:</translation>
    </message>
    <message>
        <source>Scan Subdirectories (read below)</source>
        <translation type="unfinished">Ricerca nelle sotto directory (leggi sotto)</translation>
    </message>
    <message>
        <source>General Options</source>
        <translation type="unfinished">Opzioni Generali</translation>
    </message>
    <message>
        <source>Advanced Options</source>
        <translation type="unfinished">Opzioni Avanzate</translation>
    </message>
    <message>
        <source>AcetoneISO::Options</source>
        <translation type="unfinished">AcetoneISO::Opzioni</translation>
    </message>
    <message>
        <source>Enable Tray Icon (requires application restart)</source>
        <translation type="unfinished">Abilita Tray Icon (necessita riavvio dell&apos;applicazione)</translation>
    </message>
    <message>
        <source>Close in Tray Icon</source>
        <translation type="unfinished">Chiudi nella Tray Icon</translation>
    </message>
    <message>
        <source>Automatically clean History display on restart</source>
        <translation type="unfinished">Svuota automaticamente il display Cronologia al riavvio</translation>
    </message>
    <message>
        <source>Tray Icon:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History:</source>
        <translation type="unfinished">Cronologia:</translation>
    </message>
    <message>
        <source>Automatically remove non-existant images from History display on restart</source>
        <translation type="unfinished">Rimuovi automaticamente immagini inesistenti dal display Cronologia al riavvio</translation>
    </message>
    <message>
        <source>Lxde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;DejaVu Sans&apos;;&quot;&gt;If you activate Scan Subdirectories checkbox, avoid setting database root folder directly to your ~home folder or system folders.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>optionsDiag</name>
    <message>
        <source>AcetoneISO::Select Database Folder</source>
        <translation type="unfinished">Seleziona la cartella del Database</translation>
    </message>
    <message>
        <source>Database is a quick and easy feature for managing your images.
Place them all in a folder and set the Database path to it, you will see all the images in the database display.
You can quickly mount them by simply clicking on them or right click for more options.
IMPORTANT: Do not place images in subdirectories or the display won&apos;t show them.</source>
        <translation type="obsolete">Database è una strumento veloce e comodo da usare. 
Posiziona le tue immagini in una cartella e imposta la directory del database a quella directory.
Vedrai tutte le immagini all&apos;interno del display dove le potrai montare rapidamente oppure avere altre funzionalità con il click destro.
IMPORTANTE: Non posizionare le immagini in sotto cartelle altrimenti il display non le visualizzerà.</translation>
    </message>
    <message>
        <source>Database is a quick and easy feature for managing your images.
Place them all in a folder and set the Database path to it, you will see all the images in the database display.
You can quickly mount them by simply clicking on them or right click for more options.</source>
        <translation type="unfinished">Database è una strumento veloce e comodo da usare. 
Posiziona le tue immagini in una cartella e imposta la directory del database a quella directory.
Vedrai tutte le immagini all&apos;interno del display dove le potrai montare rapidamente oppure avere altre funzionalità con il click destro.</translation>
    </message>
</context>
<context>
    <name>progress</name>
    <message>
        <source>Please wait... work in progress</source>
        <translation type="unfinished">Per favore attendi... lavori in corso!</translation>
    </message>
    <message>
        <source>AcetoneISO::Progress</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
