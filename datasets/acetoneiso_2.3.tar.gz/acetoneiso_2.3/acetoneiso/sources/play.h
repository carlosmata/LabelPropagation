//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
void acetoneiso::play()
{
QFile Mtab("/etc/mtab");//dichiaro un file Mtab che sarebbe /etc/mtab
Mtab.open(QIODevice::ReadOnly);//lo apro in sola lettura
QString str1 = (Mtab.readAll());//leggo il contenuto del file mtab

   QDir Home = QDir::home();
   QFile file(Home.path() + "/.acetoneiso/acetoneiso.conf");
   file.open(QIODevice::ReadOnly);//lo apro in sola lettura
   QString strb = (leggiRigo( 2, &file ));

QDir Temp = QDir::temp();
Temp.cd("acetoneiso");
//QDir Home = QDir::home();
QDir virtual_dvd_drive( Home.path() + "/virtual-drives" + "/dvd" );

if(str1.contains( virtual_dvd_drive.path() ) )//Caso che il dvd è già montato.
{

QMessageBox::information(this, "AcetoneISO",tr("Please Unmount the movie first"));

}
else{	//Caso che il dvd non è montato.
QString isodamontare = QFileDialog::getOpenFileName(this,tr("Select DVD-Movie to Play"), Home.path() , tr("DVD-Movie Image (*.iso *.bin *.img *.mdf *.nrg)"));
if ( !isodamontare.isNull() )
	{
	QFileInfo fi( isodamontare );
	QString onlyfile = fi.fileName();
	onlyfile.chop(4);
	QString percorsovirtuale = virtual_dvd_drive.path();
	Monta( isodamontare, percorsovirtuale ); //function defined in a_mount.h
	
// chiamo subito lo scaricamento della copertina, speriamo bene!
//dvdGui( label_dvd2, onlyfile);
// decidi se usare metodo 1 o 2

QMessageBox msgBox;
msgBox.setText(tr("Choose a method to play the movie.\nMethod 1 generally works, if it doesn't try Method 2."));
QPushButton *connectButton = msgBox.addButton(tr("Method 1"), QMessageBox::ActionRole);
QPushButton *connectButton2 = msgBox.addButton(tr("Method 2"), QMessageBox::ActionRole);
msgBox.exec();
 if (msgBox.clickedButton() == connectButton) {


	 if(strb.contains("kaffeine", Qt::CaseInsensitive)) {	//Se nel radio button è selezionato kaffeine.
	    QString kaf_input(virtual_dvd_drive.path());
	    kaf_input.prepend("dvd:/");
	    KAffeine.start("kaffeine", QStringList() << kaf_input );
	    }
	 else{					
	   if(strb.contains("vlc", Qt::CaseInsensitive)) { //Se nel radio button è selezionato vlc.
	      VLc.start("vlc", QStringList() << virtual_dvd_drive.path() );
	   }
	   else {
	      	SMplayer.start("smplayer", QStringList() << virtual_dvd_drive.path() );
		
	   	}
	    }
						}
 else if (msgBox.clickedButton() == connectButton2)
{
isodamontare.prepend("dvd:/");

	 if(strb.contains("kaffeine", Qt::CaseInsensitive)) {	//Se nel radio button è selezionato kaffeine.
	
	    KAffeine.start("kaffeine", QStringList() << isodamontare );
	    }
	 else{					
	   if(strb.contains("vlc", Qt::CaseInsensitive)) { //Se nel radio button è selezionato vlc.
	      VLc.start("vlc", QStringList() << isodamontare );
	   }
	   else {
	      	SMplayer.start("smplayer", QStringList() << isodamontare );
		
	   	}
	    }
						}
     }
}
file.close();
Mtab.close();
}
 
/*void acetoneiso::dvdGui( QLabel *label, QString &string ) //questa funzione pulisce la label e ci riscrive il titolo del dvd.Infine richiama get_cover 
{
   QDir Temp = QDir::temp();
   Temp.cd("acetoneiso");
   label->clear();
   label->setText("DVD-Movie " + string + + " " + tr(" mounted"));
   QFile f1(Temp.path() + "/dvd");
   f1.open(QIODevice::WriteOnly | QIODevice::Text);
   QTextStream out(&f1);
   out << ( string );
   QTimer::singleShot(2000, this, SLOT(get_cover())); //QUI DEVO ASPETTARE CHE CREA IL FILE /TMP/ACETONEISO/DVD E POI FA COVER
}*/

void acetoneiso::unplay()
{
QDir Home = QDir::home();
QDir Temp = QDir::temp();
Temp.cd("acetoneiso");
QFile dvd_temp( Temp.path() + "/dvd" );
QFile cover( Temp.path() + "/cov.jpg" );
QDir virtual_dvd_drive( Home.path() + "/virtual-drives" + "/dvd" );
FUsermount.start("fusermount", QStringList() << "-u" << "-z" << virtual_dvd_drive.path() );
//label_dvd2->clear();
dvd_temp.remove();
cover.remove();
//label_cover->setPixmap(QPixmap(":/images/default.png"));
//button_saveCover->setVisible(false);
QFile file_xml( Temp.path() + "/xml.xml" );
file_xml.remove();
}

