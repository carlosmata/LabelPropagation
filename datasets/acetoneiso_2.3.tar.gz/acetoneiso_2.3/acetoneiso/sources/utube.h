//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.

int acetoneiso::utubedownload() {
 QDir Homeutube = QDir::home();
QFile yutubbodl(Homeutube.path() + "/.acetoneiso/youtube-dl");
yutubbodl.remove();
//system ("rm $HOME/.acetoneiso/youtube-dl > /dev/null 2>&1");
if (system ("cd $HOME/.acetoneiso/;wget http://digilander.libero.it/bulletxt/youtube-dl > /dev/null 2>&1" )  ) {
  
}
//system ("chmod 755 $HOME/.acetoneiso/youtube-dl > /dev/null 2>&1");

yutubbodl.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner | QFile::ExeGroup | QFile::ReadGroup | QFile::ReadOther | QFile::ExeOther); 
if (yutubbodl.exists()) {
  return 0;
}
else {
return 1;
}

}


void acetoneiso::utube()
{
utubedownload();

if (utubedownload() == 1) {
       QMessageBox::warning(this, "AcetoneISO",tr("Unable to download youtube-dl.\nPlease try again and be sure your internet connection is alive.\nIf the problem persists please contact us at acetoneiso@gmail.com ."));
       return;
}

QDir Homeutube = QDir::home();


bool ok;
QString text = QInputDialog::getText(this, tr("AcetoneISO::YouTube"),
                                          tr("Insert YouTube's URL:\nNote: YouTube's server is often very slow, big files can require a lot of time to download!"), QLineEdit::Normal,
                                          "www.youtube.com/", &ok);
if (ok && !text.isEmpty()) {
QDir Home = QDir::home();
QString folder = QFileDialog::getExistingDirectory(this, tr("Select where to Save the Youtube Video"),Home.path());

if (folder.isNull() ) {
return;
}
     
      QDir acetone_bin = QDir::home();
      acetone_bin.cd(".acetoneiso");
      QFile utube_file( acetone_bin.path() + "/youtube-dl");
      
	 showProgressDisplay();
	 UTube = new QProcess();
	 UTube->setReadChannel(QProcess::StandardOutput);
	 UTube->setProcessChannelMode(QProcess::MergedChannels);	
 	//connection to update the display
 	connect(UTube, SIGNAL(readyReadStandardOutput()), SLOT(updateProgressDisplay_UTube() )); 
	connect( UTube, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOututube(int, QProcess::ExitStatus))); 
	
	  QDir upath(folder);
	  QString youtube_path = upath.filePath(folder);
	  //qDebug() << youtube_path;
	 UTube->setWorkingDirectory(youtube_path);
      UTube->start( utube_file.fileName(), QStringList() << "-b" << "-t" << text   );

     
  }
}

//youtube-dl -o $HOME/vid.flv $URL

void acetoneiso::utubeuser()
{
utubedownload();
if (utubedownload() == 1) {
       QMessageBox::warning(this, "AcetoneISO",tr("Unable to download youtube-dl.\nPlease try again and be sure your internet connection is alive.\nIf the problem persists please contact us at acetoneiso@gmail.com ."));
       return;
}
QDir Homeutube = QDir::home();


bool ok;
QString text = QInputDialog::getText(this, tr("AcetoneISO::YouTube"),
               tr("Insert YouTube's URL:\nNote: YouTube's server is often very slow, big files can require a lot of time to download!"), QLineEdit::Normal,
               "www.youtube.com/", &ok);
if (ok && !text.isEmpty()) {

QDir Home = QDir::home();
QString folder = QFileDialog::getExistingDirectory(this, tr("Select where to Save the Youtube Video"),Home.path());

if (folder.isNull() ) {
return;
}

      bool okk;
      QString text2 = QInputDialog::getText(this, tr("AcetoneISO::YouTube"),
                      tr("Please insert your YouTube's username"), QLineEdit::Normal,
                      tr("your username"), &okk);
      if (okk && !text2.isEmpty()) {
         bool okkk;
         QString text3 = QInputDialog::getText(this, tr("AcetoneISO::YouTube"),
                         tr("Please insert your YouTube's password"), QLineEdit::Password, "", &okkk);
         if (okkk && !text3.isEmpty()) {
            QDir acetone_bin = QDir::home();
            acetone_bin.cd(".acetoneiso");
            QFile utube_file( acetone_bin.path() + "/youtube-dl");    
	    
	 showProgressDisplay();
	 UTube = new QProcess();
	 UTube->setReadChannel(QProcess::StandardOutput);
	 UTube->setProcessChannelMode(QProcess::MergedChannels);	
 	//connection to update the display
 	connect(UTube, SIGNAL(readyReadStandardOutput()), SLOT(updateProgressDisplay_UTube() )); 
	connect( UTube, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOututube(int, QProcess::ExitStatus)));
	  QDir upath(folder);
	  QString youtube_path = upath.filePath(folder);
	  //qDebug() << youtube_path;
	 UTube->setWorkingDirectory(youtube_path);
         UTube->start( utube_file.fileName(), QStringList()  << "-u" << text2 << "-p" << text3 << "-b" << "-t" << text  );
            
           }
       }
    
  }
}



void acetoneiso::metacafe()
{

// faccio scaricare youtube-dl ogni volta perche' si aggiorna sempre. tanto il file occupa appena 10kb e fa subito a scaricarlo
// con questa tecnica un utente che non aggiorna spesso acetoneiso è cmq abilitato a poter scaricare da youtube nel tempo.
//youtube ha l'abitudine di cambiare metodo di download piu di una volta al mese quindi questa è la soluzione piu efficiente
QDir Homeutube = QDir::home();
QFile yutubbodl(Homeutube.path() + "/.acetoneiso/metacafe-dl");
yutubbodl.remove();
//system ("rm $HOME/.acetoneiso/metacafe-dl > /dev/null 2>&1");
if (system ("cd $HOME/.acetoneiso/;wget http://www.arrakis.es/~rggi3/metacafe-dl/metacafe-dl > /dev/null 2>&1")) {
}
//system ("chmod 755 $HOME/.acetoneiso/metacafe-dl > /dev/null 2>&1");
yutubbodl.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner | QFile::ExeGroup | QFile::ReadGroup | QFile::ReadOther | QFile::ExeOther);

bool ok;
QString text = QInputDialog::getText(this, tr("AcetoneISO::MetaCafe"),
                                          tr("Insert MetaCafe's URL:\n"), QLineEdit::Normal,
                                          "http://www.metacafe.com/", &ok);
if (ok && !text.isEmpty()) {
   QDir Home = QDir::home();
   QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO::Save Video file"),
						       Home.path() + "/AcetoneISO_MetaCafe",
                                                                       tr("Video (*.flv)"));
   if ( !fileName.isNull() ) {
      QDir acetone_bin = QDir::home();
      acetone_bin.cd(".acetoneiso");
      QFile utube_file( acetone_bin.path() + "/metacafe-dl");
      QString file;
      file = fileName.append(".flv" );
      
      
      
	 showProgressDisplay();
	 UTube = new QProcess();
	 UTube->setReadChannel(QProcess::StandardOutput);
	 UTube->setProcessChannelMode(QProcess::MergedChannels);	
 	//connection to update the display
 	connect(UTube, SIGNAL(readyReadStandardOutput()), SLOT(updateProgressDisplay_UTube() )); 
	connect( UTube, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOututube(int, QProcess::ExitStatus)));       
      UTube->start( utube_file.fileName(), QStringList()  << "-o" << file << text  );
      
     }
    }
}




