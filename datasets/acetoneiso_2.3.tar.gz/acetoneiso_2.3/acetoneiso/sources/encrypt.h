//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
void acetoneiso::encrypt()
{
QDir Home = QDir::home();
QString immagine = QFileDialog::getOpenFileName(this,tr("AcetoneISO::Select Image to encrypt"), Home.path(), tr("Image Files (*.iso *.daa *.bin *.mdf *.ashdisc *.bwi *.b5i *.lcd *.img *.cdi *.cif *.p01 *.pdi *.nrg *.ncd *.pxi *.gi *.fcd *.vcd *.c2d *.dmg)"));
	if (immagine.isNull()) {
	 return; 
	}
	
disable_all_button_processes();
GPg.start("gpg2", QStringList() << "-c" << immagine );
progBarra();
	
}

void acetoneiso::decrypt()
{
QDir Home = QDir::home();

QString immagine = QFileDialog::getOpenFileName(this,tr("AcetoneISO::Select Image to decrypt"), Home.path(), tr("Encrypted Image ( *.gpg)"));
	if (immagine.isNull()) {
	 return; 
	}
	
disable_all_button_processes();
GPg.start("gpg2", QStringList() << immagine );
progBarra();
	
}
