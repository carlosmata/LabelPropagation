//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
void acetoneiso::gencue()
{
QMessageBox::warning(this, "AcetoneISO",tr("This tool doesn't do anything special.\nIt will only create a file with the following lines referred to the BIN/IMG you select:\nFILE  + $image_file + BINARY\nTRACK 01 MODE1/2352\nINDEX 01 00:00:00\nnote: it doesn't make sense to use this feature with multisector images."));
QDir Home = QDir::home();
QString image = QFileDialog::getOpenFileName(this,tr("AcetoneISO::Select *bin or *img"), Home.path() , tr("Image Files (*.bin *.img)"));
if ( image.isNull() )  {
   }
else {
 QFileInfo image_file( image );
 QString pathtoimage = ( image_file.absolutePath() );//percorso assoluto al file senza nome del file.
 QString image_name( image_file.baseName() );//nome del file senza percorso nè estensione.
 QFile f_cue( pathtoimage + "/" + image_name + ".cue" );
//qDebug() << f_cue.fileName();
 QString contenutocue( "FILE " + image_file.fileName() + " BINARY\n"
			"TRACK 01 MODE1/2352\n"
			"INDEX 01 00:00:00\n");
//qDebug() << contenutocue;
 f_cue.open(QIODevice::WriteOnly | QIODevice::Text);
 QTextStream out(&f_cue);
 out << contenutocue;
 }
}
