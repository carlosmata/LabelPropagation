//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
void acetoneiso::printOut(int, QProcess::ExitStatus)
	{
	    QMainWindow::showNormal();
	    restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = MKisofs->exitCode();
	if(valore_uscita == 0) {
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	}
	else {
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}
	pushButton_6->setEnabled(true);
	}


void acetoneiso::printOutisofromcd(int, QProcess::ExitStatus)
	{
	QMainWindow::showNormal();
	restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = DD.exitCode();
	if(valore_uscita == 0)
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}

void acetoneiso::printOutflv(int, QProcess::ExitStatus)
	{
	  QMainWindow::showNormal();
	  restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = FLv->exitCode();
	if(valore_uscita == 0) {
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	}
	else {
	QMessageBox::critical(this, "AcetoneISO",tr("An error has occured.\nPlease try converting the FLV video with Convert generic video to Xvid AVI feature") );
	}
	pushButton_6->setEnabled(true);
	}


void acetoneiso::printOutvidgen(int, QProcess::ExitStatus)
	{
	  QMainWindow::showNormal();
	  restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = VIdgen->exitCode();
	if(valore_uscita == 0) {
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	}
	else {
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}
	pushButton_6->setEnabled(true);
	}




void acetoneiso::printOutcompress(int, QProcess::ExitStatus)
	{
	    QMainWindow::showNormal();
	    restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	    pushButton_6->setEnabled(true);
	int valore_uscita = PZip.exitCode();
	if( valore_uscita == 0 )
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}


void acetoneiso::printOutuncompress(int, QProcess::ExitStatus)
	{
	    QMainWindow::showNormal();
	    restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	    pushButton_6->setEnabled(true);
	int valore_uscita = PZipuncompress.exitCode();
	if( valore_uscita == 0 )
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}


void acetoneiso::printOutcue(int, QProcess::ExitStatus)
	{
	    QMainWindow::showNormal();
	    restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = CUe.exitCode();
	if( valore_uscita == 0 )
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}


void acetoneiso::printOutsplit(int, QProcess::ExitStatus)
	{
	    QMainWindow::showNormal();
	    restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	     pushButton_6->setEnabled(true);
	int valore_uscita = SPlit.exitCode();
	if( valore_uscita == 0 )
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}


void acetoneiso::printOutgpg(int, QProcess::ExitStatus)
	{
	    QMainWindow::showNormal();
	    restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = GPg.exitCode();
	if(valore_uscita == 0)
	QMessageBox::information(this, "AcetoneISO",tr("Operation succesfully finished!\nFind the file in ") + QDir::home().path());
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}





void acetoneiso::mergeMSG(int, QProcess::ExitStatus)
	{
	 QMainWindow::showNormal();
	 restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = CAt.exitCode();
	if(valore_uscita == 0)
	QMessageBox::information(this, "AcetoneISO",tr("Image succesfully merged"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}


void acetoneiso::printOutumount(int, QProcess::ExitStatus)
	{
	status_mounted_no_boot(); 
	int valore_uscita = FUsermount.exitCode();
	if(valore_uscita == 1) {
	  status_mounted_no_boot();
	QMessageBox::critical(this, "AcetoneISO",tr("An error occurred while unmounting.\nThe image has been unmounted but it is highly recommended to close and reopen AcetoneISO to mount a new image.") );
	}
	else{
	 status_mounted_no_boot(); 
	}
	}


//messaggi


void acetoneiso::printOutfuseiso(int, QProcess::ExitStatus)
	{
	status_mounted_no_boot();
	int valore_uscita = FUse.exitCode();
	if(!valore_uscita == 0){
	  status_mounted_no_boot();
	  QMessageBox::critical (this, "AcetoneISO",tr("Error, could not mount image.\n\nSolution:\nTry converting the image to ISO or extract the content to a folder from the upper menu \"Image Conversion.\"\nNOTE: it is NOT possible to mount multi-sector images.\nFor more information, please visit official website: http://www.acetoneteam.org" ));
	}
	else{
	  status_mounted_no_boot();
	 pushButton_2->setEnabled(true);
	 actionUnmount_Image->setEnabled(true);
	}
	 
	}
	
	
void acetoneiso::printOutextractaudiofromvideo(int, QProcess::ExitStatus)
	{
	  QMainWindow::showNormal();
	  restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = extractaudiofromvideo->exitCode();
	if( valore_uscita == 0 ) {
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	}
	else {
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}
	pushButton_6->setEnabled(true);
	}


//messaggi
void acetoneiso::printOututube(int, QProcess::ExitStatus)
{
  QMainWindow::showNormal();
  restore_all_button_processes(); //riabilita tutti i bottoni disattivati
int valore_uscita = UTube->exitCode();
if(valore_uscita == 0) {
   QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
}
   else {
   QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita)  );
}
pushButton_6->setEnabled(true);
}


void acetoneiso::message_extract_finish()
{
  QMainWindow::showNormal();
  restore_all_button_processes(); //riabilita tutti i bottoni disattivati
int valore_uscita = POweriso->exitCode();
if( valore_uscita == 0 ) {
   QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
}
else {
   QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita)  );
  }
  pushButton_6->setEnabled(true);
}

void acetoneiso::printOutMACIMG(int, QProcess::ExitStatus)
{
   QMainWindow::showNormal();
  restore_all_button_processes(); //riabilita tutti i bottoni disattivati
int valore_uscita = MAcimg->exitCode();
if(valore_uscita == 0) {
   QMessageBox::information(this, "AcetoneISO",tr("Operation succesfully finished!\n"
						"To mount the converted file, open a terminal and run as root:\n"
						"modprobe hfsplus\n"
						"mount -t hfsplus -o loop <converted-image.img> /folder_you_want"));
}
else {
   QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
}
  pushButton_6->setEnabled(true);
}

void acetoneiso::printOutbackaudio(int, QProcess::ExitStatus)
	{
	   QMainWindow::showNormal();
	  restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = BAckaudio->exitCode();
	if( valore_uscita == 0 ) {
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	}
	else {
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) + tr("\nDid you insert correct CD/DVD device?") );
	}
	  pushButton_6->setEnabled(true);
	}

void acetoneiso::printOutpsx(int, QProcess::ExitStatus)
	{
	QMainWindow::showNormal();
	restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	int valore_uscita = PSxrip->exitCode(); 
	if(valore_uscita == 0) {
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	}
	else {
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) +  tr("\nDid you insert correct CD/DVD device?") );
	}
	  pushButton_6->setEnabled(true);
	}

void acetoneiso::printOutRAR(int, QProcess::ExitStatus)
	{
	    QMainWindow::showNormal();
	    restore_all_button_processes(); //riabilita tutti i bottoni disattivati
	    pushButton_6->setEnabled(true);
	int valore_uscita = RAR->exitCode();
	if(valore_uscita == 0)
	QMessageBox::information(this, "AcetoneISO",tr("Operation succesfully finished!"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) );
	}
	
	
	

