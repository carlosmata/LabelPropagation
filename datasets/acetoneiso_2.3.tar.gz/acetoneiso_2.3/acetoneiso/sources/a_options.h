//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
/*Here is the function to read the options in ~/.acetoneiso/acetoneiso.conf file*/
#include"options.h"
#include"acetoneiso.h"
//#include"../acetoneiso.h"
#include <QtGui> 
void optionsDiag::optionss()
{
  
QDir Home = QDir::home();
QFile file(Home.path() + "/.acetoneiso/acetoneiso.conf");
if( file.exists() ) {
   file.open(QIODevice::ReadOnly);//lo apro in sola lettura
   QTextStream in(&file);
   QString str1 = in.readLine();
   QString str2 = in.readLine();
   QString str3 = in.readLine();
   QString str4 = in.readLine();
   QString str5 = in.readLine();


   
  // qDebug() << str1 << str2 << str3 << str4 << str5;
   
   if(str1.contains("standard", Qt::CaseInsensitive)) {
      radioButton_5->setChecked(true);
   }
   else {
      radioButton_6->setChecked(true);
   }

   if(str2.contains("kaffeine", Qt::CaseInsensitive)) {
      radioButton_7->setChecked(true);
   }
   else {
      if(str2.contains("vlc", Qt::CaseInsensitive)) {
         radioButton_8->setChecked(true); //Caso vlc
      }
      else {
         radioButton->setChecked(true); //caso SMPlayer
      }
   }

   if(str3.contains("kde", Qt::CaseInsensitive)) {
      radioButton_9->setChecked(true);
   }
 
   if(str3.contains("gnome", Qt::CaseInsensitive)) {
      radioButton_10->setChecked(true);
     }
     
   if(str3.contains("thunar", Qt::CaseInsensitive)) {
      radioButton_2->setChecked(true);
     }     

   if(str3.contains("lxde", Qt::CaseInsensitive)) {
      radioButton_4->setChecked(true);
     }

   if(str3.contains("nofilemanager", Qt::CaseInsensitive)) {
      radioButton_3->setChecked(true);
     } 
   
   
      if(str5.contains("norecursive", Qt::CaseInsensitive)) {
      checkBox->setChecked(false);
     } 
      if(str5.contains("yesrecursive", Qt::CaseInsensitive)) {
      checkBox->setChecked(true);
     }  
   
      lineEdit->setText( str4.remove(0,5) );

file.close();
advanceoptions();
 }
   
else {
   setDefaults();
   //optionss();//funzione ricorsiva lol lol lol lol lol lol lol .....lol così le impostazioni vengono applicate appena create!!!
 }
} 



void optionsDiag::advanceoptions() {
QDir Home = QDir::home();
QFile file(Home.path() + "/.acetoneiso/acetoneiso_advanced.conf");
if( file.exists() ) {
   file.open(QIODevice::ReadOnly);//lo apro in sola lettura
   QTextStream in(&file);
   QString string = in.readAll();
   
  if(string.contains("enabletrayicon", Qt::CaseInsensitive)) {
    checkBox_2->setChecked(true);
  }
  else {
    checkBox_2->setChecked(false);
  }

  
  if(string.contains("closetrayicon", Qt::CaseInsensitive)) {
    checkBox_4->setChecked(false);
  }  
  else {
    checkBox_4->setChecked(true);
  }  
  
  if(string.contains("cleanhistory", Qt::CaseInsensitive)) {
    checkBox_5->setChecked(false);
  }
  else {
    checkBox_5->setChecked(true);
  }

  if(string.contains("removefakehistory", Qt::CaseInsensitive)) {
    checkBox_6->setChecked(true);
  }
  else {
    checkBox_6->setChecked(false);
  }

   file.close();
   
   
//controlli per disabilitare checkBox e altro   
//controllo checkbox enable tray icon
   if  (checkBox_2->isChecked()) {
     checkBox_4->setEnabled(true);
   }
   else {
    checkBox_4->setEnabled(false); 
   }
   
//controllo checkbox database ricorsivo
   if  (checkBox->isChecked()) {
     textBrowser->setEnabled(true);
   }
   else {
    textBrowser->setEnabled(false); 
   }
//controllo checkbox clean history
   if  (checkBox_5->isChecked()) {
     checkBox_6->setEnabled(false);
   }
   else {
    checkBox_6->setEnabled(true); 
   }  
   
}
else {
  setDefaultsadvanced();
 }

}





void optionsDiag::update_options()
{
QDir Home = QDir::home();
QFile file(Home.path() + "/.acetoneiso/acetoneiso.conf");
file.remove();
file.open(QIODevice::ReadWrite );


if( radioButton_5->isChecked() ) {
   QTextStream out(&file);
   out << ( "ISO_FROM_FOLDER = standard\n" );
   }
else {
   QTextStream out(&file);
   out << ( "ISO_FROM_FOLDER = user    \n" );
   }

if( radioButton_7->isChecked() ) {
   QTextStream out(&file);
   out << ( "PLAYER = kaffeine\n" );
   }
else {
      if( radioButton_8->isChecked() ) {
         QTextStream out(&file);
         out << ( "PLAYER = vlc     \n" );
         }
      else {
         QTextStream out(&file);
         out << ( "PLAYER = smplayer \n" );
         }
      }

if( radioButton_9->isChecked() ) {
   QTextStream out(&file);
   out << ( "FILE_BROWSER = kde   \n" );
   }
   
if( radioButton_10->isChecked() ) {
   QTextStream out(&file);
   out << ( "FILE_BROWSER = gnome \n" );
   }

if( radioButton_2->isChecked() ) {
   QTextStream out(&file);
   out << ( "FILE_BROWSER = thunar \n" );
   }
  
if( radioButton_4->isChecked() ) {
   QTextStream out(&file);
   out << ( "FILE_BROWSER = lxde \n" );
   }

if( radioButton_3->isChecked() ) {
   QTextStream out(&file);
   out << ( "FILE_BROWSER = nofilemanager \n" );
   }  
  


if( checkBox->isChecked() ) {
   QTextStream out(&file);
   out << "DB = " <<( lineEdit->text() ) << "\n";
   out << ( "recursive = yesrecursive" "\n" );
   }
   else {
     QTextStream out(&file);
     out << "DB = " <<( lineEdit->text() ) << "\n";
     out << ( "recursive = norecursive" "\n" );
   }

file.close();
update_options_advance();
}


void optionsDiag::update_options_advance() {
QDir Home = QDir::home();
QFile file(Home.path() + "/.acetoneiso/acetoneiso_advanced.conf");
file.remove();
file.open(QIODevice::ReadWrite );
QTextStream out(&file);
/*
   out << ( "TRAYICON = enabletrayicon\n" );
   out << ( "TRAYICON_MINIMIZE = minimizetrayicon\n" );
   out << ( "TRAYICON_CLOSE = closetrayicon\n" );
   out << ( "HISTORY_CLEAN = cleanhistory\n" );
   out << ( "HISTORY_REMOVE_FAKE = removefakehistory\n" );
*/

if(checkBox_2->isChecked() ) { 
 out << ( "TRAYICON = enabletrayicon\n" );
}
else {
out << ( "TRAYICON = notrayicon\n" );  
} 
  
if(checkBox_4->isChecked() ) { 
out << ( "TRAYICON_CLOSE = noclosetrayt\n" );
}
else {
out << ( "TRAYICON_CLOSE = closetrayicon\n" );
}   

if(checkBox_5->isChecked() ) { 
   out << ( "HISTORY_CLEAN = noclnhistory\n" );
}
else {
   out << ( "HISTORY_CLEAN = cleanhistory\n" );
} 

if(checkBox_6->isChecked() ) { 
   out << ( "HISTORY_REMOVE_FAKE = removefakehistory\n" );
}
else {
   out << ( "HISTORY_REMOVE_FAKE = noremfakehistory\n" );
} 
  
file.close();  
}







void optionsDiag::setDefaults()
{
   QDir Home = QDir::home();
   QFile file(Home.path() + "/.acetoneiso/acetoneiso.conf");
   file.open(QIODevice::WriteOnly | QIODevice::Text);
   QTextStream out(&file);
   out << ( "ISO_FROM_FOLDER = standard\n" );
   out << ( "PLAYER = kaffeine\n" );
   out << ( "FILE_BROWSER = kde\n" );
   out << ( "DB = " + Home.path() + "\n" );
   out << ( "recursive = norecursive" "\n" );
   file.close();
   setDefaultsadvanced();
   optionss();
}


void optionsDiag::setDefaultsadvanced() {
   QDir Home = QDir::home();
   QFile file(Home.path() + "/.acetoneiso/acetoneiso_advanced.conf");
   file.open(QIODevice::WriteOnly | QIODevice::Text);
   QTextStream out(&file);
   out << ( "TRAYICON = enabletrayicon\n" );
   out << ( "TRAYICON_CLOSE = closetrayicon\n" );
   out << ( "HISTORY_CLEAN = cleanhistory\n" );
   out << ( "HISTORY_REMOVE_FAKE = removefakehistory\n" );
   file.close();
   optionss();
}

void optionsDiag::getDbDir()
{
QDir Home = QDir::home();
QString folder = QFileDialog::getExistingDirectory(this, tr("AcetoneISO::Select Database Folder"),
                                                 Home.path());
if (folder.isNull() ) {
return;
}
else
{
lineEdit->setText( folder );
}
}



