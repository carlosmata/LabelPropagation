//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO2 is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO2 is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO2.  If not, see <http://www.gnu.org/licenses/>.


void acetoneiso::umountcheck()
{
/*//mi prendo i tre numeri tipo 0,1,0 che ci dice la periferica
QString device = deviceID();
if( device.isEmpty( ) ) {
QMessageBox::critical(this, "AcetoneISO2",tr("Unable to unmount the CD/DVD device.\nPlease insert an empty CD/DVD media in device.") );
}
else
{
//QMessageBox::warning(this, "AcetoneISO2::Warning!", device);
UCheck.start("umount",QStringList()   << device  );
}*/
}



void acetoneiso::printOutucheck(int, QProcess::ExitStatus)
	{
	int valore_uscita = UCheck.exitCode();
	if(valore_uscita == 1)
	QMessageBox::critical(this, "AcetoneISO2",tr("Unable to unmount the CD/DVD device.\nBe sure there is no process that is locking the device.\nPlease click on Cancel button in the next dialog.") );
	
	}



