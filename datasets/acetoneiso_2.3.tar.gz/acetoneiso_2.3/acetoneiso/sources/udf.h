//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO2 is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO2 is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO2.  If not, see <http://www.gnu.org/licenses/>.


 void acetoneiso::udf()
{

/* il modo di gestire il dialogo qt4 con il kdesu/gksu è sì una mia idea, ma il codice qui
sotto l'ho scritto grazie ad un lavoro precedente di Fabrizio Di Marco il quale 
lo ringrazio con tanto affetto!! LLOL!
*/
QMessageBox::information(this, "AcetoneISO2",tr("to be done"));


/*

OPENFILE=`cat $HOME/.acetoneiso/acetoneiso.udf` > /dev/null 2>&1
rm -rf $HOME/virtual-drives/UDF/test > /dev/null 2>&1

home2="$HOME/virtual-drives/UDF"
#echo $home2
mkdir $HOME/virtual-drives/UDF > /dev/null 2>&1

if test -e /usr/bin/kdesu
then
kdesu  "modprobe udf"
kdesu  "mount -t udf -o loop,utf8 $OPENFILE $home2"  > /dev/null 2>&1

mkdir $HOME/virtual-drives/UDF/test > /dev/null 2>&1
	if test -e $HOME/virtual-drives/UDF/test
	then
	rm -rf $HOME/virtual-drives/UDF/test
	kdialog --msgbox "Could not mount UDF ISO filesystem"
	exit
	else
	kfmclient openURL $HOME/virtual-drives/UDF > /dev/null 2>&1
	exit
	fi

else
gksu "modprobe udf"
gksu "mount -t udf -o loop,utf8 $OPENFILE $home2"  > /dev/null 2>&1
mkdir $HOME/virtual-drives/UDF/test > /dev/null 2>&1
	if test -e $HOME/virtual-drives/UDF/test
	then
	rm -rf $HOME/virtual-drives/UDF/test
	zenity --info --text="Could not mount UDF ISO filesystem"
	exit
	else
	nautilus $HOME/virtual-drives/UDF > /dev/null 2>&1
	exit
	fi

exit
fi

  #mount -t udf -o loop,utf8  /home/bullet/shrek.iso /home/bullet/virtual-drives/UDF/




*/

}

