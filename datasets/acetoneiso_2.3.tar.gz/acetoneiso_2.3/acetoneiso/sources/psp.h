//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Fabrizio Di Marco and Marco Di Antonio (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.


void acetoneiso::convertpsp() {

QDir bin("/usr/bin");
QFile rar;
QDir::setCurrent( bin.path() );
rar.setFileName("ffmpeg");
if (!rar.exists()) {  
 QMessageBox::critical(this, "AcetoneISO",tr("Unable to find") + " ffmpeg " + tr("in /usr/bin.\nPlease install it and be sure it's linked to /usr/bin folder.") );
return;
}

QDir Home = QDir::home();
QString open;
open = QFileDialog::getOpenFileName(this,tr("Select Video"), Home.path() , tr("Video Files (*.avi *.mpg *.mpeg *.mov *.wmv *.flv *.asf *.rm *.mp4)"));
if (open.isNull() ) {
 return; 
}


   QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO::Save Video file"),
						          Home.path() + "/AcetoneISO_PSP",
								       tr("Video (*.mp4)"));
   if (fileName.isNull() ) {
    return ; 
   }
     
//ffmpeg -y -i cnn.mpg -vcodec libxvid -s 320x240 -r 29.97 -b 200k -acodec libfaac -ac 2 -ar 24000 -ab 65535 -f psp -aspect 4:3 test.mp4 
         QString file;
         file = fileName.append(".mp4" );
	 
	 showProgressDisplay();   
	 VIdgen = new QProcess();
	 VIdgen->setReadChannel(QProcess::StandardOutput);
	 VIdgen->setProcessChannelMode(QProcess::MergedChannels);	
 	//connection to update the display
 	connect(VIdgen, SIGNAL(readyReadStandardOutput()), SLOT(updateProgressDisplay_vidgen() )); 
	connect( VIdgen, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutvidgen(int, QProcess::ExitStatus)));
VIdgen->start("ffmpeg",QStringList()  << "-y" << "-i" << open << "-vcodec" << "libxvid" << "-s" << "320x240" << "-r" << "29.97" << "-b" << "200k" << "-acodec" << "libfaac" << "-ac" << "2" << "-ar" << "24000" << "-ab" << "65535" << "-f" << "psp" << "-aspect" << "4:3" << file  );
        // progBarra();

  
}
