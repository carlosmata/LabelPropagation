//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
 void acetoneiso::isocd()
{
bool ok;
QString text = QInputDialog::getText(this, tr("AcetoneISO::Inser cd/dvd device"),
                                          tr("Please specify your CD/DVD device. If you aren't sure just leave default.\nTypical devices are:\n/dev/cdrom or /dev/cdrom0 or /dev/cdrom1 or /dev/dvd and follow this symbolism."), QLineEdit::Normal,
                                          "/dev/cdrom", &ok);
if (ok && !text.isEmpty()) {
   bool ok2;
   int i = QInputDialog::getInteger(this, tr("AcetoneISO::Byte Size"),tr("Please insert the Byte Size.\nLeaving default is the best solution!"), 1024, 0, 100000, 2, &ok2);
   if (!ok2) {
      return;
     }
  
      QDir Home = QDir::home();
      QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO::Save ISO"),
										Home.path() + "/AcetoneISO_data",
										tr("Images (*.iso)"));
      if ( fileName.isNull() ) {
         return;
         }
     
         fileName.append(".iso");
         fileName.prepend("of=");
         QString bsize = "bs=";
         QString block;
         block = QString::number(i).prepend(bsize);
         text.prepend("if=" );
        disable_all_button_processes();
         DD.start("dd", QStringList() << text << fileName << block );
         progBarra();
        
      
  }//chiusura primo if
}


