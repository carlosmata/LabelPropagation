//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO2 is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO2 is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO2.  If not, see <http://www.gnu.org/licenses/>.

/*
void acetoneiso::eltorito() {
QMessageBox::warning(this, "AcetoneISO",tr("This feature is untested, we can't guarantee it will work.\nSorry."));
QFile stage2_eltorito( "/usr/lib/grub/i386-pc/stage2_eltorito" );
QFile mkisofs_file( "/usr/bin/genisoimage");
	if(!mkisofs_file.exists()) {
	QMessageBox::warning(this, "AcetoneISO2::Warning!",tr("Please be sure to have genisoimage installed in /usr/bin "));
	  return;
	}
QString folder = QFileDialog::getExistingDirectory( this, tr("AcetoneISO2::Select Folder to transform in a bootable ISO"), QDir::home().path() );
		if(!folder.isNull() )
		{
	 	 QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO2::Save ISO file"),
				QDir::home().path() + "/acetone_bootable" ,
				tr("Images (*.iso)"));
		 
		 if (fileName.isNull() )
		 {
		   return;
		 }
			fileName.append( ".iso" );

 				
				 //funzione caso manual
				   QString bootfile = QFileDialog::getOpenFileName(this,tr("Select Boot File"), QDir::home().path() );
					if ( bootfile.isNull() ) {
					  return;
					}

					 QFile boot_file( bootfile );
					 QFileInfo boot_file_info( boot_file );
					 QDir directoryToConvert( folder );
					 directoryToConvert.mkdir("boot");
					 directoryToConvert.cd( "boot" );
					 directoryToConvert.mkdir( "acetoneiso" );
					 directoryToConvert.cd( "acetoneiso" );
					 boot_file.copy( folder + "boot/acetoneiso/" + boot_file_info.fileName() );
					 
showProgressDisplay();
MKisofs = new QProcess();
MKisofs->setReadChannel(QProcess::StandardOutput);
MKisofs->setProcessChannelMode(QProcess::MergedChannels);
connect(MKisofs, SIGNAL(readyReadStandardOutput()), SLOT(updateProgressDisplay_MKisofs() )); 
connect(MKisofs, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOut(int, QProcess::ExitStatus)));
MKisofs->start("genisoimage", QStringList() << "-R" << "-b" << ( "boot/acetoneiso/" + boot_file_info.fileName() ) << "-no-emul-boot" << "-boot-load-size 4" << "-boot-info-table" << "-o" << fileName << folder );
			
	        

        }
}


void acetoneiso::elfloppy()
{
QMessageBox::warning(this, "AcetoneISO",tr("This feature is untested, we can't guarantee it will work.\nSorry."));
QFile mkisofs_file( "/usr/bin/genisoimage");
	if(!mkisofs_file.exists())
	QMessageBox::warning(this, "AcetoneISO2::Warning!",tr("Please be sure to have genisoimage installed in /usr/bin "));
	else
	{
	  QString folder = QFileDialog::getExistingDirectory( this, tr("AcetoneISO2::Select Folder to transform in a bootable ISO"), QDir::home().path() );
		if(!folder.isEmpty() )
		{
		 QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO2::Save ISO file"),
				QDir::home().path() + "/acetone_bootable" ,
				tr("Images (*.iso)"));
		 
		 if (!fileName.isNull() )
		 {
			fileName.append( ".iso" );
		   QString bootfile = QFileDialog::getOpenFileName(this,tr("Select Boot File"), QDir::home().path() );
					if ( bootfile.isNull() )
					{
					}
					else
					{
					 QFile boot_file( bootfile );
					 QFileInfo boot_file_info( boot_file );
					 QDir directoryToConvert( folder );
					 directoryToConvert.mkdir("boot");
					 directoryToConvert.cd( "boot" );
					 boot_file.copy( folder + "boot/" + boot_file_info.fileName() );
					 
					  showProgressDisplay();
		  MKisofs = new QProcess();
		  MKisofs->setReadChannel(QProcess::StandardOutput);
		  MKisofs->setProcessChannelMode(QProcess::MergedChannels);
		  connect(MKisofs, SIGNAL(readyReadStandardOutput()), SLOT(updateProgressDisplay_MKisofs() )); 
		  connect(MKisofs, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOut(int, QProcess::ExitStatus)));
					 MKisofs->start("genisoimage", QStringList() << "-r" << "-b" << ( "boot/" + boot_file_info.fileName() ) << "-c" << "boot/boot.catalog" << "-o" << fileName << folder );
					
					}
		  
		 }
	  	}
	  
	}
}
*/

void acetoneiso::getboot()
{
QDir Home = QDir::home();
QMessageBox msgBox;
msgBox.setText(tr("Select from where to extract Boot Image:"));
QPushButton *connectButton = msgBox.addButton(tr("ISO File"), QMessageBox::ActionRole);
QPushButton *connectButton2 = msgBox.addButton(tr("CD/DVD"), QMessageBox::ActionRole);
//msgBox.setStandardButtons(QMessageBox::("ISO File") | QMessageBox::("CD/DVD"));
msgBox.exec();
 if (msgBox.clickedButton() == connectButton) {
	QString iso = QFileDialog::getOpenFileName(this,tr("Open Image"), Home.path() , tr("Image Files (*.iso)"));
	if ( iso.isNull() ){
	}
	else{
		QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO2::Save boot image"),Home.path() + "/A-iso_extractedBoot" );
		if (!fileName.isNull() ){
			fileName.append(".boot");
			ELtorito.start("geteltorito", QStringList() << "-o" << fileName << iso );
			progBarra();
		}		
	    } 
	}
 else if (msgBox.clickedButton() == connectButton2) {
		QDir iso("/dev/cdrom");
		QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO2::Save boot image"),Home.path() + "/A-iso_extractedBoot" );
		if (!fileName.isNull() ){
		 fileName.append(".boot");
		 ELtorito.start("geteltorito", QStringList() << "-o" << fileName << iso.path() );
		 progBarra();
		}
 }

} 



