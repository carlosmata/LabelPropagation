//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.


 void acetoneiso::formatcd()
{
umountcheck();
QDir Home = QDir::home();
QString device = deviceID();
QString devid = "dev=";
QString devicefinal = devid.append(device);

QMessageBox msgBox;
msgBox.setText(tr("Select a format type:\nFast method is recommended."));
QPushButton *connectButton = msgBox.addButton(tr("Fast"), QMessageBox::ActionRole);
QPushButton *connectButton2 = msgBox.addButton(tr("Complete"), QMessageBox::ActionRole);
QString alog( QDir::home().path() + "/.acetoneiso/acetoneiso.log" );
//file di log
QFile log( alog );
BIso.setReadChannel(QProcess::StandardOutput);//imposto il canale di lettura del processo
BIso.setStandardOutputFile( alog,   QIODevice::Truncate );//l'output di va nel file alog
//msgBox.setStandardButtons(QMessageBox::("ISO File") | QMessageBox::("CD/DVD"));
msgBox.exec();
if (msgBox.clickedButton() == connectButton) {
//sono nel caso FAST
//in attesa che l'utente possa settare il proprio masterizzatore


BIso.start("wodim",QStringList()   << devicefinal << "blank=fast"  );

progBarra();
	
	}
 else if (msgBox.clickedButton() == connectButton2) {



//in attesa che l'utente possa settare il proprio masterizzatore


			QString number;
			//number = QString::number(i);
			QString fspeed = "speed=";
			QString speed;
			//speed = fspeed.append( number );
			
	//QMessageBox::information(this, "AcetoneISO", speed);



BIso.start("wodim",QStringList()   << devicefinal  << "blank=all" );

progBarra();



	}
}



//for fast format= wodim dev=/dev/cdrw  blank=fast
//for complete format= wodim dev=/dev/cdrw  blank=all


 void acetoneiso::formatdvd()
{
QDir Home = QDir::home();
QMessageBox msgBox;
msgBox.setText(tr("We highly recommend to NOT erase a DVD.\nAcetoneISO can simply overwrite existing data so there is no need to erase it.\nAlso remember that erasing a lot of times a dvd will damage the media.\nDo You want to continue anyways?"));
QPushButton *connectButton = msgBox.addButton(tr("Yes"), QMessageBox::ActionRole);
QPushButton *connectButton2 = msgBox.addButton(tr("No"), QMessageBox::ActionRole);
//msgBox.setStandardButtons(QMessageBox::("ISO File") | QMessageBox::("CD/DVD"));
msgBox.exec();
if (msgBox.clickedButton() == connectButton) {
   umountcheck();
   bool ok;
   int i = QInputDialog::getInteger(this, tr("AcetoneISO::Erase Speed"),tr("Please insert the erasing speed:"), 4, 2, 16, 2, &ok);
	if (!ok) {
	   }
	else {
//in attesa che l'utente possa settare il proprio masterizzatore
		QString number;
		number = QString::number(i);
		QString fspeed = "speed=";
		QString speed;
		speed = fspeed.append( number );
//QMessageBox::information(this, "AcetoneISO", speed);
		QString alog( QDir::home().path() + "/.acetoneiso/acetoneiso.log" );
//file di log
		QFile log( alog );
		BIso.setReadChannel(QProcess::StandardOutput);//imposto il canale di lettura del processo
		BIso.setStandardOutputFile( alog,   QIODevice::Truncate );//l'output di va nel file alog
		BIso.start("wodim",QStringList()   << "dev=/dev/dvdrw" << speed << "-format" );
		progBarra();
	    }
   }
   else if (msgBox.clickedButton() == connectButton2) {
      }
}
//messaggi
void acetoneiso::printOutburniso(int, QProcess::ExitStatus)
	{
	int valore_uscita = BIso.exitCode();
	if(valore_uscita == 0)
	QMessageBox::information(this, "AcetoneISO",tr("Process Succesfully Finished!"));
	else
	QMessageBox::critical(this, "AcetoneISO","Process Error Code: " + QString::number(valore_uscita) + tr("\nPlease see the log file in   ") + QDir::home().path() + ("/.acetoneiso/acetoneiso.log") );
	}

