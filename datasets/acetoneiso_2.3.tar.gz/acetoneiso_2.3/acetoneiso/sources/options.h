//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
#ifndef OPTIONS_H
#define OPTIONS_H
#include <QFile>
#include <QDialog>
#include "../build/ui_options.h"
//
class optionsDiag : public QDialog, public Ui::options
{
Q_OBJECT
public:
	optionsDiag( QWidget * parent = 0, Qt::WFlags f = 0 );
private slots:
   void optionss();
   void update_options();
   void setDefaults();
   void getDbDir();
   void whatisdatabase();
   void setDefaultsadvanced();
   void advanceoptions();
   void update_options_advance();
   void clickedtrayenable(int stato);
   void recursivedb (int statodb);
   void cleanhistory(int cleanh);
};
#endif





