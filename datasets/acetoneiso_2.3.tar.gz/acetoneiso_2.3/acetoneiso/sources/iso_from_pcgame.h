//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>. 
void acetoneiso::isopcgame()
{
QMessageBox::warning(this, "AcetoneISO::Warning!",tr("This utility will not do a 1:1 copy of your game! It will simply skip copyprotection errors.\nYou will need a no-cd fix cd/dvd to make the game work also known as crack.\nNote: if the game is very old and uses a mixed data/audio file system, this utility won't work. Sorry :("));

QFile mkisofs;
mkisofs.setFileName("/usr/bin/genisoimage");

QDir Home = QDir::home();

if (mkisofs.exists()) {
   bool ok;
   QString text = QInputDialog::getText(this, tr("AcetoneISO::Insert cd/dvd mount point"),
                                          tr("Please specify your CD/DVD mount point. If you aren't sure just leave default.\nTypical mount points are:\n/media/cdrom or /media/cdrom0 or /media/cdrom1 and follow this symbolism."), QLineEdit::Normal,
                                          "/media/cdrom0", &ok);
   if (ok && !text.isEmpty()) {
      QString fileName = QFileDialog::getSaveFileName(this, tr("AcetoneISO::Save ISO"),
										Home.path() + "/AcetoneISO_PcGame",
										tr("Images (*.iso)"));
      if ( fileName.isNull() ) {
         return;
       }

         fileName.append(".iso");
	 
		  showProgressDisplay();
		  MKisofs = new QProcess();
		  MKisofs->setReadChannel(QProcess::StandardOutput);
		  MKisofs->setProcessChannelMode(QProcess::MergedChannels);
		  connect(MKisofs, SIGNAL(readyReadStandardOutput()), SLOT(updateProgressDisplay_MKisofs() )); 
		  connect(MKisofs, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOut(int, QProcess::ExitStatus)));
		  
         MKisofs->start("genisoimage",QStringList() << "-R" << "-J" << "-o" << fileName << text  );
         
       	
    }
 }
else
QMessageBox::warning(this, "AcetoneISO::Warning!",tr("no genisoimage found in /usr/bin"));
}


