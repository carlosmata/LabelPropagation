//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.



void acetoneiso::status_mounted_no_boot()
{


QDir Temp = QDir::temp();
Temp.cd("acetoneiso");
QFile f1(Temp.path() + "/1");
QFile f2(Temp.path() + "/2");
QFile f3(Temp.path() + "/3");
QFile f4(Temp.path() + "/4");
QFile f5(Temp.path() + "/5");
QFile f6(Temp.path() + "/6");
QFile f7(Temp.path() + "/7");
QFile dvd_temp(Temp.path() + "/dvd");
bool isomounted = false;
int countdrives = 0;

if (f1.exists())
{
//qDebug() << "ci sto";
countdrives = countdrives + 1;
isomounted = true;
}

if (f2.exists())
{
countdrives = countdrives + 1;
isomounted = true;
}
if (f3.exists())
{

countdrives = countdrives + 1;
isomounted = true;
}
if (f4.exists())
{

countdrives = countdrives + 1;
isomounted = true;
}
if (f5.exists())
{

countdrives = countdrives + 1;
isomounted = true;
}
if (f6.exists())
{

countdrives = countdrives + 1;
isomounted = true;
}
if (f7.exists())
{
countdrives = countdrives + 1;
isomounted = true;
}
if (dvd_temp.exists())
{

}
//qDebug() << countdrives;
if (countdrives >= 7){
pushButton->setEnabled(false);
actionMount_Image->setEnabled(false);
pushButton->setText(tr("Reached maximum allowed drives to mount.")); 
}
else{
pushButton->setEnabled(true);
actionMount_Image->setEnabled(true);
pushButton->setText(tr("Mount")); 
}


if (isomounted) {
  int size = listWidget_2->selectedItems().size();  
  if (size < 1) {
    pushButton_2->setText(tr("Unmount"));
    actionUnmount_Image->setText(tr("Unmount Image"));
     actionUnmount_Image->setEnabled(false);
    pushButton_2->setEnabled(false);
   return; 
  }  
actionUnmount_Image->setEnabled(true);  
pushButton_2->setEnabled(true);
}
else{
actionUnmount_Image->setEnabled(false);
pushButton_2->setEnabled(false);
pushButton_2->setText(tr("Unmount"));
actionUnmount_Image->setText(tr("Unmount Image"));
}

f1.close();
f2.close();
f3.close();
f4.close();
f5.close();
f6.close();
f7.close();
dvd_temp.close();


}
