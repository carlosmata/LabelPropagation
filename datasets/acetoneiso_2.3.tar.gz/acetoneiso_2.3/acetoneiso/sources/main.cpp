//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//Copyright 2010/2011 Marco Di Antonio

//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.
#include <QApplication>
#include "acetoneiso.h"
#include <QTranslator>
 
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

//const char *h = "--help"; 
QString clImage = argv[1];
if ( clImage.contains("--help")  or clImage.contains("-h")) {
      printf ( "\nAcetoneISO Distribuited under GPL v.3.0 \nAuthors:\nMarco Di Antonio 2010\nFabrizio Di Marco and Marco Di Antonio 2006-2007-2008-2009 \nContact: acetoneiso@gmail.com\nWebsite:www.acetoneteam.org\nusage: \nacetoneiso [$path_to_imagefile_to_mount] --> mounts given image and opens it in default filemanager \nacetoneiso           --> opens AcetoneISO GUI\nacetoneiso --help    --> shows this help\n\n" );
    }
else {
      //printf ( "Mounting %s\n", argv[1] );  
      //cmMount( argv[1] );
      QString locale = QLocale::system().name();
      QTranslator translator;
      translator.load(QString(":/locale/acetoneiso_") + locale);
      app.installTranslator(&translator);

      acetoneiso *dialog = new acetoneiso();
      dialog->show();
      return app.exec();
     }
}
