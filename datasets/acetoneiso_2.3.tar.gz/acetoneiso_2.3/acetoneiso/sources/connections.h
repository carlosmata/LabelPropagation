//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Fabrizio Di Marco and Marco Di Antonio  (acetoneiso@gmail.com)
//
//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.



void acetoneiso::connections() {

    connect( actionConvert_MacOs_Image_2, SIGNAL ( triggered() ), this, SLOT ( macimg() ) );
    connect( pushButton, SIGNAL( clicked() ), this, SLOT( mount() ) ); 
    connect( pushButton_2, SIGNAL( clicked() ), this, SLOT( umount() ) ); 
    
    connect( pushButton_3, SIGNAL( clicked() ), this, SLOT( clear_history() ) ); 
    connect( pushButton_6, SIGNAL( clicked() ), this, SLOT( hide_process_display() ) ); 
    
    connect(actionMake_a_small_donation, SIGNAL( triggered() ), this, SLOT( paypal() ) );
    connect( pushButton_4, SIGNAL( triggered() ), this, SLOT( extract() ) ); 
    
    connect( actionSha1_check, SIGNAL( triggered() ), this, SLOT( sha1() ) ); 
    connect( actionSha256_check, SIGNAL( triggered() ), this, SLOT( sha256() ) ); 
    connect( actionSha512_check, SIGNAL( triggered() ), this, SLOT( sha384() ) ); 
    
    connect( actionMount_Image, SIGNAL( triggered() ), this, SLOT( mount() ) );
    connect( actionDonate, SIGNAL( triggered() ), this, SLOT( a_donate() ) );
    connect( actionExit, SIGNAL( triggered() ), qApp, SLOT( quit() ) );
    connect( pushButton_Omni_3, SIGNAL( triggered() ), this, SLOT( converter() ) );
    connect( pushButton_IsoFromFolder_2, SIGNAL( triggered() ), this, SLOT( foldertoiso() ) );
    connect( actionA_protected_CD_DVD, SIGNAL( triggered() ), this, SLOT( isopcgame() ) );
    connect( pushButton_PSX_Rip, SIGNAL( triggered() ), this, SLOT( psxrip() ) );
    connect( button_backup_audio_2, SIGNAL( triggered() ), this, SLOT( backupaudio() ) );
    connect( actionCompress, SIGNAL( triggered() ), this, SLOT( compress() ) ); 
    connect( actionDecrypt, SIGNAL( triggered() ), this, SLOT( decrypt() ) );
    connect( actionEncrypt, SIGNAL( triggered() ), this, SLOT( encrypt() ) );
    connect( pushButton_IsoFromFolder_3, SIGNAL( triggered() ), this, SLOT( isocd() ) );
    connect( actionMerge_Splitted_Image, SIGNAL( triggered() ), this, SLOT( merge() ) );
    connect( actionSplit, SIGNAL( triggered() ), this, SLOT( split() ) );
    connect( actionExtract, SIGNAL( triggered() ), this, SLOT( uncompress() ) );
    connect( actionPlay, SIGNAL( triggered() ), this, SLOT( play() ) );
    connect( actionUmount_2, SIGNAL( triggered() ), this, SLOT( unplay() ) );
    connect( pushButton_GenCUE, SIGNAL( triggered() ), this, SLOT( gencue() ) );
    connect( actionMount_UDF_ISO_2, SIGNAL( triggered() ), this, SLOT( udf() ) );
    connect( actionConvert_video_for_PSP, SIGNAL( triggered() ), this, SLOT( convertpsp() ) );
    connect( pushButton_5, SIGNAL( clicked() ), this, SLOT( call_database_options() ) );
    connect( actionRip_DVD_2_Xvid, SIGNAL( triggered() ), this, SLOT( rip() ) );
    connect( actionConvert_generic_video, SIGNAL( triggered() ), this, SLOT( vidgeneric() ) );
    connect( actionWithout_Account, SIGNAL( triggered() ), this, SLOT( utube() ) );
    connect( actionUser_Account_Login, SIGNAL( triggered() ), this, SLOT( utubeuser() ) );
    connect(actionUnmount_Image,SIGNAL( triggered() ), this, SLOT( umount() ) );
    //connect( actionPornTube_Download_Video, SIGNAL( triggered() ), this, SLOT( pornotube() ) );
    connect( actionMetaCafe_Download_Video, SIGNAL( triggered() ), this, SLOT( metacafe() ) );
    connect( actionConvert_FLV_2_AVI, SIGNAL( triggered() ), this, SLOT( flvavi() ) );
    connect( actionConvert_WMA_2_MP3, SIGNAL( triggered() ), this, SLOT( wma2wav() ) );
    connect( actionExtract_a_RAR_password_protectd, SIGNAL( triggered() ), this, SLOT( rar() ) );
    connect( actionGenerate_Md5, SIGNAL( triggered() ), this, SLOT( md5generate() ) );
    connect( actionCheck_Md5, SIGNAL( triggered() ), this, SLOT( md5check() ) );
    connect( actionGeneric_Mount_2, SIGNAL( triggered() ), this, SLOT( gmount() ) );
    connect( actionGeneric_Umount_2, SIGNAL( triggered() ), this, SLOT( gumount() ) );
    connect( actionExtract_Boot_Image_2, SIGNAL( triggered() ), this, SLOT( getboot() ) );
    connect( &GPg, SIGNAL(finished(int, QProcess::ExitStatus)), this,SLOT( closeProg() ) );
    connect( &GPg, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutgpg(int, QProcess::ExitStatus)));
    connect( &PZip, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &PZip, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutcompress(int, QProcess::ExitStatus)));
    connect( &SPlit, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &SPlit, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutsplit(int, QProcess::ExitStatus)));
    connect( &PZipuncompress, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &PZipuncompress, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutuncompress(int, QProcess::ExitStatus)));
    connect( listWidget, SIGNAL( itemDoubleClicked (QListWidgetItem *) ), this, SLOT(mdatabase(QListWidgetItem *) ) );
    connect( &DD, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &DD, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutisofromcd(int, QProcess::ExitStatus)));
    connect( &DD, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( initial_get_database() ));
    connect( listWidget_2, SIGNAL( itemDoubleClicked (QListWidgetItem *) ), this, SLOT(open_mounted(QListWidgetItem *) ) );
    connect( &TAr, SIGNAL(finished(int, QProcess::ExitStatus)), this,SLOT( closeProg() ) );
    connect( &TAr, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(messaggio_poweriso()));
   
    connect( &CUe, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &CUe, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutcue(int, QProcess::ExitStatus)));
    connect( pushButton_delImage, SIGNAL( clicked() ), this, SLOT( remove_fromDatabase() ) );
    connect( pushButton_updateDB, SIGNAL( clicked() ), this, SLOT( initial_get_database() ) );
    connect( &WGet2, SIGNAL( finished(int, QProcess::ExitStatus)), this,SLOT( closeProg() ) );
    connect( &CAt, SIGNAL( finished(int, QProcess::ExitStatus)), this,SLOT( closeProg() ) );
    connect( &CAt, SIGNAL( finished(int, QProcess::ExitStatus)), this,SLOT( mergeMSG(int, QProcess::ExitStatus) ) );
    connect( &FUse, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutfuseiso(int, QProcess::ExitStatus)));
    connect( &ELtorito, SIGNAL( finished(int, QProcess::ExitStatus)), this,SLOT( closeProg() ) );
    connect( &TOc, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));

    connect( &AUdio, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &AUdio, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutaudiotools(int, QProcess::ExitStatus)));
    connect( &FUsermount, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &FUsermount, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutumount(int, QProcess::ExitStatus)));
    connect( &BIso, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &UCheck, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutucheck(int, QProcess::ExitStatus)));
    connect( actionRip_CD_Audio_to_WAV, SIGNAL( triggered() ), this, SLOT( ripcdaudio() ) );
    connect( &RIpaudio, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT( closeProg() ));
    connect( &RIpaudio, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutripaudio(int, QProcess::ExitStatus)));
    connect( &AUdio, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(printOutripaudio(int, QProcess::ExitStatus)));
    connect( actionExtract_Audio_from_any_Video_file, SIGNAL( triggered() ), this, SLOT( extractaudio() ) );

    connect( lineEdit, SIGNAL( editingFinished() ), this, SLOT( search() ) );
    connect( lineEdit, SIGNAL( cursorPositionChanged ( int , int ) ), this, SLOT( search() ) );
    connect(dockWidget1, SIGNAL(dockLocationChanged(Qt::DockWidgetArea)),this, SLOT(setDockPos()));
    connect(listWidget, SIGNAL(customContextMenuRequested(const QPoint &)), this, SLOT(userListMenuRequested(const QPoint &))); 
    connect(history, SIGNAL(customContextMenuRequested(const QPoint &)), this, SLOT(historycontextmenu(const QPoint &))); 
    connect( history, SIGNAL( itemDoubleClicked (QListWidgetItem *) ), this, SLOT(historydoubleclickmount(QListWidgetItem *) ) );
    connect( search_history_lineedit, SIGNAL( editingFinished() ), this, SLOT( search_history() ) );
    connect( search_history_lineedit, SIGNAL( cursorPositionChanged ( int , int ) ), this, SLOT( search_history() ) );
    connect(listWidget_2, SIGNAL(customContextMenuRequested(const QPoint &)), this, SLOT(mountdisplaycontextmenu(const QPoint &))); 

    //burn connections
    connect(erase_combobox_action, SIGNAL( clicked() ), this, SLOT( erase_media() ) );
    connect(pushButton_7, SIGNAL( clicked() ), this, SLOT( burniso2_cd() ) );

  connect(listWidget_2, SIGNAL( itemSelectionChanged() ), this, SLOT( mountdisplayClicked() ) );
    
    
}


