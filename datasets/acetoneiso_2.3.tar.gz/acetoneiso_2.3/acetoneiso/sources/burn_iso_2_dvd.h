//This file is part of AcetoneISO. Copyright 2006,2007,2008,2009 Marco Di Antonio and Fabrizio Di Marco (acetoneiso@gmail.com)
//Copyright 2010/2011 Marco Di Antonio

//    AcetoneISO is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    AcetoneISO is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with AcetoneISO.  If not, see <http://www.gnu.org/licenses/>.



#ifndef BURN_ISO2DVD_H
#define BURN_ISO2DVD_H
#include <QFile>
#include <QProcess>
#include <QByteArray>
#include <QDialog>
#include "../build/ui_burn_iso_2_dvd.h"
//
class burniso2dvd : public QDialog, public Ui::burniso2dvd
{
Q_OBJECT
public:
	burniso2dvd( QWidget * parent = 0, Qt::WFlags f = 0 );
	QStringList device_path;
	QStringList id_device;
	QByteArray erase_output;
	bool is_erasing;
	bool loaded_success;
	QTimer *timer;
	QString discotipo;
	QByteArray eraseoutput_real;
	QHash<QString,QString> dvdHash;
	QHash<QString,QString> dvdHashStoragetype;
	QHash<int, QString> hash_speed;
	QString imageToBurn;
	QStringList arraySpeed;
	int itemRemovedSpeed;
	QString discIsNotEmptyAndRWType;
	
private slots:
  void start_erase();
  void device_scan();
  void media_available();
  void clean_combobox_speed();
  void select_image();
  void estimated_time() ;
  void combo_changed(int n);
  void updateEraseDisplay();
  void printOutErase(int, QProcess::ExitStatus);
  void disable_buttons();
  void enable_buttons();
  void play_success();
  void play_error();
  
  
private:
QProcess *erase;
QProcess EJect;
  
};
#endif

